/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 1

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1

/* "%code top" blocks.  */
#line 23 "modules/grpc/otel/otel-grammar.y"

#include "otel-parser.h"


#line 73 "modules/grpc/otel/otel-grammar.c"
/* Substitute the type names.  */
#define YYSTYPE         OTEL_STYPE
#define YYLTYPE         OTEL_LTYPE
/* Substitute the variable and function names.  */
#define yyparse         otel_parse
#define yylex           otel_lex
#define yyerror         otel_error
#define yydebug         otel_debug
#define yynerrs         otel_nerrs


# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

/* Use api.header.include to #include this header
   instead of duplicating it here.  */
#ifndef YY_OTEL_MODULES_GRPC_OTEL_OTEL_GRAMMAR_H_INCLUDED
# define YY_OTEL_MODULES_GRPC_OTEL_OTEL_GRAMMAR_H_INCLUDED
/* Debug traces.  */
#ifndef OTEL_DEBUG
# if defined YYDEBUG
#if YYDEBUG
#   define OTEL_DEBUG 1
#  else
#   define OTEL_DEBUG 0
#  endif
# else /* ! defined YYDEBUG */
#  define OTEL_DEBUG 0
# endif /* ! defined YYDEBUG */
#endif  /* ! defined OTEL_DEBUG */
#if OTEL_DEBUG
extern int otel_debug;
#endif

/* Token kinds.  */
#ifndef OTEL_TOKENTYPE
# define OTEL_TOKENTYPE
  enum otel_tokentype
  {
    OTEL_EMPTY = -2,
    OTEL_EOF = 0,                  /* "end of file"  */
    OTEL_error = 256,              /* error  */
    OTEL_UNDEF = 10523,            /* "invalid token"  */
    LL_CONTEXT_ROOT = 1,           /* LL_CONTEXT_ROOT  */
    LL_CONTEXT_DESTINATION = 2,    /* LL_CONTEXT_DESTINATION  */
    LL_CONTEXT_SOURCE = 3,         /* LL_CONTEXT_SOURCE  */
    LL_CONTEXT_PARSER = 4,         /* LL_CONTEXT_PARSER  */
    LL_CONTEXT_REWRITE = 5,        /* LL_CONTEXT_REWRITE  */
    LL_CONTEXT_FILTER = 6,         /* LL_CONTEXT_FILTER  */
    LL_CONTEXT_LOG = 7,            /* LL_CONTEXT_LOG  */
    LL_CONTEXT_BLOCK_DEF = 8,      /* LL_CONTEXT_BLOCK_DEF  */
    LL_CONTEXT_BLOCK_REF = 9,      /* LL_CONTEXT_BLOCK_REF  */
    LL_CONTEXT_BLOCK_CONTENT = 10, /* LL_CONTEXT_BLOCK_CONTENT  */
    LL_CONTEXT_BLOCK_ARG = 11,     /* LL_CONTEXT_BLOCK_ARG  */
    LL_CONTEXT_PRAGMA = 12,        /* LL_CONTEXT_PRAGMA  */
    LL_CONTEXT_FORMAT = 13,        /* LL_CONTEXT_FORMAT  */
    LL_CONTEXT_TEMPLATE_FUNC = 14, /* LL_CONTEXT_TEMPLATE_FUNC  */
    LL_CONTEXT_INNER_DEST = 15,    /* LL_CONTEXT_INNER_DEST  */
    LL_CONTEXT_INNER_SRC = 16,     /* LL_CONTEXT_INNER_SRC  */
    LL_CONTEXT_CLIENT_PROTO = 17,  /* LL_CONTEXT_CLIENT_PROTO  */
    LL_CONTEXT_SERVER_PROTO = 18,  /* LL_CONTEXT_SERVER_PROTO  */
    LL_CONTEXT_OPTIONS = 19,       /* LL_CONTEXT_OPTIONS  */
    LL_CONTEXT_CONFIG = 20,        /* LL_CONTEXT_CONFIG  */
    LL_CONTEXT_MAX = 21,           /* LL_CONTEXT_MAX  */
    KW_SOURCE = 10000,             /* KW_SOURCE  */
    KW_FILTER = 10001,             /* KW_FILTER  */
    KW_PARSER = 10002,             /* KW_PARSER  */
    KW_DESTINATION = 10003,        /* KW_DESTINATION  */
    KW_LOG = 10004,                /* KW_LOG  */
    KW_OPTIONS = 10005,            /* KW_OPTIONS  */
    KW_INCLUDE = 10006,            /* KW_INCLUDE  */
    KW_BLOCK = 10007,              /* KW_BLOCK  */
    KW_JUNCTION = 10008,           /* KW_JUNCTION  */
    KW_CHANNEL = 10009,            /* KW_CHANNEL  */
    KW_IF = 10010,                 /* KW_IF  */
    KW_ELSE = 10011,               /* KW_ELSE  */
    KW_ELIF = 10012,               /* KW_ELIF  */
    KW_INTERNAL = 10020,           /* KW_INTERNAL  */
    KW_SYSLOG = 10060,             /* KW_SYSLOG  */
    KW_MARK_FREQ = 10071,          /* KW_MARK_FREQ  */
    KW_STATS_FREQ = 10072,         /* KW_STATS_FREQ  */
    KW_STATS_LEVEL = 10073,        /* KW_STATS_LEVEL  */
    KW_STATS_LIFETIME = 10074,     /* KW_STATS_LIFETIME  */
    KW_FLUSH_LINES = 10075,        /* KW_FLUSH_LINES  */
    KW_SUPPRESS = 10076,           /* KW_SUPPRESS  */
    KW_FLUSH_TIMEOUT = 10077,      /* KW_FLUSH_TIMEOUT  */
    KW_LOG_MSG_SIZE = 10078,       /* KW_LOG_MSG_SIZE  */
    KW_FILE_TEMPLATE = 10079,      /* KW_FILE_TEMPLATE  */
    KW_PROTO_TEMPLATE = 10080,     /* KW_PROTO_TEMPLATE  */
    KW_MARK_MODE = 10081,          /* KW_MARK_MODE  */
    KW_ENCODING = 10082,           /* KW_ENCODING  */
    KW_TYPE = 10083,               /* KW_TYPE  */
    KW_STATS_MAX_DYNAMIC = 10084,  /* KW_STATS_MAX_DYNAMIC  */
    KW_MIN_IW_SIZE_PER_READER = 10085, /* KW_MIN_IW_SIZE_PER_READER  */
    KW_WORKERS = 10086,            /* KW_WORKERS  */
    KW_BATCH_LINES = 10087,        /* KW_BATCH_LINES  */
    KW_BATCH_TIMEOUT = 10088,      /* KW_BATCH_TIMEOUT  */
    KW_TRIM_LARGE_MESSAGES = 10089, /* KW_TRIM_LARGE_MESSAGES  */
    KW_STATS = 10400,              /* KW_STATS  */
    KW_FREQ = 10401,               /* KW_FREQ  */
    KW_LEVEL = 10402,              /* KW_LEVEL  */
    KW_LIFETIME = 10403,           /* KW_LIFETIME  */
    KW_MAX_DYNAMIC = 10404,        /* KW_MAX_DYNAMIC  */
    KW_SYSLOG_STATS = 10405,       /* KW_SYSLOG_STATS  */
    KW_HEALTHCHECK_FREQ = 10406,   /* KW_HEALTHCHECK_FREQ  */
    KW_CHAIN_HOSTNAMES = 10090,    /* KW_CHAIN_HOSTNAMES  */
    KW_NORMALIZE_HOSTNAMES = 10091, /* KW_NORMALIZE_HOSTNAMES  */
    KW_KEEP_HOSTNAME = 10092,      /* KW_KEEP_HOSTNAME  */
    KW_CHECK_HOSTNAME = 10093,     /* KW_CHECK_HOSTNAME  */
    KW_BAD_HOSTNAME = 10094,       /* KW_BAD_HOSTNAME  */
    KW_LOG_LEVEL = 10095,          /* KW_LOG_LEVEL  */
    KW_KEEP_TIMESTAMP = 10100,     /* KW_KEEP_TIMESTAMP  */
    KW_USE_DNS = 10110,            /* KW_USE_DNS  */
    KW_USE_FQDN = 10111,           /* KW_USE_FQDN  */
    KW_CUSTOM_DOMAIN = 10112,      /* KW_CUSTOM_DOMAIN  */
    KW_DNS_CACHE = 10120,          /* KW_DNS_CACHE  */
    KW_DNS_CACHE_SIZE = 10121,     /* KW_DNS_CACHE_SIZE  */
    KW_DNS_CACHE_EXPIRE = 10130,   /* KW_DNS_CACHE_EXPIRE  */
    KW_DNS_CACHE_EXPIRE_FAILED = 10131, /* KW_DNS_CACHE_EXPIRE_FAILED  */
    KW_DNS_CACHE_HOSTS = 10132,    /* KW_DNS_CACHE_HOSTS  */
    KW_PERSIST_ONLY = 10140,       /* KW_PERSIST_ONLY  */
    KW_USE_RCPTID = 10141,         /* KW_USE_RCPTID  */
    KW_USE_UNIQID = 10142,         /* KW_USE_UNIQID  */
    KW_TZ_CONVERT = 10150,         /* KW_TZ_CONVERT  */
    KW_TS_FORMAT = 10151,          /* KW_TS_FORMAT  */
    KW_FRAC_DIGITS = 10152,        /* KW_FRAC_DIGITS  */
    KW_LOG_FIFO_SIZE = 10160,      /* KW_LOG_FIFO_SIZE  */
    KW_LOG_FETCH_LIMIT = 10162,    /* KW_LOG_FETCH_LIMIT  */
    KW_LOG_IW_SIZE = 10163,        /* KW_LOG_IW_SIZE  */
    KW_LOG_PREFIX = 10164,         /* KW_LOG_PREFIX  */
    KW_PROGRAM_OVERRIDE = 10165,   /* KW_PROGRAM_OVERRIDE  */
    KW_HOST_OVERRIDE = 10166,      /* KW_HOST_OVERRIDE  */
    KW_THROTTLE = 10170,           /* KW_THROTTLE  */
    KW_THREADED = 10171,           /* KW_THREADED  */
    KW_PASS_UNIX_CREDENTIALS = 10180, /* KW_PASS_UNIX_CREDENTIALS  */
    KW_PERSIST_NAME = 10181,       /* KW_PERSIST_NAME  */
    KW_READ_OLD_RECORDS = 10182,   /* KW_READ_OLD_RECORDS  */
    KW_USE_SYSLOGNG_PID = 10183,   /* KW_USE_SYSLOGNG_PID  */
    KW_FLAGS = 10190,              /* KW_FLAGS  */
    KW_PAD_SIZE = 10200,           /* KW_PAD_SIZE  */
    KW_TIME_ZONE = 10201,          /* KW_TIME_ZONE  */
    KW_RECV_TIME_ZONE = 10202,     /* KW_RECV_TIME_ZONE  */
    KW_SEND_TIME_ZONE = 10203,     /* KW_SEND_TIME_ZONE  */
    KW_LOCAL_TIME_ZONE = 10204,    /* KW_LOCAL_TIME_ZONE  */
    KW_FORMAT = 10205,             /* KW_FORMAT  */
    KW_MULTI_LINE_MODE = 10206,    /* KW_MULTI_LINE_MODE  */
    KW_MULTI_LINE_PREFIX = 10207,  /* KW_MULTI_LINE_PREFIX  */
    KW_MULTI_LINE_GARBAGE = 10208, /* KW_MULTI_LINE_GARBAGE  */
    KW_TRUNCATE_SIZE = 10209,      /* KW_TRUNCATE_SIZE  */
    KW_TIME_REOPEN = 10210,        /* KW_TIME_REOPEN  */
    KW_TIME_REAP = 10211,          /* KW_TIME_REAP  */
    KW_TIME_SLEEP = 10212,         /* KW_TIME_SLEEP  */
    KW_PARTITIONS = 10213,         /* KW_PARTITIONS  */
    KW_PARTITION_KEY = 10214,      /* KW_PARTITION_KEY  */
    KW_PARALLELIZE = 10215,        /* KW_PARALLELIZE  */
    KW_TMPL_ESCAPE = 10220,        /* KW_TMPL_ESCAPE  */
    KW_OPTIONAL = 10230,           /* KW_OPTIONAL  */
    KW_CREATE_DIRS = 10240,        /* KW_CREATE_DIRS  */
    KW_OWNER = 10250,              /* KW_OWNER  */
    KW_GROUP = 10251,              /* KW_GROUP  */
    KW_PERM = 10252,               /* KW_PERM  */
    KW_DIR_OWNER = 10260,          /* KW_DIR_OWNER  */
    KW_DIR_GROUP = 10261,          /* KW_DIR_GROUP  */
    KW_DIR_PERM = 10262,           /* KW_DIR_PERM  */
    KW_TEMPLATE = 10270,           /* KW_TEMPLATE  */
    KW_TEMPLATE_ESCAPE = 10271,    /* KW_TEMPLATE_ESCAPE  */
    KW_TEMPLATE_FUNCTION = 10272,  /* KW_TEMPLATE_FUNCTION  */
    KW_DEFAULT_FACILITY = 10300,   /* KW_DEFAULT_FACILITY  */
    KW_DEFAULT_SEVERITY = 10301,   /* KW_DEFAULT_SEVERITY  */
    KW_SDATA_PREFIX = 10302,       /* KW_SDATA_PREFIX  */
    KW_PORT = 10323,               /* KW_PORT  */
    KW_USE_TIME_RECVD = 10340,     /* KW_USE_TIME_RECVD  */
    KW_FACILITY = 10350,           /* KW_FACILITY  */
    KW_SEVERITY = 10351,           /* KW_SEVERITY  */
    KW_HOST = 10352,               /* KW_HOST  */
    KW_MATCH = 10353,              /* KW_MATCH  */
    KW_MESSAGE = 10354,            /* KW_MESSAGE  */
    KW_NETMASK = 10355,            /* KW_NETMASK  */
    KW_TAGS = 10356,               /* KW_TAGS  */
    KW_NETMASK6 = 10357,           /* KW_NETMASK6  */
    KW_REWRITE = 10370,            /* KW_REWRITE  */
    KW_CONDITION = 10371,          /* KW_CONDITION  */
    KW_VALUE = 10372,              /* KW_VALUE  */
    KW_YES = 10380,                /* KW_YES  */
    KW_NO = 10381,                 /* KW_NO  */
    KW_AUTO = 10382,               /* KW_AUTO  */
    KW_IFDEF = 10410,              /* KW_IFDEF  */
    KW_ENDIF = 10411,              /* KW_ENDIF  */
    LL_DOTDOT = 10420,             /* LL_DOTDOT  */
    LL_DOTDOTDOT = 10421,          /* LL_DOTDOTDOT  */
    LL_PRAGMA = 10422,             /* LL_PRAGMA  */
    LL_EOL = 10423,                /* LL_EOL  */
    LL_ERROR = 10424,              /* LL_ERROR  */
    LL_ARROW = 10425,              /* LL_ARROW  */
    LL_IDENTIFIER = 10430,         /* LL_IDENTIFIER  */
    LL_NUMBER = 10431,             /* LL_NUMBER  */
    LL_FLOAT = 10432,              /* LL_FLOAT  */
    LL_STRING = 10433,             /* LL_STRING  */
    LL_TOKEN = 10434,              /* LL_TOKEN  */
    LL_BLOCK = 10435,              /* LL_BLOCK  */
    LL_PLUGIN = 10436,             /* LL_PLUGIN  */
    KW_VALUE_PAIRS = 10500,        /* KW_VALUE_PAIRS  */
    KW_EXCLUDE = 10502,            /* KW_EXCLUDE  */
    KW_PAIR = 10503,               /* KW_PAIR  */
    KW_KEY = 10504,                /* KW_KEY  */
    KW_SCOPE = 10505,              /* KW_SCOPE  */
    KW_SHIFT = 10506,              /* KW_SHIFT  */
    KW_SHIFT_LEVELS = 10507,       /* KW_SHIFT_LEVELS  */
    KW_REKEY = 10508,              /* KW_REKEY  */
    KW_ADD_PREFIX = 10509,         /* KW_ADD_PREFIX  */
    KW_REPLACE_PREFIX = 10510,     /* KW_REPLACE_PREFIX  */
    KW_CAST = 10511,               /* KW_CAST  */
    KW_UPPER = 10512,              /* KW_UPPER  */
    KW_LOWER = 10513,              /* KW_LOWER  */
    KW_INCLUDE_BYTES = 10514,      /* KW_INCLUDE_BYTES  */
    KW_ON_ERROR = 10520,           /* KW_ON_ERROR  */
    KW_RETRIES = 10521,            /* KW_RETRIES  */
    KW_FETCH_NO_DATA_DELAY = 10522, /* KW_FETCH_NO_DATA_DELAY  */
    KW_OPENTELEMETRY = 10524,      /* KW_OPENTELEMETRY  */
    KW_AUTH = 10525,               /* KW_AUTH  */
    KW_INSECURE = 10526,           /* KW_INSECURE  */
    KW_TLS = 10527,                /* KW_TLS  */
    KW_KEY_FILE = 10528,           /* KW_KEY_FILE  */
    KW_CERT_FILE = 10529,          /* KW_CERT_FILE  */
    KW_CA_FILE = 10530,            /* KW_CA_FILE  */
    KW_PEER_VERIFY = 10531,        /* KW_PEER_VERIFY  */
    KW_OPTIONAL_UNTRUSTED = 10532, /* KW_OPTIONAL_UNTRUSTED  */
    KW_OPTIONAL_TRUSTED = 10533,   /* KW_OPTIONAL_TRUSTED  */
    KW_REQUIRED_UNTRUSTED = 10534, /* KW_REQUIRED_UNTRUSTED  */
    KW_REQUIRED_TRUSTED = 10535,   /* KW_REQUIRED_TRUSTED  */
    KW_ALTS = 10536,               /* KW_ALTS  */
    KW_URL = 10537,                /* KW_URL  */
    KW_TARGET_SERVICE_ACCOUNTS = 10538, /* KW_TARGET_SERVICE_ACCOUNTS  */
    KW_ADC = 10539                 /* KW_ADC  */
  };
  typedef enum otel_tokentype otel_token_kind_t;
#endif
/* Token kinds.  */
#define OTEL_EMPTY -2
#define OTEL_EOF 0
#define OTEL_error 256
#define OTEL_UNDEF 10523
#define LL_CONTEXT_ROOT 1
#define LL_CONTEXT_DESTINATION 2
#define LL_CONTEXT_SOURCE 3
#define LL_CONTEXT_PARSER 4
#define LL_CONTEXT_REWRITE 5
#define LL_CONTEXT_FILTER 6
#define LL_CONTEXT_LOG 7
#define LL_CONTEXT_BLOCK_DEF 8
#define LL_CONTEXT_BLOCK_REF 9
#define LL_CONTEXT_BLOCK_CONTENT 10
#define LL_CONTEXT_BLOCK_ARG 11
#define LL_CONTEXT_PRAGMA 12
#define LL_CONTEXT_FORMAT 13
#define LL_CONTEXT_TEMPLATE_FUNC 14
#define LL_CONTEXT_INNER_DEST 15
#define LL_CONTEXT_INNER_SRC 16
#define LL_CONTEXT_CLIENT_PROTO 17
#define LL_CONTEXT_SERVER_PROTO 18
#define LL_CONTEXT_OPTIONS 19
#define LL_CONTEXT_CONFIG 20
#define LL_CONTEXT_MAX 21
#define KW_SOURCE 10000
#define KW_FILTER 10001
#define KW_PARSER 10002
#define KW_DESTINATION 10003
#define KW_LOG 10004
#define KW_OPTIONS 10005
#define KW_INCLUDE 10006
#define KW_BLOCK 10007
#define KW_JUNCTION 10008
#define KW_CHANNEL 10009
#define KW_IF 10010
#define KW_ELSE 10011
#define KW_ELIF 10012
#define KW_INTERNAL 10020
#define KW_SYSLOG 10060
#define KW_MARK_FREQ 10071
#define KW_STATS_FREQ 10072
#define KW_STATS_LEVEL 10073
#define KW_STATS_LIFETIME 10074
#define KW_FLUSH_LINES 10075
#define KW_SUPPRESS 10076
#define KW_FLUSH_TIMEOUT 10077
#define KW_LOG_MSG_SIZE 10078
#define KW_FILE_TEMPLATE 10079
#define KW_PROTO_TEMPLATE 10080
#define KW_MARK_MODE 10081
#define KW_ENCODING 10082
#define KW_TYPE 10083
#define KW_STATS_MAX_DYNAMIC 10084
#define KW_MIN_IW_SIZE_PER_READER 10085
#define KW_WORKERS 10086
#define KW_BATCH_LINES 10087
#define KW_BATCH_TIMEOUT 10088
#define KW_TRIM_LARGE_MESSAGES 10089
#define KW_STATS 10400
#define KW_FREQ 10401
#define KW_LEVEL 10402
#define KW_LIFETIME 10403
#define KW_MAX_DYNAMIC 10404
#define KW_SYSLOG_STATS 10405
#define KW_HEALTHCHECK_FREQ 10406
#define KW_CHAIN_HOSTNAMES 10090
#define KW_NORMALIZE_HOSTNAMES 10091
#define KW_KEEP_HOSTNAME 10092
#define KW_CHECK_HOSTNAME 10093
#define KW_BAD_HOSTNAME 10094
#define KW_LOG_LEVEL 10095
#define KW_KEEP_TIMESTAMP 10100
#define KW_USE_DNS 10110
#define KW_USE_FQDN 10111
#define KW_CUSTOM_DOMAIN 10112
#define KW_DNS_CACHE 10120
#define KW_DNS_CACHE_SIZE 10121
#define KW_DNS_CACHE_EXPIRE 10130
#define KW_DNS_CACHE_EXPIRE_FAILED 10131
#define KW_DNS_CACHE_HOSTS 10132
#define KW_PERSIST_ONLY 10140
#define KW_USE_RCPTID 10141
#define KW_USE_UNIQID 10142
#define KW_TZ_CONVERT 10150
#define KW_TS_FORMAT 10151
#define KW_FRAC_DIGITS 10152
#define KW_LOG_FIFO_SIZE 10160
#define KW_LOG_FETCH_LIMIT 10162
#define KW_LOG_IW_SIZE 10163
#define KW_LOG_PREFIX 10164
#define KW_PROGRAM_OVERRIDE 10165
#define KW_HOST_OVERRIDE 10166
#define KW_THROTTLE 10170
#define KW_THREADED 10171
#define KW_PASS_UNIX_CREDENTIALS 10180
#define KW_PERSIST_NAME 10181
#define KW_READ_OLD_RECORDS 10182
#define KW_USE_SYSLOGNG_PID 10183
#define KW_FLAGS 10190
#define KW_PAD_SIZE 10200
#define KW_TIME_ZONE 10201
#define KW_RECV_TIME_ZONE 10202
#define KW_SEND_TIME_ZONE 10203
#define KW_LOCAL_TIME_ZONE 10204
#define KW_FORMAT 10205
#define KW_MULTI_LINE_MODE 10206
#define KW_MULTI_LINE_PREFIX 10207
#define KW_MULTI_LINE_GARBAGE 10208
#define KW_TRUNCATE_SIZE 10209
#define KW_TIME_REOPEN 10210
#define KW_TIME_REAP 10211
#define KW_TIME_SLEEP 10212
#define KW_PARTITIONS 10213
#define KW_PARTITION_KEY 10214
#define KW_PARALLELIZE 10215
#define KW_TMPL_ESCAPE 10220
#define KW_OPTIONAL 10230
#define KW_CREATE_DIRS 10240
#define KW_OWNER 10250
#define KW_GROUP 10251
#define KW_PERM 10252
#define KW_DIR_OWNER 10260
#define KW_DIR_GROUP 10261
#define KW_DIR_PERM 10262
#define KW_TEMPLATE 10270
#define KW_TEMPLATE_ESCAPE 10271
#define KW_TEMPLATE_FUNCTION 10272
#define KW_DEFAULT_FACILITY 10300
#define KW_DEFAULT_SEVERITY 10301
#define KW_SDATA_PREFIX 10302
#define KW_PORT 10323
#define KW_USE_TIME_RECVD 10340
#define KW_FACILITY 10350
#define KW_SEVERITY 10351
#define KW_HOST 10352
#define KW_MATCH 10353
#define KW_MESSAGE 10354
#define KW_NETMASK 10355
#define KW_TAGS 10356
#define KW_NETMASK6 10357
#define KW_REWRITE 10370
#define KW_CONDITION 10371
#define KW_VALUE 10372
#define KW_YES 10380
#define KW_NO 10381
#define KW_AUTO 10382
#define KW_IFDEF 10410
#define KW_ENDIF 10411
#define LL_DOTDOT 10420
#define LL_DOTDOTDOT 10421
#define LL_PRAGMA 10422
#define LL_EOL 10423
#define LL_ERROR 10424
#define LL_ARROW 10425
#define LL_IDENTIFIER 10430
#define LL_NUMBER 10431
#define LL_FLOAT 10432
#define LL_STRING 10433
#define LL_TOKEN 10434
#define LL_BLOCK 10435
#define LL_PLUGIN 10436
#define KW_VALUE_PAIRS 10500
#define KW_EXCLUDE 10502
#define KW_PAIR 10503
#define KW_KEY 10504
#define KW_SCOPE 10505
#define KW_SHIFT 10506
#define KW_SHIFT_LEVELS 10507
#define KW_REKEY 10508
#define KW_ADD_PREFIX 10509
#define KW_REPLACE_PREFIX 10510
#define KW_CAST 10511
#define KW_UPPER 10512
#define KW_LOWER 10513
#define KW_INCLUDE_BYTES 10514
#define KW_ON_ERROR 10520
#define KW_RETRIES 10521
#define KW_FETCH_NO_DATA_DELAY 10522
#define KW_OPENTELEMETRY 10524
#define KW_AUTH 10525
#define KW_INSECURE 10526
#define KW_TLS 10527
#define KW_KEY_FILE 10528
#define KW_CERT_FILE 10529
#define KW_CA_FILE 10530
#define KW_PEER_VERIFY 10531
#define KW_OPTIONAL_UNTRUSTED 10532
#define KW_OPTIONAL_TRUSTED 10533
#define KW_REQUIRED_UNTRUSTED 10534
#define KW_REQUIRED_TRUSTED 10535
#define KW_ALTS 10536
#define KW_URL 10537
#define KW_TARGET_SERVICE_ACCOUNTS 10538
#define KW_ADC 10539

/* Value type.  */
#if ! defined OTEL_STYPE && ! defined OTEL_STYPE_IS_DECLARED
typedef CFG_STYPE OTEL_STYPE;
# define OTEL_STYPE_IS_TRIVIAL 1
# define OTEL_STYPE_IS_DECLARED 1
#endif

/* Location type.  */
typedef CFG_LTYPE OTEL_LTYPE;




int otel_parse (CfgLexer *lexer, void **instance, gpointer arg);


#endif /* !YY_OTEL_MODULES_GRPC_OTEL_OTEL_GRAMMAR_H_INCLUDED  */
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_LL_CONTEXT_ROOT = 3,            /* LL_CONTEXT_ROOT  */
  YYSYMBOL_LL_CONTEXT_DESTINATION = 4,     /* LL_CONTEXT_DESTINATION  */
  YYSYMBOL_LL_CONTEXT_SOURCE = 5,          /* LL_CONTEXT_SOURCE  */
  YYSYMBOL_LL_CONTEXT_PARSER = 6,          /* LL_CONTEXT_PARSER  */
  YYSYMBOL_LL_CONTEXT_REWRITE = 7,         /* LL_CONTEXT_REWRITE  */
  YYSYMBOL_LL_CONTEXT_FILTER = 8,          /* LL_CONTEXT_FILTER  */
  YYSYMBOL_LL_CONTEXT_LOG = 9,             /* LL_CONTEXT_LOG  */
  YYSYMBOL_LL_CONTEXT_BLOCK_DEF = 10,      /* LL_CONTEXT_BLOCK_DEF  */
  YYSYMBOL_LL_CONTEXT_BLOCK_REF = 11,      /* LL_CONTEXT_BLOCK_REF  */
  YYSYMBOL_LL_CONTEXT_BLOCK_CONTENT = 12,  /* LL_CONTEXT_BLOCK_CONTENT  */
  YYSYMBOL_LL_CONTEXT_BLOCK_ARG = 13,      /* LL_CONTEXT_BLOCK_ARG  */
  YYSYMBOL_LL_CONTEXT_PRAGMA = 14,         /* LL_CONTEXT_PRAGMA  */
  YYSYMBOL_LL_CONTEXT_FORMAT = 15,         /* LL_CONTEXT_FORMAT  */
  YYSYMBOL_LL_CONTEXT_TEMPLATE_FUNC = 16,  /* LL_CONTEXT_TEMPLATE_FUNC  */
  YYSYMBOL_LL_CONTEXT_INNER_DEST = 17,     /* LL_CONTEXT_INNER_DEST  */
  YYSYMBOL_LL_CONTEXT_INNER_SRC = 18,      /* LL_CONTEXT_INNER_SRC  */
  YYSYMBOL_LL_CONTEXT_CLIENT_PROTO = 19,   /* LL_CONTEXT_CLIENT_PROTO  */
  YYSYMBOL_LL_CONTEXT_SERVER_PROTO = 20,   /* LL_CONTEXT_SERVER_PROTO  */
  YYSYMBOL_LL_CONTEXT_OPTIONS = 21,        /* LL_CONTEXT_OPTIONS  */
  YYSYMBOL_LL_CONTEXT_CONFIG = 22,         /* LL_CONTEXT_CONFIG  */
  YYSYMBOL_LL_CONTEXT_MAX = 23,            /* LL_CONTEXT_MAX  */
  YYSYMBOL_KW_SOURCE = 24,                 /* KW_SOURCE  */
  YYSYMBOL_KW_FILTER = 25,                 /* KW_FILTER  */
  YYSYMBOL_KW_PARSER = 26,                 /* KW_PARSER  */
  YYSYMBOL_KW_DESTINATION = 27,            /* KW_DESTINATION  */
  YYSYMBOL_KW_LOG = 28,                    /* KW_LOG  */
  YYSYMBOL_KW_OPTIONS = 29,                /* KW_OPTIONS  */
  YYSYMBOL_KW_INCLUDE = 30,                /* KW_INCLUDE  */
  YYSYMBOL_KW_BLOCK = 31,                  /* KW_BLOCK  */
  YYSYMBOL_KW_JUNCTION = 32,               /* KW_JUNCTION  */
  YYSYMBOL_KW_CHANNEL = 33,                /* KW_CHANNEL  */
  YYSYMBOL_KW_IF = 34,                     /* KW_IF  */
  YYSYMBOL_KW_ELSE = 35,                   /* KW_ELSE  */
  YYSYMBOL_KW_ELIF = 36,                   /* KW_ELIF  */
  YYSYMBOL_KW_INTERNAL = 37,               /* KW_INTERNAL  */
  YYSYMBOL_KW_SYSLOG = 38,                 /* KW_SYSLOG  */
  YYSYMBOL_KW_MARK_FREQ = 39,              /* KW_MARK_FREQ  */
  YYSYMBOL_KW_STATS_FREQ = 40,             /* KW_STATS_FREQ  */
  YYSYMBOL_KW_STATS_LEVEL = 41,            /* KW_STATS_LEVEL  */
  YYSYMBOL_KW_STATS_LIFETIME = 42,         /* KW_STATS_LIFETIME  */
  YYSYMBOL_KW_FLUSH_LINES = 43,            /* KW_FLUSH_LINES  */
  YYSYMBOL_KW_SUPPRESS = 44,               /* KW_SUPPRESS  */
  YYSYMBOL_KW_FLUSH_TIMEOUT = 45,          /* KW_FLUSH_TIMEOUT  */
  YYSYMBOL_KW_LOG_MSG_SIZE = 46,           /* KW_LOG_MSG_SIZE  */
  YYSYMBOL_KW_FILE_TEMPLATE = 47,          /* KW_FILE_TEMPLATE  */
  YYSYMBOL_KW_PROTO_TEMPLATE = 48,         /* KW_PROTO_TEMPLATE  */
  YYSYMBOL_KW_MARK_MODE = 49,              /* KW_MARK_MODE  */
  YYSYMBOL_KW_ENCODING = 50,               /* KW_ENCODING  */
  YYSYMBOL_KW_TYPE = 51,                   /* KW_TYPE  */
  YYSYMBOL_KW_STATS_MAX_DYNAMIC = 52,      /* KW_STATS_MAX_DYNAMIC  */
  YYSYMBOL_KW_MIN_IW_SIZE_PER_READER = 53, /* KW_MIN_IW_SIZE_PER_READER  */
  YYSYMBOL_KW_WORKERS = 54,                /* KW_WORKERS  */
  YYSYMBOL_KW_BATCH_LINES = 55,            /* KW_BATCH_LINES  */
  YYSYMBOL_KW_BATCH_TIMEOUT = 56,          /* KW_BATCH_TIMEOUT  */
  YYSYMBOL_KW_TRIM_LARGE_MESSAGES = 57,    /* KW_TRIM_LARGE_MESSAGES  */
  YYSYMBOL_KW_STATS = 58,                  /* KW_STATS  */
  YYSYMBOL_KW_FREQ = 59,                   /* KW_FREQ  */
  YYSYMBOL_KW_LEVEL = 60,                  /* KW_LEVEL  */
  YYSYMBOL_KW_LIFETIME = 61,               /* KW_LIFETIME  */
  YYSYMBOL_KW_MAX_DYNAMIC = 62,            /* KW_MAX_DYNAMIC  */
  YYSYMBOL_KW_SYSLOG_STATS = 63,           /* KW_SYSLOG_STATS  */
  YYSYMBOL_KW_HEALTHCHECK_FREQ = 64,       /* KW_HEALTHCHECK_FREQ  */
  YYSYMBOL_KW_CHAIN_HOSTNAMES = 65,        /* KW_CHAIN_HOSTNAMES  */
  YYSYMBOL_KW_NORMALIZE_HOSTNAMES = 66,    /* KW_NORMALIZE_HOSTNAMES  */
  YYSYMBOL_KW_KEEP_HOSTNAME = 67,          /* KW_KEEP_HOSTNAME  */
  YYSYMBOL_KW_CHECK_HOSTNAME = 68,         /* KW_CHECK_HOSTNAME  */
  YYSYMBOL_KW_BAD_HOSTNAME = 69,           /* KW_BAD_HOSTNAME  */
  YYSYMBOL_KW_LOG_LEVEL = 70,              /* KW_LOG_LEVEL  */
  YYSYMBOL_KW_KEEP_TIMESTAMP = 71,         /* KW_KEEP_TIMESTAMP  */
  YYSYMBOL_KW_USE_DNS = 72,                /* KW_USE_DNS  */
  YYSYMBOL_KW_USE_FQDN = 73,               /* KW_USE_FQDN  */
  YYSYMBOL_KW_CUSTOM_DOMAIN = 74,          /* KW_CUSTOM_DOMAIN  */
  YYSYMBOL_KW_DNS_CACHE = 75,              /* KW_DNS_CACHE  */
  YYSYMBOL_KW_DNS_CACHE_SIZE = 76,         /* KW_DNS_CACHE_SIZE  */
  YYSYMBOL_KW_DNS_CACHE_EXPIRE = 77,       /* KW_DNS_CACHE_EXPIRE  */
  YYSYMBOL_KW_DNS_CACHE_EXPIRE_FAILED = 78, /* KW_DNS_CACHE_EXPIRE_FAILED  */
  YYSYMBOL_KW_DNS_CACHE_HOSTS = 79,        /* KW_DNS_CACHE_HOSTS  */
  YYSYMBOL_KW_PERSIST_ONLY = 80,           /* KW_PERSIST_ONLY  */
  YYSYMBOL_KW_USE_RCPTID = 81,             /* KW_USE_RCPTID  */
  YYSYMBOL_KW_USE_UNIQID = 82,             /* KW_USE_UNIQID  */
  YYSYMBOL_KW_TZ_CONVERT = 83,             /* KW_TZ_CONVERT  */
  YYSYMBOL_KW_TS_FORMAT = 84,              /* KW_TS_FORMAT  */
  YYSYMBOL_KW_FRAC_DIGITS = 85,            /* KW_FRAC_DIGITS  */
  YYSYMBOL_KW_LOG_FIFO_SIZE = 86,          /* KW_LOG_FIFO_SIZE  */
  YYSYMBOL_KW_LOG_FETCH_LIMIT = 87,        /* KW_LOG_FETCH_LIMIT  */
  YYSYMBOL_KW_LOG_IW_SIZE = 88,            /* KW_LOG_IW_SIZE  */
  YYSYMBOL_KW_LOG_PREFIX = 89,             /* KW_LOG_PREFIX  */
  YYSYMBOL_KW_PROGRAM_OVERRIDE = 90,       /* KW_PROGRAM_OVERRIDE  */
  YYSYMBOL_KW_HOST_OVERRIDE = 91,          /* KW_HOST_OVERRIDE  */
  YYSYMBOL_KW_THROTTLE = 92,               /* KW_THROTTLE  */
  YYSYMBOL_KW_THREADED = 93,               /* KW_THREADED  */
  YYSYMBOL_KW_PASS_UNIX_CREDENTIALS = 94,  /* KW_PASS_UNIX_CREDENTIALS  */
  YYSYMBOL_KW_PERSIST_NAME = 95,           /* KW_PERSIST_NAME  */
  YYSYMBOL_KW_READ_OLD_RECORDS = 96,       /* KW_READ_OLD_RECORDS  */
  YYSYMBOL_KW_USE_SYSLOGNG_PID = 97,       /* KW_USE_SYSLOGNG_PID  */
  YYSYMBOL_KW_FLAGS = 98,                  /* KW_FLAGS  */
  YYSYMBOL_KW_PAD_SIZE = 99,               /* KW_PAD_SIZE  */
  YYSYMBOL_KW_TIME_ZONE = 100,             /* KW_TIME_ZONE  */
  YYSYMBOL_KW_RECV_TIME_ZONE = 101,        /* KW_RECV_TIME_ZONE  */
  YYSYMBOL_KW_SEND_TIME_ZONE = 102,        /* KW_SEND_TIME_ZONE  */
  YYSYMBOL_KW_LOCAL_TIME_ZONE = 103,       /* KW_LOCAL_TIME_ZONE  */
  YYSYMBOL_KW_FORMAT = 104,                /* KW_FORMAT  */
  YYSYMBOL_KW_MULTI_LINE_MODE = 105,       /* KW_MULTI_LINE_MODE  */
  YYSYMBOL_KW_MULTI_LINE_PREFIX = 106,     /* KW_MULTI_LINE_PREFIX  */
  YYSYMBOL_KW_MULTI_LINE_GARBAGE = 107,    /* KW_MULTI_LINE_GARBAGE  */
  YYSYMBOL_KW_TRUNCATE_SIZE = 108,         /* KW_TRUNCATE_SIZE  */
  YYSYMBOL_KW_TIME_REOPEN = 109,           /* KW_TIME_REOPEN  */
  YYSYMBOL_KW_TIME_REAP = 110,             /* KW_TIME_REAP  */
  YYSYMBOL_KW_TIME_SLEEP = 111,            /* KW_TIME_SLEEP  */
  YYSYMBOL_KW_PARTITIONS = 112,            /* KW_PARTITIONS  */
  YYSYMBOL_KW_PARTITION_KEY = 113,         /* KW_PARTITION_KEY  */
  YYSYMBOL_KW_PARALLELIZE = 114,           /* KW_PARALLELIZE  */
  YYSYMBOL_KW_TMPL_ESCAPE = 115,           /* KW_TMPL_ESCAPE  */
  YYSYMBOL_KW_OPTIONAL = 116,              /* KW_OPTIONAL  */
  YYSYMBOL_KW_CREATE_DIRS = 117,           /* KW_CREATE_DIRS  */
  YYSYMBOL_KW_OWNER = 118,                 /* KW_OWNER  */
  YYSYMBOL_KW_GROUP = 119,                 /* KW_GROUP  */
  YYSYMBOL_KW_PERM = 120,                  /* KW_PERM  */
  YYSYMBOL_KW_DIR_OWNER = 121,             /* KW_DIR_OWNER  */
  YYSYMBOL_KW_DIR_GROUP = 122,             /* KW_DIR_GROUP  */
  YYSYMBOL_KW_DIR_PERM = 123,              /* KW_DIR_PERM  */
  YYSYMBOL_KW_TEMPLATE = 124,              /* KW_TEMPLATE  */
  YYSYMBOL_KW_TEMPLATE_ESCAPE = 125,       /* KW_TEMPLATE_ESCAPE  */
  YYSYMBOL_KW_TEMPLATE_FUNCTION = 126,     /* KW_TEMPLATE_FUNCTION  */
  YYSYMBOL_KW_DEFAULT_FACILITY = 127,      /* KW_DEFAULT_FACILITY  */
  YYSYMBOL_KW_DEFAULT_SEVERITY = 128,      /* KW_DEFAULT_SEVERITY  */
  YYSYMBOL_KW_SDATA_PREFIX = 129,          /* KW_SDATA_PREFIX  */
  YYSYMBOL_KW_PORT = 130,                  /* KW_PORT  */
  YYSYMBOL_KW_USE_TIME_RECVD = 131,        /* KW_USE_TIME_RECVD  */
  YYSYMBOL_KW_FACILITY = 132,              /* KW_FACILITY  */
  YYSYMBOL_KW_SEVERITY = 133,              /* KW_SEVERITY  */
  YYSYMBOL_KW_HOST = 134,                  /* KW_HOST  */
  YYSYMBOL_KW_MATCH = 135,                 /* KW_MATCH  */
  YYSYMBOL_KW_MESSAGE = 136,               /* KW_MESSAGE  */
  YYSYMBOL_KW_NETMASK = 137,               /* KW_NETMASK  */
  YYSYMBOL_KW_TAGS = 138,                  /* KW_TAGS  */
  YYSYMBOL_KW_NETMASK6 = 139,              /* KW_NETMASK6  */
  YYSYMBOL_KW_REWRITE = 140,               /* KW_REWRITE  */
  YYSYMBOL_KW_CONDITION = 141,             /* KW_CONDITION  */
  YYSYMBOL_KW_VALUE = 142,                 /* KW_VALUE  */
  YYSYMBOL_KW_YES = 143,                   /* KW_YES  */
  YYSYMBOL_KW_NO = 144,                    /* KW_NO  */
  YYSYMBOL_KW_AUTO = 145,                  /* KW_AUTO  */
  YYSYMBOL_KW_IFDEF = 146,                 /* KW_IFDEF  */
  YYSYMBOL_KW_ENDIF = 147,                 /* KW_ENDIF  */
  YYSYMBOL_LL_DOTDOT = 148,                /* LL_DOTDOT  */
  YYSYMBOL_LL_DOTDOTDOT = 149,             /* LL_DOTDOTDOT  */
  YYSYMBOL_LL_PRAGMA = 150,                /* LL_PRAGMA  */
  YYSYMBOL_LL_EOL = 151,                   /* LL_EOL  */
  YYSYMBOL_LL_ERROR = 152,                 /* LL_ERROR  */
  YYSYMBOL_LL_ARROW = 153,                 /* LL_ARROW  */
  YYSYMBOL_LL_IDENTIFIER = 154,            /* LL_IDENTIFIER  */
  YYSYMBOL_LL_NUMBER = 155,                /* LL_NUMBER  */
  YYSYMBOL_LL_FLOAT = 156,                 /* LL_FLOAT  */
  YYSYMBOL_LL_STRING = 157,                /* LL_STRING  */
  YYSYMBOL_LL_TOKEN = 158,                 /* LL_TOKEN  */
  YYSYMBOL_LL_BLOCK = 159,                 /* LL_BLOCK  */
  YYSYMBOL_LL_PLUGIN = 160,                /* LL_PLUGIN  */
  YYSYMBOL_KW_VALUE_PAIRS = 161,           /* KW_VALUE_PAIRS  */
  YYSYMBOL_KW_EXCLUDE = 162,               /* KW_EXCLUDE  */
  YYSYMBOL_KW_PAIR = 163,                  /* KW_PAIR  */
  YYSYMBOL_KW_KEY = 164,                   /* KW_KEY  */
  YYSYMBOL_KW_SCOPE = 165,                 /* KW_SCOPE  */
  YYSYMBOL_KW_SHIFT = 166,                 /* KW_SHIFT  */
  YYSYMBOL_KW_SHIFT_LEVELS = 167,          /* KW_SHIFT_LEVELS  */
  YYSYMBOL_KW_REKEY = 168,                 /* KW_REKEY  */
  YYSYMBOL_KW_ADD_PREFIX = 169,            /* KW_ADD_PREFIX  */
  YYSYMBOL_KW_REPLACE_PREFIX = 170,        /* KW_REPLACE_PREFIX  */
  YYSYMBOL_KW_CAST = 171,                  /* KW_CAST  */
  YYSYMBOL_KW_UPPER = 172,                 /* KW_UPPER  */
  YYSYMBOL_KW_LOWER = 173,                 /* KW_LOWER  */
  YYSYMBOL_KW_INCLUDE_BYTES = 174,         /* KW_INCLUDE_BYTES  */
  YYSYMBOL_KW_ON_ERROR = 175,              /* KW_ON_ERROR  */
  YYSYMBOL_KW_RETRIES = 176,               /* KW_RETRIES  */
  YYSYMBOL_KW_FETCH_NO_DATA_DELAY = 177,   /* KW_FETCH_NO_DATA_DELAY  */
  YYSYMBOL_KW_OPENTELEMETRY = 178,         /* KW_OPENTELEMETRY  */
  YYSYMBOL_KW_AUTH = 179,                  /* KW_AUTH  */
  YYSYMBOL_KW_INSECURE = 180,              /* KW_INSECURE  */
  YYSYMBOL_KW_TLS = 181,                   /* KW_TLS  */
  YYSYMBOL_KW_KEY_FILE = 182,              /* KW_KEY_FILE  */
  YYSYMBOL_KW_CERT_FILE = 183,             /* KW_CERT_FILE  */
  YYSYMBOL_KW_CA_FILE = 184,               /* KW_CA_FILE  */
  YYSYMBOL_KW_PEER_VERIFY = 185,           /* KW_PEER_VERIFY  */
  YYSYMBOL_KW_OPTIONAL_UNTRUSTED = 186,    /* KW_OPTIONAL_UNTRUSTED  */
  YYSYMBOL_KW_OPTIONAL_TRUSTED = 187,      /* KW_OPTIONAL_TRUSTED  */
  YYSYMBOL_KW_REQUIRED_UNTRUSTED = 188,    /* KW_REQUIRED_UNTRUSTED  */
  YYSYMBOL_KW_REQUIRED_TRUSTED = 189,      /* KW_REQUIRED_TRUSTED  */
  YYSYMBOL_KW_ALTS = 190,                  /* KW_ALTS  */
  YYSYMBOL_KW_URL = 191,                   /* KW_URL  */
  YYSYMBOL_KW_TARGET_SERVICE_ACCOUNTS = 192, /* KW_TARGET_SERVICE_ACCOUNTS  */
  YYSYMBOL_KW_ADC = 193,                   /* KW_ADC  */
  YYSYMBOL_194_ = 194,                     /* '('  */
  YYSYMBOL_195_ = 195,                     /* ')'  */
  YYSYMBOL_196_ = 196,                     /* '{'  */
  YYSYMBOL_197_ = 197,                     /* '}'  */
  YYSYMBOL_198_ = 198,                     /* ';'  */
  YYSYMBOL_199_ = 199,                     /* ':'  */
  YYSYMBOL_YYACCEPT = 200,                 /* $accept  */
  YYSYMBOL_start = 201,                    /* start  */
  YYSYMBOL_source_otel = 202,              /* source_otel  */
  YYSYMBOL_203_1 = 203,                    /* $@1  */
  YYSYMBOL_source_otel_options = 204,      /* source_otel_options  */
  YYSYMBOL_source_otel_option = 205,       /* source_otel_option  */
  YYSYMBOL_206_2 = 206,                    /* $@2  */
  YYSYMBOL_source_otel_auth_option = 207,  /* source_otel_auth_option  */
  YYSYMBOL_208_3 = 208,                    /* $@3  */
  YYSYMBOL_209_4 = 209,                    /* $@4  */
  YYSYMBOL_210_5 = 210,                    /* $@5  */
  YYSYMBOL_source_otel_auth_tls_options = 211, /* source_otel_auth_tls_options  */
  YYSYMBOL_source_otel_auth_tls_option = 212, /* source_otel_auth_tls_option  */
  YYSYMBOL_source_otel_auth_tls_peer_verify = 213, /* source_otel_auth_tls_peer_verify  */
  YYSYMBOL_parser_otel = 214,              /* parser_otel  */
  YYSYMBOL_215_6 = 215,                    /* $@6  */
  YYSYMBOL_parser_otel_options = 216,      /* parser_otel_options  */
  YYSYMBOL_parser_otel_option = 217,       /* parser_otel_option  */
  YYSYMBOL_destination_otel = 218,         /* destination_otel  */
  YYSYMBOL_219_7 = 219,                    /* $@7  */
  YYSYMBOL_destination_otel_options = 220, /* destination_otel_options  */
  YYSYMBOL_destination_otel_option = 221,  /* destination_otel_option  */
  YYSYMBOL_222_8 = 222,                    /* $@8  */
  YYSYMBOL_destination_otel_auth_option = 223, /* destination_otel_auth_option  */
  YYSYMBOL_224_9 = 224,                    /* $@9  */
  YYSYMBOL_225_10 = 225,                   /* $@10  */
  YYSYMBOL_226_11 = 226,                   /* $@11  */
  YYSYMBOL_227_12 = 227,                   /* $@12  */
  YYSYMBOL_destination_otel_auth_tls_options = 228, /* destination_otel_auth_tls_options  */
  YYSYMBOL_destination_otel_auth_tls_option = 229, /* destination_otel_auth_tls_option  */
  YYSYMBOL_destination_otel_auth_alts_options = 230, /* destination_otel_auth_alts_options  */
  YYSYMBOL_destination_otel_auth_alts_option = 231, /* destination_otel_auth_alts_option  */
  YYSYMBOL_destination_otel_auth_alts_target_service_accounts = 232, /* destination_otel_auth_alts_target_service_accounts  */
  YYSYMBOL_233_13 = 233,                   /* $@13  */
  YYSYMBOL_string = 234,                   /* string  */
  YYSYMBOL_yesno_strict = 235,             /* yesno_strict  */
  YYSYMBOL_yesno = 236,                    /* yesno  */
  YYSYMBOL_dnsmode = 237,                  /* dnsmode  */
  YYSYMBOL_nonnegative_integer64 = 238,    /* nonnegative_integer64  */
  YYSYMBOL_nonnegative_integer = 239,      /* nonnegative_integer  */
  YYSYMBOL_positive_integer64 = 240,       /* positive_integer64  */
  YYSYMBOL_positive_integer = 241,         /* positive_integer  */
  YYSYMBOL_string_list = 242,              /* string_list  */
  YYSYMBOL_string_list_build = 243,        /* string_list_build  */
  YYSYMBOL_severity_string = 244,          /* severity_string  */
  YYSYMBOL_facility_string = 245,          /* facility_string  */
  YYSYMBOL_parser_opt = 246,               /* parser_opt  */
  YYSYMBOL_driver_option = 247,            /* driver_option  */
  YYSYMBOL_inner_source = 248,             /* inner_source  */
  YYSYMBOL_source_driver_option = 249,     /* source_driver_option  */
  YYSYMBOL_inner_dest = 250,               /* inner_dest  */
  YYSYMBOL_dest_driver_option = 251,       /* dest_driver_option  */
  YYSYMBOL_threaded_dest_driver_batch_option = 252, /* threaded_dest_driver_batch_option  */
  YYSYMBOL_threaded_dest_driver_workers_option = 253, /* threaded_dest_driver_workers_option  */
  YYSYMBOL_threaded_dest_driver_general_option = 254, /* threaded_dest_driver_general_option  */
  YYSYMBOL_threaded_source_driver_option = 255, /* threaded_source_driver_option  */
  YYSYMBOL_256_17 = 256,                   /* $@17  */
  YYSYMBOL_257_18 = 257,                   /* $@18  */
  YYSYMBOL_threaded_source_driver_option_flags = 258, /* threaded_source_driver_option_flags  */
  YYSYMBOL_source_option = 259,            /* source_option  */
  YYSYMBOL_260_19 = 260,                   /* $@19  */
  YYSYMBOL_host_resolve_option = 261,      /* host_resolve_option  */
  YYSYMBOL_msg_format_option = 262,        /* msg_format_option  */
  YYSYMBOL__inner_dest_context_push = 263, /* _inner_dest_context_push  */
  YYSYMBOL__inner_dest_context_pop = 264,  /* _inner_dest_context_pop  */
  YYSYMBOL__inner_src_context_push = 265,  /* _inner_src_context_push  */
  YYSYMBOL__inner_src_context_pop = 266    /* _inner_src_context_pop  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;



/* Unqualified %code blocks.  */
#line 28 "modules/grpc/otel/otel-grammar.y"


#include "cfg-grammar-internal.h"
#include "plugin.h"
#include "syslog-names.h"
#include "otel-source.h"
#include "otel-protobuf-parser.h"
#include "otel-dest.h"

GrpcServerCredentialsBuilderW *last_grpc_server_credentials_builder;
GrpcClientCredentialsBuilderW *last_grpc_client_credentials_builder;

#line 60 "modules/grpc/otel/otel-grammar.y"


# define YYLLOC_DEFAULT(Current, Rhs, N)                                \
  do {                                                                  \
    if (N)                                                              \
      {                                                                 \
        (Current).name         = YYRHSLOC(Rhs, 1).name;                 \
        (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;          \
        (Current).first_column = YYRHSLOC (Rhs, 1).first_column;        \
        (Current).last_line    = YYRHSLOC (Rhs, N).last_line;           \
        (Current).last_column  = YYRHSLOC (Rhs, N).last_column;         \
      }                                                                 \
    else                                                                \
      {                                                                 \
        (Current).name         = YYRHSLOC(Rhs, 0).name;                 \
        (Current).first_line   = (Current).last_line   =                \
          YYRHSLOC (Rhs, 0).last_line;                                  \
        (Current).first_column = (Current).last_column =                \
          YYRHSLOC (Rhs, 0).last_column;                                \
      }                                                                 \
  } while (0)

#define CHECK_ERROR_WITHOUT_MESSAGE(val, token) do {                    \
    if (!(val))                                                         \
      {                                                                 \
        YYERROR;                                                        \
      }                                                                 \
  } while (0)

#define CHECK_ERROR(val, token, errorfmt, ...) do {                     \
    if (!(val))                                                         \
      {                                                                 \
        if (errorfmt)                                                   \
          {                                                             \
            gchar __buf[256];                                           \
            g_snprintf(__buf, sizeof(__buf), errorfmt, ## __VA_ARGS__); \
            yyerror(& (token), lexer, NULL, NULL, __buf);               \
          }                                                             \
        YYERROR;                                                        \
      }                                                                 \
  } while (0)

#define CHECK_ERROR_GERROR(val, token, error, errorfmt, ...) do {       \
    if (!(val))                                                         \
      {                                                                 \
        if (errorfmt)                                                   \
          {                                                             \
            gchar __buf[256];                                           \
            g_snprintf(__buf, sizeof(__buf), errorfmt ", error=%s", ## __VA_ARGS__, error->message); \
            yyerror(& (token), lexer, NULL, NULL, __buf);               \
          }                                                             \
        g_clear_error(&error);						\
        YYERROR;                                                        \
      }                                                                 \
  } while (0)

#define YYMAXDEPTH 20000



#line 894 "modules/grpc/otel/otel-grammar.c"

#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_int16 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if 1

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* 1 */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined OTEL_LTYPE_IS_TRIVIAL && OTEL_LTYPE_IS_TRIVIAL \
             && defined OTEL_STYPE_IS_TRIVIAL && OTEL_STYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
  YYLTYPE yyls_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE) \
             + YYSIZEOF (YYLTYPE)) \
      + 2 * YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  11
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   242

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  200
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  67
/* YYNRULES -- Number of rules.  */
#define YYNRULES  131
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  291

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   10539


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_uint8 yytranslate[] =
{
       0,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     194,   195,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,   199,   198,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   196,     2,   197,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,     2,     2,     2,     2,     2,     2,     2,
      37,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      38,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    39,    40,    41,    42,    43,    44,    45,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      65,    66,    67,    68,    69,    70,     2,     2,     2,     2,
      71,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      72,    73,    74,     2,     2,     2,     2,     2,     2,     2,
      75,    76,     2,     2,     2,     2,     2,     2,     2,     2,
      77,    78,    79,     2,     2,     2,     2,     2,     2,     2,
      80,    81,    82,     2,     2,     2,     2,     2,     2,     2,
      83,    84,    85,     2,     2,     2,     2,     2,     2,     2,
      86,     2,    87,    88,    89,    90,    91,     2,     2,     2,
      92,    93,     2,     2,     2,     2,     2,     2,     2,     2,
      94,    95,    96,    97,     2,     2,     2,     2,     2,     2,
      98,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
     109,   110,   111,   112,   113,   114,     2,     2,     2,     2,
     115,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     116,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     117,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     118,   119,   120,     2,     2,     2,     2,     2,     2,     2,
     121,   122,   123,     2,     2,     2,     2,     2,     2,     2,
     124,   125,   126,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     127,   128,   129,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   130,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     131,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     132,   133,   134,   135,   136,   137,   138,   139,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     140,   141,   142,     2,     2,     2,     2,     2,     2,     2,
     143,   144,   145,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      58,    59,    60,    61,    62,    63,    64,     2,     2,     2,
     146,   147,     2,     2,     2,     2,     2,     2,     2,     2,
     148,   149,   150,   151,   152,   153,     2,     2,     2,     2,
     154,   155,   156,   157,   158,   159,   160,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     161,     2,   162,   163,   164,   165,   166,   167,   168,   169,
     170,   171,   172,   173,   174,     2,     2,     2,     2,     2,
     175,   176,   177,     2,   178,   179,   180,   181,   182,   183,
     184,   185,   186,   187,   188,   189,   190,   191,   192,   193
};

#if OTEL_DEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   452,   452,   453,   454,   459,   458,   466,   467,   471,
     472,   472,   473,   477,   477,   478,   478,   479,   479,   483,
     484,   488,   493,   498,   503,   510,   511,   512,   513,   518,
     517,   525,   526,   530,   535,   534,   542,   543,   547,   548,
     548,   549,   550,   551,   555,   555,   556,   556,   557,   557,
     558,   558,   562,   563,   567,   572,   577,   585,   586,   590,
     595,   594,   600,   913,   914,   918,   919,   923,   924,   934,
     935,   939,   946,   953,   960,  1026,  1030,  1031,  1040,  1051,
    1059,  1063,  1072,  1076,  1077,  1081,  1108,  1109,  1113,  1141,
    1142,  1143,  1144,  1148,  1149,  1153,  1158,  1162,  1163,  1168,
    1169,  1170,  1170,  1171,  1171,  1172,  1181,  1186,  1192,  1193,
    1194,  1195,  1196,  1197,  1198,  1199,  1200,  1201,  1202,  1202,
    1238,  1239,  1240,  1241,  1245,  1246,  1252,  1258,  1483,  1484,
    1485,  1486
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if 1
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "LL_CONTEXT_ROOT",
  "LL_CONTEXT_DESTINATION", "LL_CONTEXT_SOURCE", "LL_CONTEXT_PARSER",
  "LL_CONTEXT_REWRITE", "LL_CONTEXT_FILTER", "LL_CONTEXT_LOG",
  "LL_CONTEXT_BLOCK_DEF", "LL_CONTEXT_BLOCK_REF",
  "LL_CONTEXT_BLOCK_CONTENT", "LL_CONTEXT_BLOCK_ARG", "LL_CONTEXT_PRAGMA",
  "LL_CONTEXT_FORMAT", "LL_CONTEXT_TEMPLATE_FUNC", "LL_CONTEXT_INNER_DEST",
  "LL_CONTEXT_INNER_SRC", "LL_CONTEXT_CLIENT_PROTO",
  "LL_CONTEXT_SERVER_PROTO", "LL_CONTEXT_OPTIONS", "LL_CONTEXT_CONFIG",
  "LL_CONTEXT_MAX", "KW_SOURCE", "KW_FILTER", "KW_PARSER",
  "KW_DESTINATION", "KW_LOG", "KW_OPTIONS", "KW_INCLUDE", "KW_BLOCK",
  "KW_JUNCTION", "KW_CHANNEL", "KW_IF", "KW_ELSE", "KW_ELIF",
  "KW_INTERNAL", "KW_SYSLOG", "KW_MARK_FREQ", "KW_STATS_FREQ",
  "KW_STATS_LEVEL", "KW_STATS_LIFETIME", "KW_FLUSH_LINES", "KW_SUPPRESS",
  "KW_FLUSH_TIMEOUT", "KW_LOG_MSG_SIZE", "KW_FILE_TEMPLATE",
  "KW_PROTO_TEMPLATE", "KW_MARK_MODE", "KW_ENCODING", "KW_TYPE",
  "KW_STATS_MAX_DYNAMIC", "KW_MIN_IW_SIZE_PER_READER", "KW_WORKERS",
  "KW_BATCH_LINES", "KW_BATCH_TIMEOUT", "KW_TRIM_LARGE_MESSAGES",
  "KW_STATS", "KW_FREQ", "KW_LEVEL", "KW_LIFETIME", "KW_MAX_DYNAMIC",
  "KW_SYSLOG_STATS", "KW_HEALTHCHECK_FREQ", "KW_CHAIN_HOSTNAMES",
  "KW_NORMALIZE_HOSTNAMES", "KW_KEEP_HOSTNAME", "KW_CHECK_HOSTNAME",
  "KW_BAD_HOSTNAME", "KW_LOG_LEVEL", "KW_KEEP_TIMESTAMP", "KW_USE_DNS",
  "KW_USE_FQDN", "KW_CUSTOM_DOMAIN", "KW_DNS_CACHE", "KW_DNS_CACHE_SIZE",
  "KW_DNS_CACHE_EXPIRE", "KW_DNS_CACHE_EXPIRE_FAILED",
  "KW_DNS_CACHE_HOSTS", "KW_PERSIST_ONLY", "KW_USE_RCPTID",
  "KW_USE_UNIQID", "KW_TZ_CONVERT", "KW_TS_FORMAT", "KW_FRAC_DIGITS",
  "KW_LOG_FIFO_SIZE", "KW_LOG_FETCH_LIMIT", "KW_LOG_IW_SIZE",
  "KW_LOG_PREFIX", "KW_PROGRAM_OVERRIDE", "KW_HOST_OVERRIDE",
  "KW_THROTTLE", "KW_THREADED", "KW_PASS_UNIX_CREDENTIALS",
  "KW_PERSIST_NAME", "KW_READ_OLD_RECORDS", "KW_USE_SYSLOGNG_PID",
  "KW_FLAGS", "KW_PAD_SIZE", "KW_TIME_ZONE", "KW_RECV_TIME_ZONE",
  "KW_SEND_TIME_ZONE", "KW_LOCAL_TIME_ZONE", "KW_FORMAT",
  "KW_MULTI_LINE_MODE", "KW_MULTI_LINE_PREFIX", "KW_MULTI_LINE_GARBAGE",
  "KW_TRUNCATE_SIZE", "KW_TIME_REOPEN", "KW_TIME_REAP", "KW_TIME_SLEEP",
  "KW_PARTITIONS", "KW_PARTITION_KEY", "KW_PARALLELIZE", "KW_TMPL_ESCAPE",
  "KW_OPTIONAL", "KW_CREATE_DIRS", "KW_OWNER", "KW_GROUP", "KW_PERM",
  "KW_DIR_OWNER", "KW_DIR_GROUP", "KW_DIR_PERM", "KW_TEMPLATE",
  "KW_TEMPLATE_ESCAPE", "KW_TEMPLATE_FUNCTION", "KW_DEFAULT_FACILITY",
  "KW_DEFAULT_SEVERITY", "KW_SDATA_PREFIX", "KW_PORT", "KW_USE_TIME_RECVD",
  "KW_FACILITY", "KW_SEVERITY", "KW_HOST", "KW_MATCH", "KW_MESSAGE",
  "KW_NETMASK", "KW_TAGS", "KW_NETMASK6", "KW_REWRITE", "KW_CONDITION",
  "KW_VALUE", "KW_YES", "KW_NO", "KW_AUTO", "KW_IFDEF", "KW_ENDIF",
  "LL_DOTDOT", "LL_DOTDOTDOT", "LL_PRAGMA", "LL_EOL", "LL_ERROR",
  "LL_ARROW", "LL_IDENTIFIER", "LL_NUMBER", "LL_FLOAT", "LL_STRING",
  "LL_TOKEN", "LL_BLOCK", "LL_PLUGIN", "KW_VALUE_PAIRS", "KW_EXCLUDE",
  "KW_PAIR", "KW_KEY", "KW_SCOPE", "KW_SHIFT", "KW_SHIFT_LEVELS",
  "KW_REKEY", "KW_ADD_PREFIX", "KW_REPLACE_PREFIX", "KW_CAST", "KW_UPPER",
  "KW_LOWER", "KW_INCLUDE_BYTES", "KW_ON_ERROR", "KW_RETRIES",
  "KW_FETCH_NO_DATA_DELAY", "KW_OPENTELEMETRY", "KW_AUTH", "KW_INSECURE",
  "KW_TLS", "KW_KEY_FILE", "KW_CERT_FILE", "KW_CA_FILE", "KW_PEER_VERIFY",
  "KW_OPTIONAL_UNTRUSTED", "KW_OPTIONAL_TRUSTED", "KW_REQUIRED_UNTRUSTED",
  "KW_REQUIRED_TRUSTED", "KW_ALTS", "KW_URL", "KW_TARGET_SERVICE_ACCOUNTS",
  "KW_ADC", "'('", "')'", "'{'", "'}'", "';'", "':'", "$accept", "start",
  "source_otel", "$@1", "source_otel_options", "source_otel_option", "$@2",
  "source_otel_auth_option", "$@3", "$@4", "$@5",
  "source_otel_auth_tls_options", "source_otel_auth_tls_option",
  "source_otel_auth_tls_peer_verify", "parser_otel", "$@6",
  "parser_otel_options", "parser_otel_option", "destination_otel", "$@7",
  "destination_otel_options", "destination_otel_option", "$@8",
  "destination_otel_auth_option", "$@9", "$@10", "$@11", "$@12",
  "destination_otel_auth_tls_options", "destination_otel_auth_tls_option",
  "destination_otel_auth_alts_options",
  "destination_otel_auth_alts_option",
  "destination_otel_auth_alts_target_service_accounts", "$@13", "string",
  "yesno_strict", "yesno", "dnsmode", "nonnegative_integer64",
  "nonnegative_integer", "positive_integer64", "positive_integer",
  "string_list", "string_list_build", "severity_string", "facility_string",
  "parser_opt", "driver_option", "inner_source", "source_driver_option",
  "inner_dest", "dest_driver_option", "threaded_dest_driver_batch_option",
  "threaded_dest_driver_workers_option",
  "threaded_dest_driver_general_option", "threaded_source_driver_option",
  "$@17", "$@18", "threaded_source_driver_option_flags", "source_option",
  "$@19", "host_resolve_option", "msg_format_option",
  "_inner_dest_context_push", "_inner_dest_context_pop",
  "_inner_src_context_push", "_inner_src_context_pop", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-178)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-102)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
      61,  -167,  -148,  -147,    22,  -178,  -178,  -178,  -178,  -178,
    -178,  -178,  -158,  -150,  -149,  -178,  -178,   -27,   -35,   -36,
    -145,  -144,  -141,   -27,  -178,  -138,  -136,  -133,  -121,  -114,
    -113,   -92,   -91,  -178,   -90,  -178,   -89,  -178,   -35,  -178,
    -178,  -178,  -178,  -178,  -178,   -88,   -84,   -82,  -178,  -178,
    -178,   -36,  -178,  -178,  -178,  -178,   -86,    42,  -128,  -131,
    -178,  -178,  -128,  -108,   -47,  -108,  -108,   -47,  -131,  -108,
    -108,   -80,  -131,  -132,  -178,  -131,  -131,  -108,   -79,   -78,
    -178,   -76,   -75,   -73,   -72,  -178,   -67,   -66,   -60,   -58,
     -57,   -54,   -52,   -49,   -48,   -43,  -178,   -20,  -178,  -178,
    -178,  -178,   -69,  -178,  -178,   -42,   -41,  -178,  -178,   -40,
    -178,  -178,   -38,   -33,   -32,   -31,   -30,   -29,   -28,  -156,
     -26,  -178,  -131,   -25,   -24,   -23,  -142,  -178,  -131,   -34,
    -131,  -131,  -128,  -128,  -128,  -108,  -131,  -131,  -131,  -128,
    -128,  -131,   -21,   -19,   -18,   -17,  -178,  -178,  -178,  -178,
    -178,  -178,  -178,  -178,  -178,  -178,  -178,  -178,  -178,  -178,
    -178,  -178,   -14,  -178,  -178,  -178,  -178,  -178,  -178,  -178,
    -178,   -13,   -12,  -178,  -178,   -11,  -178,   -10,    -9,    -8,
      -7,    -6,    -5,    -4,    -3,    -2,    -1,     3,  -131,     4,
    -178,  -128,   -68,  -128,  -128,   -15,     7,     8,    12,  -178,
      13,    14,    15,  -178,  -178,  -178,  -178,  -178,  -178,  -178,
    -178,  -178,  -178,  -178,  -178,  -178,  -178,  -178,  -178,    16,
    -178,  -178,    17,    18,    19,    20,   -83,   -81,    21,    23,
    -177,    24,  -178,  -178,  -178,  -178,  -178,    26,    27,    28,
      29,   -83,    31,    32,   -81,  -178,  -178,    34,    35,    36,
      37,    38,  -177,  -178,  -131,  -131,  -131,  -178,  -178,  -131,
    -178,  -178,  -131,  -131,  -131,  -103,  -178,  -178,    39,    40,
      41,    43,  -178,    44,    45,    46,  -178,  -178,  -178,  -178,
      47,  -178,  -178,  -178,  -178,  -131,  -178,  -178,  -178,  -178,
    -178
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,     0,     0,     0,     0,    34,     4,     5,     2,    29,
       3,     1,     0,     0,     0,   128,   130,    32,    37,   103,
       0,     0,     0,    32,    33,     0,     0,     0,     0,     0,
       0,     0,     0,    88,     0,    39,     0,   129,    37,    92,
      91,    98,    42,    43,    41,     0,     0,     0,    85,    10,
     131,   103,    87,    86,   105,    12,     0,   118,     0,     0,
      30,    31,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    36,   107,     0,     0,     0,     0,
       7,     0,     0,     0,     0,   102,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   104,     0,    65,    66,
      68,    67,     0,    63,    64,     0,     0,    73,    74,     0,
      71,    72,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    35,   107,     0,     0,     0,     0,     6,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    77,     0,     0,     0,     0,   119,    82,    81,    84,
      95,    93,    94,    89,    90,    83,    97,    96,    44,    46,
      48,    50,     0,    38,   106,   100,    99,     9,    13,    15,
      17,     0,     0,    80,    79,     0,    78,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    77,     0,
      75,     0,     0,     0,     0,     0,     0,     0,     0,    40,
       0,     0,     0,    11,   124,   126,   125,   127,   109,   110,
     114,   108,   113,   111,   112,   115,   116,    76,   117,     0,
      70,    69,     0,     0,     0,     0,    53,    58,     0,     0,
      20,     0,   123,   121,   120,   122,    45,     0,     0,     0,
       0,    53,     0,     0,    58,    51,    14,     0,     0,     0,
       0,     0,    20,    18,     0,     0,     0,    47,    52,    62,
      49,    57,     0,     0,     0,     0,    16,    19,     0,     0,
       0,     0,    60,     0,     0,     0,    25,    26,    27,    28,
       0,    54,    55,    56,    59,    62,    21,    22,    23,    24,
      61
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -178,  -178,  -178,  -178,    65,  -178,  -178,  -178,  -178,  -178,
    -178,  -117,  -178,  -178,  -178,  -178,   129,  -178,  -178,  -178,
     120,  -178,  -178,  -178,  -178,  -178,  -178,  -178,   -63,  -178,
     -70,  -178,  -125,  -178,   -59,  -178,   -44,  -178,  -178,    94,
    -178,   -37,  -178,    49,  -178,  -178,  -178,   -16,  -178,  -178,
    -178,  -178,  -178,  -178,  -178,  -178,  -178,  -178,    88,  -178,
    -178,  -178,  -178,  -178,  -178,  -178,  -178
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
       0,     4,     8,    13,    50,    51,    78,   171,   200,   201,
     202,   251,   252,   280,    10,    14,    22,    23,     6,    12,
      37,    38,    71,   162,   195,   196,   197,   198,   240,   241,
     243,   244,   271,   285,   122,   101,   102,   222,   111,   112,
     108,   109,   189,   190,   177,   175,    24,    39,    53,    54,
      40,    41,    42,    43,    44,    55,    56,    57,   123,    96,
      97,   146,    85,    18,    73,    19,    79
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
     105,    25,    25,    52,   173,   247,   248,   249,   250,   116,
      20,     5,   220,   120,    81,    98,    99,   124,   106,    26,
      27,    28,    11,   103,   158,   159,   104,   100,   113,   114,
       7,     9,   117,   118,   160,    52,    15,   161,   168,   169,
     125,    82,    83,    84,    16,    17,   142,   107,   170,    58,
      59,    29,   143,   144,    60,   145,    62,    30,    63,    31,
      31,    64,    45,   121,  -101,     1,     2,     3,    46,   172,
     174,   176,   178,    65,    32,    98,    99,   183,   184,   185,
      66,    67,   188,   276,   277,   278,   279,   100,   179,   180,
     181,  -101,  -101,  -101,    47,   186,   187,    21,   182,   237,
     238,   239,    68,    69,    70,    72,    75,    86,   110,    87,
      76,   242,    77,    88,   119,   126,    80,   127,   128,   129,
     103,   130,   131,   104,    48,    33,   147,   132,   133,   188,
      89,    90,    91,    92,   134,   267,   135,   136,    93,    94,
     137,    34,   138,    49,    35,   139,   140,   219,   221,   223,
     224,   141,    61,   148,   149,   150,    36,   151,    74,    -8,
     290,   115,   152,   153,   154,   155,   156,   157,     0,   163,
     165,   166,   167,   191,   261,   192,   193,   194,   258,   225,
      95,   199,   203,   204,   205,   206,   207,   208,   209,   210,
     211,   212,   213,   214,   215,   268,   269,   270,   216,   218,
     272,   226,   227,   273,   274,   275,   228,   229,   230,   231,
     164,   232,   233,   234,   235,   236,   245,     0,   246,   253,
     254,   255,   256,     0,   257,   259,   272,   260,   262,   263,
     264,   265,     0,   266,   281,   282,   283,   217,   284,   286,
     287,   288,   289
};

static const yytype_int16 yycheck[] =
{
      59,    37,    37,    19,    38,   182,   183,   184,   185,    68,
      37,   178,    80,    72,   100,   143,   144,    76,    62,    54,
      55,    56,     0,   154,   180,   181,   157,   155,    65,    66,
     178,   178,    69,    70,   190,    51,   194,   193,   180,   181,
      77,   127,   128,   129,   194,   194,    66,   155,   190,   194,
     194,    86,    72,    73,   195,    75,   194,    92,   194,    95,
      95,   194,    98,   195,   100,     4,     5,     6,   104,   128,
     129,   130,   131,   194,   109,   143,   144,   136,   137,   138,
     194,   194,   141,   186,   187,   188,   189,   155,   132,   133,
     134,   127,   128,   129,   130,   139,   140,   124,   135,   182,
     183,   184,   194,   194,   194,   194,   194,    65,   155,    67,
     194,   192,   194,    71,   194,   194,    51,   195,   194,   194,
     154,   194,   194,   157,   160,   160,   195,   194,   194,   188,
      88,    89,    90,    91,   194,   252,   194,   194,    96,    97,
     194,   176,   194,   179,   179,   194,   194,   191,   192,   193,
     194,   194,    23,   195,   195,   195,   191,   195,    38,   195,
     285,    67,   195,   195,   195,   195,   195,   195,    -1,   195,
     195,   195,   195,   194,   244,   194,   194,   194,   241,   194,
     138,   195,   195,   195,   195,   195,   195,   195,   195,   195,
     195,   195,   195,   195,   195,   254,   255,   256,   195,   195,
     259,   194,   194,   262,   263,   264,   194,   194,   194,   194,
     122,   195,   195,   195,   195,   195,   195,    -1,   195,   195,
     194,   194,   194,    -1,   195,   194,   285,   195,   194,   194,
     194,   194,    -1,   195,   195,   195,   195,   188,   195,   195,
     195,   195,   195
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int16 yystos[] =
{
       0,     4,     5,     6,   201,   178,   218,   178,   202,   178,
     214,     0,   219,   203,   215,   194,   194,   194,   263,   265,
      37,   124,   216,   217,   246,    37,    54,    55,    56,    86,
      92,    95,   109,   160,   176,   179,   191,   220,   221,   247,
     250,   251,   252,   253,   254,    98,   104,   130,   160,   179,
     204,   205,   247,   248,   249,   255,   256,   257,   194,   194,
     195,   216,   194,   194,   194,   194,   194,   194,   194,   194,
     194,   222,   194,   264,   220,   194,   194,   194,   206,   266,
     204,   100,   127,   128,   129,   262,    65,    67,    71,    88,
      89,    90,    91,    96,    97,   138,   259,   260,   143,   144,
     155,   235,   236,   154,   157,   234,   236,   155,   240,   241,
     155,   238,   239,   241,   241,   239,   234,   241,   241,   194,
     234,   195,   234,   258,   234,   241,   194,   195,   194,   194,
     194,   194,   194,   194,   194,   194,   194,   194,   194,   194,
     194,   194,    66,    72,    73,    75,   261,   195,   195,   195,
     195,   195,   195,   195,   195,   195,   195,   195,   180,   181,
     190,   193,   223,   195,   258,   195,   195,   195,   180,   181,
     190,   207,   234,    38,   234,   245,   234,   244,   234,   236,
     236,   236,   241,   234,   234,   234,   236,   236,   234,   242,
     243,   194,   194,   194,   194,   224,   225,   226,   227,   195,
     208,   209,   210,   195,   195,   195,   195,   195,   195,   195,
     195,   195,   195,   195,   195,   195,   195,   243,   195,   236,
      80,   236,   237,   236,   236,   194,   194,   194,   194,   194,
     194,   194,   195,   195,   195,   195,   195,   182,   183,   184,
     228,   229,   192,   230,   231,   195,   195,   182,   183,   184,
     185,   211,   212,   195,   194,   194,   194,   195,   228,   194,
     195,   230,   194,   194,   194,   194,   195,   211,   234,   234,
     234,   232,   234,   234,   234,   234,   186,   187,   188,   189,
     213,   195,   195,   195,   195,   233,   195,   195,   195,   195,
     232
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int16 yyr1[] =
{
       0,   200,   201,   201,   201,   203,   202,   204,   204,   205,
     206,   205,   205,   208,   207,   209,   207,   210,   207,   211,
     211,   212,   212,   212,   212,   213,   213,   213,   213,   215,
     214,   216,   216,   217,   219,   218,   220,   220,   221,   222,
     221,   221,   221,   221,   224,   223,   225,   223,   226,   223,
     227,   223,   228,   228,   229,   229,   229,   230,   230,   231,
     233,   232,   232,   234,   234,   235,   235,   236,   236,   237,
     237,   238,   239,   240,   241,   242,   243,   243,   244,   245,
     245,   246,   246,   247,   247,   248,   249,   249,   250,   251,
     251,   251,   251,   252,   252,   253,   254,   254,   254,   255,
     255,   256,   255,   257,   255,   255,   258,   258,   259,   259,
     259,   259,   259,   259,   259,   259,   259,   259,   260,   259,
     261,   261,   261,   261,   262,   262,   262,   262,   263,   264,
     265,   266
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     2,     2,     2,     0,     7,     2,     0,     4,
       0,     5,     1,     0,     4,     0,     5,     0,     4,     2,
       0,     4,     4,     4,     4,     1,     1,     1,     1,     0,
       5,     2,     0,     1,     0,     7,     2,     0,     4,     0,
       5,     1,     1,     1,     0,     4,     0,     5,     0,     5,
       0,     4,     2,     0,     4,     4,     4,     2,     0,     4,
       0,     3,     0,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     2,     0,     1,     1,
       1,     4,     4,     4,     4,     1,     1,     1,     1,     4,
       4,     1,     1,     4,     4,     4,     4,     4,     1,     4,
       4,     0,     2,     0,     2,     1,     2,     0,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     0,     2,
       4,     4,     4,     4,     4,     4,     4,     4,     0,     0,
       0,     0
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = OTEL_EMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == OTEL_EMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (&yylloc, lexer, instance, arg, YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use OTEL_error or OTEL_UNDEF. */
#define YYERRCODE OTEL_UNDEF

/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)                                \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;        \
          (Current).first_column = YYRHSLOC (Rhs, 1).first_column;      \
          (Current).last_line    = YYRHSLOC (Rhs, N).last_line;         \
          (Current).last_column  = YYRHSLOC (Rhs, N).last_column;       \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).first_line   = (Current).last_line   =              \
            YYRHSLOC (Rhs, 0).last_line;                                \
          (Current).first_column = (Current).last_column =              \
            YYRHSLOC (Rhs, 0).last_column;                              \
        }                                                               \
    while (0)
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K])


/* Enable debugging if requested.  */
#if OTEL_DEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)


/* YYLOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

# ifndef YYLOCATION_PRINT

#  if defined YY_LOCATION_PRINT

   /* Temporary convenience wrapper in case some people defined the
      undocumented and private YY_LOCATION_PRINT macros.  */
#   define YYLOCATION_PRINT(File, Loc)  YY_LOCATION_PRINT(File, *(Loc))

#  elif defined OTEL_LTYPE_IS_TRIVIAL && OTEL_LTYPE_IS_TRIVIAL

/* Print *YYLOCP on YYO.  Private, do not rely on its existence. */

YY_ATTRIBUTE_UNUSED
static int
yy_location_print_ (FILE *yyo, YYLTYPE const * const yylocp)
{
  int res = 0;
  int end_col = 0 != yylocp->last_column ? yylocp->last_column - 1 : 0;
  if (0 <= yylocp->first_line)
    {
      res += YYFPRINTF (yyo, "%d", yylocp->first_line);
      if (0 <= yylocp->first_column)
        res += YYFPRINTF (yyo, ".%d", yylocp->first_column);
    }
  if (0 <= yylocp->last_line)
    {
      if (yylocp->first_line < yylocp->last_line)
        {
          res += YYFPRINTF (yyo, "-%d", yylocp->last_line);
          if (0 <= end_col)
            res += YYFPRINTF (yyo, ".%d", end_col);
        }
      else if (0 <= end_col && yylocp->first_column < end_col)
        res += YYFPRINTF (yyo, "-%d", end_col);
    }
  return res;
}

#   define YYLOCATION_PRINT  yy_location_print_

    /* Temporary convenience wrapper in case some people defined the
       undocumented and private YY_LOCATION_PRINT macros.  */
#   define YY_LOCATION_PRINT(File, Loc)  YYLOCATION_PRINT(File, &(Loc))

#  else

#   define YYLOCATION_PRINT(File, Loc) ((void) 0)
    /* Temporary convenience wrapper in case some people defined the
       undocumented and private YY_LOCATION_PRINT macros.  */
#   define YY_LOCATION_PRINT  YYLOCATION_PRINT

#  endif
# endif /* !defined YYLOCATION_PRINT */


# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value, Location, lexer, instance, arg); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp, CfgLexer *lexer, void **instance, gpointer arg)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  YY_USE (yylocationp);
  YY_USE (lexer);
  YY_USE (instance);
  YY_USE (arg);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp, CfgLexer *lexer, void **instance, gpointer arg)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  YYLOCATION_PRINT (yyo, yylocationp);
  YYFPRINTF (yyo, ": ");
  yy_symbol_value_print (yyo, yykind, yyvaluep, yylocationp, lexer, instance, arg);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp, YYLTYPE *yylsp,
                 int yyrule, CfgLexer *lexer, void **instance, gpointer arg)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)],
                       &(yylsp[(yyi + 1) - (yynrhs)]), lexer, instance, arg);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, yylsp, Rule, lexer, instance, arg); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !OTEL_DEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !OTEL_DEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


/* Context of a parse error.  */
typedef struct
{
  yy_state_t *yyssp;
  yysymbol_kind_t yytoken;
  YYLTYPE *yylloc;
} yypcontext_t;

/* Put in YYARG at most YYARGN of the expected tokens given the
   current YYCTX, and return the number of tokens stored in YYARG.  If
   YYARG is null, return the number of expected tokens (guaranteed to
   be less than YYNTOKENS).  Return YYENOMEM on memory exhaustion.
   Return 0 if there are more than YYARGN expected tokens, yet fill
   YYARG up to YYARGN. */
static int
yypcontext_expected_tokens (const yypcontext_t *yyctx,
                            yysymbol_kind_t yyarg[], int yyargn)
{
  /* Actual size of YYARG. */
  int yycount = 0;
  int yyn = yypact[+*yyctx->yyssp];
  if (!yypact_value_is_default (yyn))
    {
      /* Start YYX at -YYN if negative to avoid negative indexes in
         YYCHECK.  In other words, skip the first -YYN actions for
         this state because they are default actions.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;
      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yyx;
      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
        if (yycheck[yyx + yyn] == yyx && yyx != YYSYMBOL_YYerror
            && !yytable_value_is_error (yytable[yyx + yyn]))
          {
            if (!yyarg)
              ++yycount;
            else if (yycount == yyargn)
              return 0;
            else
              yyarg[yycount++] = YY_CAST (yysymbol_kind_t, yyx);
          }
    }
  if (yyarg && yycount == 0 && 0 < yyargn)
    yyarg[0] = YYSYMBOL_YYEMPTY;
  return yycount;
}




#ifndef yystrlen
# if defined __GLIBC__ && defined _STRING_H
#  define yystrlen(S) (YY_CAST (YYPTRDIFF_T, strlen (S)))
# else
/* Return the length of YYSTR.  */
static YYPTRDIFF_T
yystrlen (const char *yystr)
{
  YYPTRDIFF_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
# endif
#endif

#ifndef yystpcpy
# if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#  define yystpcpy stpcpy
# else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
# endif
#endif

#ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYPTRDIFF_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYPTRDIFF_T yyn = 0;
      char const *yyp = yystr;
      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            else
              goto append;

          append:
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (yyres)
    return yystpcpy (yyres, yystr) - yyres;
  else
    return yystrlen (yystr);
}
#endif


static int
yy_syntax_error_arguments (const yypcontext_t *yyctx,
                           yysymbol_kind_t yyarg[], int yyargn)
{
  /* Actual size of YYARG. */
  int yycount = 0;
  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yyctx->yytoken != YYSYMBOL_YYEMPTY)
    {
      int yyn;
      if (yyarg)
        yyarg[yycount] = yyctx->yytoken;
      ++yycount;
      yyn = yypcontext_expected_tokens (yyctx,
                                        yyarg ? yyarg + 1 : yyarg, yyargn - 1);
      if (yyn == YYENOMEM)
        return YYENOMEM;
      else
        yycount += yyn;
    }
  return yycount;
}

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return -1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return YYENOMEM if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYPTRDIFF_T *yymsg_alloc, char **yymsg,
                const yypcontext_t *yyctx)
{
  enum { YYARGS_MAX = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat: reported tokens (one for the "unexpected",
     one per "expected"). */
  yysymbol_kind_t yyarg[YYARGS_MAX];
  /* Cumulated lengths of YYARG.  */
  YYPTRDIFF_T yysize = 0;

  /* Actual size of YYARG. */
  int yycount = yy_syntax_error_arguments (yyctx, yyarg, YYARGS_MAX);
  if (yycount == YYENOMEM)
    return YYENOMEM;

  switch (yycount)
    {
#define YYCASE_(N, S)                       \
      case N:                               \
        yyformat = S;                       \
        break
    default: /* Avoid compiler warnings. */
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
    }

  /* Compute error message size.  Don't count the "%s"s, but reserve
     room for the terminator.  */
  yysize = yystrlen (yyformat) - 2 * yycount + 1;
  {
    int yyi;
    for (yyi = 0; yyi < yycount; ++yyi)
      {
        YYPTRDIFF_T yysize1
          = yysize + yytnamerr (YY_NULLPTR, yytname[yyarg[yyi]]);
        if (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM)
          yysize = yysize1;
        else
          return YYENOMEM;
      }
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return -1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yytname[yyarg[yyi++]]);
          yyformat += 2;
        }
      else
        {
          ++yyp;
          ++yyformat;
        }
  }
  return 0;
}


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep, YYLTYPE *yylocationp, CfgLexer *lexer, void **instance, gpointer arg)
{
  YY_USE (yyvaluep);
  YY_USE (yylocationp);
  YY_USE (lexer);
  YY_USE (instance);
  YY_USE (arg);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  switch (yykind)
    {
    case YYSYMBOL_LL_IDENTIFIER: /* LL_IDENTIFIER  */
#line 337 "modules/grpc/otel/otel-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3225 "modules/grpc/otel/otel-grammar.c"
        break;

    case YYSYMBOL_LL_STRING: /* LL_STRING  */
#line 337 "modules/grpc/otel/otel-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3231 "modules/grpc/otel/otel-grammar.c"
        break;

    case YYSYMBOL_LL_BLOCK: /* LL_BLOCK  */
#line 337 "modules/grpc/otel/otel-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3237 "modules/grpc/otel/otel-grammar.c"
        break;

    case YYSYMBOL_LL_PLUGIN: /* LL_PLUGIN  */
#line 337 "modules/grpc/otel/otel-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3243 "modules/grpc/otel/otel-grammar.c"
        break;

    case YYSYMBOL_string: /* string  */
#line 337 "modules/grpc/otel/otel-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3249 "modules/grpc/otel/otel-grammar.c"
        break;

      default:
        break;
    }
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}






/*----------.
| yyparse.  |
`----------*/

int
yyparse (CfgLexer *lexer, void **instance, gpointer arg)
{
/* Lookahead token kind.  */
int yychar;


/* The semantic value of the lookahead symbol.  */
/* Default value used for initialization, for pacifying older GCCs
   or non-GCC compilers.  */
YY_INITIAL_VALUE (static YYSTYPE yyval_default;)
YYSTYPE yylval YY_INITIAL_VALUE (= yyval_default);

/* Location data for the lookahead symbol.  */
static YYLTYPE yyloc_default
# if defined OTEL_LTYPE_IS_TRIVIAL && OTEL_LTYPE_IS_TRIVIAL
  = { 1, 1, 1, 1 }
# endif
;
YYLTYPE yylloc = yyloc_default;

    /* Number of syntax errors so far.  */
    int yynerrs = 0;

    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

    /* The location stack: array, bottom, top.  */
    YYLTYPE yylsa[YYINITDEPTH];
    YYLTYPE *yyls = yylsa;
    YYLTYPE *yylsp = yyls;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
  YYLTYPE yyloc;

  /* The locations where the error started and ended.  */
  YYLTYPE yyerror_range[3];

  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYPTRDIFF_T yymsg_alloc = sizeof yymsgbuf;

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N), yylsp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = OTEL_EMPTY; /* Cause a token to be read.  */

  yylsp[0] = yylloc;
  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;
        YYLTYPE *yyls1 = yyls;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yyls1, yysize * YYSIZEOF (*yylsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
        yyls = yyls1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
        YYSTACK_RELOCATE (yyls_alloc, yyls);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
      yylsp = yyls + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == OTEL_EMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex (&yylval, &yylloc, lexer);
    }

  if (yychar <= OTEL_EOF)
    {
      yychar = OTEL_EOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == OTEL_error)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = OTEL_UNDEF;
      yytoken = YYSYMBOL_YYerror;
      yyerror_range[1] = yylloc;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END
  *++yylsp = yylloc;

  /* Discard the shifted token.  */
  yychar = OTEL_EMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

  /* Default location. */
  YYLLOC_DEFAULT (yyloc, (yylsp - yylen), yylen);
  yyerror_range[1] = yyloc;
  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* start: LL_CONTEXT_SOURCE source_otel  */
#line 452 "modules/grpc/otel/otel-grammar.y"
                                  { YYACCEPT; }
#line 3555 "modules/grpc/otel/otel-grammar.c"
    break;

  case 3: /* start: LL_CONTEXT_PARSER parser_otel  */
#line 453 "modules/grpc/otel/otel-grammar.y"
                                  { YYACCEPT; }
#line 3561 "modules/grpc/otel/otel-grammar.c"
    break;

  case 4: /* start: LL_CONTEXT_DESTINATION destination_otel  */
#line 454 "modules/grpc/otel/otel-grammar.y"
                                            { YYACCEPT; }
#line 3567 "modules/grpc/otel/otel-grammar.c"
    break;

  case 5: /* $@1: %empty  */
#line 459 "modules/grpc/otel/otel-grammar.y"
    {
      last_driver = *instance = otel_sd_new(configuration);
    }
#line 3575 "modules/grpc/otel/otel-grammar.c"
    break;

  case 6: /* source_otel: KW_OPENTELEMETRY $@1 '(' _inner_src_context_push source_otel_options _inner_src_context_pop ')'  */
#line 462 "modules/grpc/otel/otel-grammar.y"
                                                                               { (yyval.ptr) = last_driver; }
#line 3581 "modules/grpc/otel/otel-grammar.c"
    break;

  case 9: /* source_otel_option: KW_PORT '(' positive_integer ')'  */
#line 471 "modules/grpc/otel/otel-grammar.y"
                                     { otel_sd_set_port(last_driver, (yyvsp[-1].num)); }
#line 3587 "modules/grpc/otel/otel-grammar.c"
    break;

  case 10: /* $@2: %empty  */
#line 472 "modules/grpc/otel/otel-grammar.y"
            { last_grpc_server_credentials_builder = otel_sd_get_credentials_builder(last_driver); }
#line 3593 "modules/grpc/otel/otel-grammar.c"
    break;

  case 13: /* $@3: %empty  */
#line 477 "modules/grpc/otel/otel-grammar.y"
                { grpc_server_credentials_builder_set_mode(last_grpc_server_credentials_builder, GSAM_INSECURE); }
#line 3599 "modules/grpc/otel/otel-grammar.c"
    break;

  case 15: /* $@4: %empty  */
#line 478 "modules/grpc/otel/otel-grammar.y"
           { grpc_server_credentials_builder_set_mode(last_grpc_server_credentials_builder, GSAM_TLS); }
#line 3605 "modules/grpc/otel/otel-grammar.c"
    break;

  case 17: /* $@5: %empty  */
#line 479 "modules/grpc/otel/otel-grammar.y"
            { grpc_server_credentials_builder_set_mode(last_grpc_server_credentials_builder, GSAM_ALTS); }
#line 3611 "modules/grpc/otel/otel-grammar.c"
    break;

  case 21: /* source_otel_auth_tls_option: KW_KEY_FILE '(' string ')'  */
#line 489 "modules/grpc/otel/otel-grammar.y"
      {
        CHECK_ERROR(grpc_server_credentials_builder_set_tls_key_path(last_grpc_server_credentials_builder, (yyvsp[-1].cptr)), (yylsp[-3]), "Failed to set key-file()");
        free((yyvsp[-1].cptr));
      }
#line 3620 "modules/grpc/otel/otel-grammar.c"
    break;

  case 22: /* source_otel_auth_tls_option: KW_CERT_FILE '(' string ')'  */
#line 494 "modules/grpc/otel/otel-grammar.y"
      {
        CHECK_ERROR(grpc_server_credentials_builder_set_tls_cert_path(last_grpc_server_credentials_builder, (yyvsp[-1].cptr)), (yylsp[-3]), "Failed to set cert-file()");
        free((yyvsp[-1].cptr));
      }
#line 3629 "modules/grpc/otel/otel-grammar.c"
    break;

  case 23: /* source_otel_auth_tls_option: KW_CA_FILE '(' string ')'  */
#line 499 "modules/grpc/otel/otel-grammar.y"
      {
        CHECK_ERROR(grpc_server_credentials_builder_set_tls_ca_path(last_grpc_server_credentials_builder, (yyvsp[-1].cptr)), (yylsp[-3]), "Failed to set ca-file()");
        free((yyvsp[-1].cptr));
      }
#line 3638 "modules/grpc/otel/otel-grammar.c"
    break;

  case 24: /* source_otel_auth_tls_option: KW_PEER_VERIFY '(' source_otel_auth_tls_peer_verify ')'  */
#line 504 "modules/grpc/otel/otel-grammar.y"
      {
        grpc_server_credentials_builder_set_tls_peer_verify(last_grpc_server_credentials_builder, (yyvsp[-1].num));
      }
#line 3646 "modules/grpc/otel/otel-grammar.c"
    break;

  case 25: /* source_otel_auth_tls_peer_verify: KW_OPTIONAL_UNTRUSTED  */
#line 510 "modules/grpc/otel/otel-grammar.y"
                          { (yyval.num) = GSTPV_OPTIONAL_UNTRUSTED; }
#line 3652 "modules/grpc/otel/otel-grammar.c"
    break;

  case 26: /* source_otel_auth_tls_peer_verify: KW_OPTIONAL_TRUSTED  */
#line 511 "modules/grpc/otel/otel-grammar.y"
                        { (yyval.num) = GSTPV_OPTIONAL_TRUSTED; }
#line 3658 "modules/grpc/otel/otel-grammar.c"
    break;

  case 27: /* source_otel_auth_tls_peer_verify: KW_REQUIRED_UNTRUSTED  */
#line 512 "modules/grpc/otel/otel-grammar.y"
                          { (yyval.num) = GSTPV_REQUIRED_UNTRUSTED; }
#line 3664 "modules/grpc/otel/otel-grammar.c"
    break;

  case 28: /* source_otel_auth_tls_peer_verify: KW_REQUIRED_TRUSTED  */
#line 513 "modules/grpc/otel/otel-grammar.y"
                        { (yyval.num) = GSTPV_REQUIRED_TRUSTED; }
#line 3670 "modules/grpc/otel/otel-grammar.c"
    break;

  case 29: /* $@6: %empty  */
#line 518 "modules/grpc/otel/otel-grammar.y"
    {
      last_parser = *instance = otel_protobuf_parser_new(configuration);
    }
#line 3678 "modules/grpc/otel/otel-grammar.c"
    break;

  case 30: /* parser_otel: KW_OPENTELEMETRY $@6 '(' parser_otel_options ')'  */
#line 521 "modules/grpc/otel/otel-grammar.y"
                                { (yyval.ptr) = last_parser; }
#line 3684 "modules/grpc/otel/otel-grammar.c"
    break;

  case 34: /* $@7: %empty  */
#line 535 "modules/grpc/otel/otel-grammar.y"
    {
      last_driver = *instance = otel_dd_new(configuration);
    }
#line 3692 "modules/grpc/otel/otel-grammar.c"
    break;

  case 35: /* destination_otel: KW_OPENTELEMETRY $@7 '(' _inner_dest_context_push destination_otel_options _inner_dest_context_pop ')'  */
#line 538 "modules/grpc/otel/otel-grammar.y"
                                                                                      { (yyval.ptr) = last_driver; }
#line 3698 "modules/grpc/otel/otel-grammar.c"
    break;

  case 38: /* destination_otel_option: KW_URL '(' string ')'  */
#line 547 "modules/grpc/otel/otel-grammar.y"
                          { otel_dd_set_url(last_driver, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 3704 "modules/grpc/otel/otel-grammar.c"
    break;

  case 39: /* $@8: %empty  */
#line 548 "modules/grpc/otel/otel-grammar.y"
            { last_grpc_client_credentials_builder = otel_dd_get_credentials_builder(last_driver); }
#line 3710 "modules/grpc/otel/otel-grammar.c"
    break;

  case 44: /* $@9: %empty  */
#line 555 "modules/grpc/otel/otel-grammar.y"
                { grpc_client_credentials_builder_set_mode(last_grpc_client_credentials_builder, GCAM_INSECURE); }
#line 3716 "modules/grpc/otel/otel-grammar.c"
    break;

  case 46: /* $@10: %empty  */
#line 556 "modules/grpc/otel/otel-grammar.y"
           { grpc_client_credentials_builder_set_mode(last_grpc_client_credentials_builder, GCAM_TLS); }
#line 3722 "modules/grpc/otel/otel-grammar.c"
    break;

  case 48: /* $@11: %empty  */
#line 557 "modules/grpc/otel/otel-grammar.y"
            { grpc_client_credentials_builder_set_mode(last_grpc_client_credentials_builder, GCAM_ALTS); }
#line 3728 "modules/grpc/otel/otel-grammar.c"
    break;

  case 50: /* $@12: %empty  */
#line 558 "modules/grpc/otel/otel-grammar.y"
           { grpc_client_credentials_builder_set_mode(last_grpc_client_credentials_builder, GCAM_ADC); }
#line 3734 "modules/grpc/otel/otel-grammar.c"
    break;

  case 54: /* destination_otel_auth_tls_option: KW_KEY_FILE '(' string ')'  */
#line 568 "modules/grpc/otel/otel-grammar.y"
      {
        CHECK_ERROR(grpc_client_credentials_builder_set_tls_key_path(last_grpc_client_credentials_builder, (yyvsp[-1].cptr)), (yylsp[-3]), "Failed to set key-file()");
        free((yyvsp[-1].cptr));
      }
#line 3743 "modules/grpc/otel/otel-grammar.c"
    break;

  case 55: /* destination_otel_auth_tls_option: KW_CERT_FILE '(' string ')'  */
#line 573 "modules/grpc/otel/otel-grammar.y"
      {
        CHECK_ERROR(grpc_client_credentials_builder_set_tls_cert_path(last_grpc_client_credentials_builder, (yyvsp[-1].cptr)), (yylsp[-3]), "Failed to set cert-file()");
        free((yyvsp[-1].cptr));
      }
#line 3752 "modules/grpc/otel/otel-grammar.c"
    break;

  case 56: /* destination_otel_auth_tls_option: KW_CA_FILE '(' string ')'  */
#line 578 "modules/grpc/otel/otel-grammar.y"
      {
        CHECK_ERROR(grpc_client_credentials_builder_set_tls_ca_path(last_grpc_client_credentials_builder, (yyvsp[-1].cptr)), (yylsp[-3]), "Failed to set ca-file()");
        free((yyvsp[-1].cptr));
      }
#line 3761 "modules/grpc/otel/otel-grammar.c"
    break;

  case 60: /* $@13: %empty  */
#line 595 "modules/grpc/otel/otel-grammar.y"
      {
        grpc_client_credentials_builder_add_alts_target_service_account(last_grpc_client_credentials_builder, (yyvsp[0].cptr));
        free((yyvsp[0].cptr));
      }
#line 3770 "modules/grpc/otel/otel-grammar.c"
    break;

  case 65: /* yesno_strict: KW_YES  */
#line 918 "modules/grpc/otel/otel-grammar.y"
                                                { (yyval.num) = 1; }
#line 3776 "modules/grpc/otel/otel-grammar.c"
    break;

  case 66: /* yesno_strict: KW_NO  */
#line 919 "modules/grpc/otel/otel-grammar.y"
                                                { (yyval.num) = 0; }
#line 3782 "modules/grpc/otel/otel-grammar.c"
    break;

  case 68: /* yesno: LL_NUMBER  */
#line 924 "modules/grpc/otel/otel-grammar.y"
                                                { (yyval.num) = (yyvsp[0].num); }
#line 3788 "modules/grpc/otel/otel-grammar.c"
    break;

  case 69: /* dnsmode: yesno  */
#line 934 "modules/grpc/otel/otel-grammar.y"
                                                { (yyval.num) = (yyvsp[0].num); }
#line 3794 "modules/grpc/otel/otel-grammar.c"
    break;

  case 70: /* dnsmode: KW_PERSIST_ONLY  */
#line 935 "modules/grpc/otel/otel-grammar.y"
                                                { (yyval.num) = 2; }
#line 3800 "modules/grpc/otel/otel-grammar.c"
    break;

  case 71: /* nonnegative_integer64: LL_NUMBER  */
#line 940 "modules/grpc/otel/otel-grammar.y"
          {
            CHECK_ERROR(((yyvsp[0].num) >= 0), (yylsp[0]), "It cannot be negative");
          }
#line 3808 "modules/grpc/otel/otel-grammar.c"
    break;

  case 72: /* nonnegative_integer: nonnegative_integer64  */
#line 947 "modules/grpc/otel/otel-grammar.y"
          {
            CHECK_ERROR(((yyvsp[0].num) <= G_MAXINT32), (yylsp[0]), "Must be smaller than 2^31");
          }
#line 3816 "modules/grpc/otel/otel-grammar.c"
    break;

  case 73: /* positive_integer64: LL_NUMBER  */
#line 954 "modules/grpc/otel/otel-grammar.y"
          {
            CHECK_ERROR(((yyvsp[0].num) > 0), (yylsp[0]), "Must be positive");
          }
#line 3824 "modules/grpc/otel/otel-grammar.c"
    break;

  case 74: /* positive_integer: positive_integer64  */
#line 961 "modules/grpc/otel/otel-grammar.y"
          {
            CHECK_ERROR(((yyvsp[0].num) <= G_MAXINT32), (yylsp[0]), "Must be smaller than 2^31");
          }
#line 3832 "modules/grpc/otel/otel-grammar.c"
    break;

  case 75: /* string_list: string_list_build  */
#line 1026 "modules/grpc/otel/otel-grammar.y"
                                                { (yyval.ptr) = (yyvsp[0].ptr); }
#line 3838 "modules/grpc/otel/otel-grammar.c"
    break;

  case 76: /* string_list_build: string string_list_build  */
#line 1030 "modules/grpc/otel/otel-grammar.y"
                                                { (yyval.ptr) = g_list_prepend((yyvsp[0].ptr), g_strdup((yyvsp[-1].cptr))); free((yyvsp[-1].cptr)); }
#line 3844 "modules/grpc/otel/otel-grammar.c"
    break;

  case 77: /* string_list_build: %empty  */
#line 1031 "modules/grpc/otel/otel-grammar.y"
                                                { (yyval.ptr) = NULL; }
#line 3850 "modules/grpc/otel/otel-grammar.c"
    break;

  case 78: /* severity_string: string  */
#line 1041 "modules/grpc/otel/otel-grammar.y"
          {
	    /* return the numeric value of the "level" */
	    int n = syslog_name_lookup_severity_by_name((yyvsp[0].cptr));
	    CHECK_ERROR((n != -1), (yylsp[0]), "Unknown priority level\"%s\"", (yyvsp[0].cptr));
	    free((yyvsp[0].cptr));
            (yyval.num) = n;
	  }
#line 3862 "modules/grpc/otel/otel-grammar.c"
    break;

  case 79: /* facility_string: string  */
#line 1052 "modules/grpc/otel/otel-grammar.y"
          {
            /* return the numeric value of facility */
	    int n = syslog_name_lookup_facility_by_name((yyvsp[0].cptr));
	    CHECK_ERROR((n != -1), (yylsp[0]), "Unknown facility \"%s\"", (yyvsp[0].cptr));
	    free((yyvsp[0].cptr));
	    (yyval.num) = n;
	  }
#line 3874 "modules/grpc/otel/otel-grammar.c"
    break;

  case 80: /* facility_string: KW_SYSLOG  */
#line 1059 "modules/grpc/otel/otel-grammar.y"
                                                { (yyval.num) = LOG_SYSLOG; }
#line 3880 "modules/grpc/otel/otel-grammar.c"
    break;

  case 81: /* parser_opt: KW_TEMPLATE '(' string ')'  */
#line 1063 "modules/grpc/otel/otel-grammar.y"
                                                {
                                                  LogTemplate *template;
                                                  GError *error = NULL;

                                                  template = cfg_tree_check_inline_template(&configuration->tree, (yyvsp[-1].cptr), &error);
                                                  CHECK_ERROR_GERROR(template != NULL, (yylsp[-1]), error, "Error compiling template");
                                                  log_parser_set_template(last_parser, template);
                                                  free((yyvsp[-1].cptr));
                                                }
#line 3894 "modules/grpc/otel/otel-grammar.c"
    break;

  case 82: /* parser_opt: KW_INTERNAL '(' yesno ')'  */
#line 1072 "modules/grpc/otel/otel-grammar.y"
                                    { log_pipe_set_internal(&last_parser->super, (yyvsp[-1].num)); }
#line 3900 "modules/grpc/otel/otel-grammar.c"
    break;

  case 83: /* driver_option: KW_PERSIST_NAME '(' string ')'  */
#line 1076 "modules/grpc/otel/otel-grammar.y"
                                         { log_pipe_set_persist_name(&last_driver->super, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 3906 "modules/grpc/otel/otel-grammar.c"
    break;

  case 84: /* driver_option: KW_INTERNAL '(' yesno ')'  */
#line 1077 "modules/grpc/otel/otel-grammar.y"
                                    { log_pipe_set_internal(&last_driver->super, (yyvsp[-1].num)); }
#line 3912 "modules/grpc/otel/otel-grammar.c"
    break;

  case 85: /* inner_source: LL_PLUGIN  */
#line 1082 "modules/grpc/otel/otel-grammar.y"
          {
            Plugin *p;
            gint context = LL_CONTEXT_INNER_SRC;
            gpointer value;

            p = cfg_find_plugin(configuration, context, (yyvsp[0].cptr));
            CHECK_ERROR(p, (yylsp[0]), "%s plugin %s not found", cfg_lexer_lookup_context_name_by_type(context), (yyvsp[0].cptr));

            value = cfg_parse_plugin(configuration, p, &(yylsp[0]), last_driver);

            free((yyvsp[0].cptr));
            if (!value)
              {
                YYERROR;
              }
            if (!log_driver_add_plugin(last_driver, (LogDriverPlugin *) value))
              {
                log_driver_plugin_free(value);
                CHECK_ERROR(TRUE, (yylsp[0]), "Error while registering the plugin %s in this destination", (yyvsp[0].cptr));
              }
          }
#line 3938 "modules/grpc/otel/otel-grammar.c"
    break;

  case 88: /* inner_dest: LL_PLUGIN  */
#line 1114 "modules/grpc/otel/otel-grammar.y"
          {
            Plugin *p;
            gint context = LL_CONTEXT_INNER_DEST;
            gpointer value;

            p = cfg_find_plugin(configuration, context, (yyvsp[0].cptr));
            CHECK_ERROR(p, (yylsp[0]), "%s plugin %s not found", cfg_lexer_lookup_context_name_by_type(context), (yyvsp[0].cptr));

            value = cfg_parse_plugin(configuration, p, &(yylsp[0]), last_driver);

            free((yyvsp[0].cptr));
            if (!value)
              {
                YYERROR;
              }
            if (!log_driver_add_plugin(last_driver, (LogDriverPlugin *) value))
              {
                log_driver_plugin_free(value);
                CHECK_ERROR(TRUE, (yylsp[0]), "Error while registering the plugin %s in this destination", (yyvsp[0].cptr));
              }
          }
#line 3964 "modules/grpc/otel/otel-grammar.c"
    break;

  case 89: /* dest_driver_option: KW_LOG_FIFO_SIZE '(' positive_integer ')'  */
#line 1141 "modules/grpc/otel/otel-grammar.y"
                                                        { ((LogDestDriver *) last_driver)->log_fifo_size = (yyvsp[-1].num); }
#line 3970 "modules/grpc/otel/otel-grammar.c"
    break;

  case 90: /* dest_driver_option: KW_THROTTLE '(' nonnegative_integer ')'  */
#line 1142 "modules/grpc/otel/otel-grammar.y"
                                                          { ((LogDestDriver *) last_driver)->throttle = (yyvsp[-1].num); }
#line 3976 "modules/grpc/otel/otel-grammar.c"
    break;

  case 93: /* threaded_dest_driver_batch_option: KW_BATCH_LINES '(' nonnegative_integer ')'  */
#line 1148 "modules/grpc/otel/otel-grammar.y"
                                                     { log_threaded_dest_driver_set_batch_lines(last_driver, (yyvsp[-1].num)); }
#line 3982 "modules/grpc/otel/otel-grammar.c"
    break;

  case 94: /* threaded_dest_driver_batch_option: KW_BATCH_TIMEOUT '(' positive_integer ')'  */
#line 1149 "modules/grpc/otel/otel-grammar.y"
                                                    { log_threaded_dest_driver_set_batch_timeout(last_driver, (yyvsp[-1].num)); }
#line 3988 "modules/grpc/otel/otel-grammar.c"
    break;

  case 95: /* threaded_dest_driver_workers_option: KW_WORKERS '(' positive_integer ')'  */
#line 1153 "modules/grpc/otel/otel-grammar.y"
                                               { log_threaded_dest_driver_set_num_workers(last_driver, (yyvsp[-1].num)); }
#line 3994 "modules/grpc/otel/otel-grammar.c"
    break;

  case 96: /* threaded_dest_driver_general_option: KW_RETRIES '(' positive_integer ')'  */
#line 1159 "modules/grpc/otel/otel-grammar.y"
        {
          log_threaded_dest_driver_set_max_retries_on_error(last_driver, (yyvsp[-1].num));
        }
#line 4002 "modules/grpc/otel/otel-grammar.c"
    break;

  case 97: /* threaded_dest_driver_general_option: KW_TIME_REOPEN '(' positive_integer ')'  */
#line 1162 "modules/grpc/otel/otel-grammar.y"
                                                  { log_threaded_dest_driver_set_time_reopen(last_driver, (yyvsp[-1].num)); }
#line 4008 "modules/grpc/otel/otel-grammar.c"
    break;

  case 99: /* threaded_source_driver_option: KW_FORMAT '(' string ')'  */
#line 1168 "modules/grpc/otel/otel-grammar.y"
                                   { log_threaded_source_driver_get_parse_options(last_driver)->format = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4014 "modules/grpc/otel/otel-grammar.c"
    break;

  case 101: /* $@17: %empty  */
#line 1170 "modules/grpc/otel/otel-grammar.y"
          { last_msg_format_options = log_threaded_source_driver_get_parse_options(last_driver); }
#line 4020 "modules/grpc/otel/otel-grammar.c"
    break;

  case 103: /* $@18: %empty  */
#line 1171 "modules/grpc/otel/otel-grammar.y"
          { last_source_options = log_threaded_source_driver_get_source_options(last_driver); }
#line 4026 "modules/grpc/otel/otel-grammar.c"
    break;

  case 106: /* threaded_source_driver_option_flags: string threaded_source_driver_option_flags  */
#line 1182 "modules/grpc/otel/otel-grammar.y"
        {
          CHECK_ERROR(msg_format_options_process_flag(log_threaded_source_driver_get_parse_options(last_driver), (yyvsp[-1].cptr)), (yylsp[-1]), "Unknown flag \"%s\"", (yyvsp[-1].cptr));
          free((yyvsp[-1].cptr));
        }
#line 4035 "modules/grpc/otel/otel-grammar.c"
    break;

  case 108: /* source_option: KW_LOG_IW_SIZE '(' positive_integer ')'  */
#line 1192 "modules/grpc/otel/otel-grammar.y"
                                                        { last_source_options->init_window_size = (yyvsp[-1].num); }
#line 4041 "modules/grpc/otel/otel-grammar.c"
    break;

  case 109: /* source_option: KW_CHAIN_HOSTNAMES '(' yesno ')'  */
#line 1193 "modules/grpc/otel/otel-grammar.y"
                                                { last_source_options->chain_hostnames = (yyvsp[-1].num); }
#line 4047 "modules/grpc/otel/otel-grammar.c"
    break;

  case 110: /* source_option: KW_KEEP_HOSTNAME '(' yesno ')'  */
#line 1194 "modules/grpc/otel/otel-grammar.y"
                                                { last_source_options->keep_hostname = (yyvsp[-1].num); }
#line 4053 "modules/grpc/otel/otel-grammar.c"
    break;

  case 111: /* source_option: KW_PROGRAM_OVERRIDE '(' string ')'  */
#line 1195 "modules/grpc/otel/otel-grammar.y"
                                                { last_source_options->program_override = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4059 "modules/grpc/otel/otel-grammar.c"
    break;

  case 112: /* source_option: KW_HOST_OVERRIDE '(' string ')'  */
#line 1196 "modules/grpc/otel/otel-grammar.y"
                                                { last_source_options->host_override = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4065 "modules/grpc/otel/otel-grammar.c"
    break;

  case 113: /* source_option: KW_LOG_PREFIX '(' string ')'  */
#line 1197 "modules/grpc/otel/otel-grammar.y"
                                                { gchar *p = strrchr((yyvsp[-1].cptr), ':'); if (p) *p = 0; last_source_options->program_override = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4071 "modules/grpc/otel/otel-grammar.c"
    break;

  case 114: /* source_option: KW_KEEP_TIMESTAMP '(' yesno ')'  */
#line 1198 "modules/grpc/otel/otel-grammar.y"
                                                { last_source_options->keep_timestamp = (yyvsp[-1].num); }
#line 4077 "modules/grpc/otel/otel-grammar.c"
    break;

  case 115: /* source_option: KW_READ_OLD_RECORDS '(' yesno ')'  */
#line 1199 "modules/grpc/otel/otel-grammar.y"
                                                { last_source_options->read_old_records = (yyvsp[-1].num); }
#line 4083 "modules/grpc/otel/otel-grammar.c"
    break;

  case 116: /* source_option: KW_USE_SYSLOGNG_PID '(' yesno ')'  */
#line 1200 "modules/grpc/otel/otel-grammar.y"
                                                { last_source_options->use_syslogng_pid = (yyvsp[-1].num); }
#line 4089 "modules/grpc/otel/otel-grammar.c"
    break;

  case 117: /* source_option: KW_TAGS '(' string_list ')'  */
#line 1201 "modules/grpc/otel/otel-grammar.y"
                                                { log_source_options_set_tags(last_source_options, (yyvsp[-1].ptr)); }
#line 4095 "modules/grpc/otel/otel-grammar.c"
    break;

  case 118: /* $@19: %empty  */
#line 1202 "modules/grpc/otel/otel-grammar.y"
          { last_host_resolve_options = &last_source_options->host_resolve_options; }
#line 4101 "modules/grpc/otel/otel-grammar.c"
    break;

  case 120: /* host_resolve_option: KW_USE_FQDN '(' yesno ')'  */
#line 1238 "modules/grpc/otel/otel-grammar.y"
                                                { last_host_resolve_options->use_fqdn = (yyvsp[-1].num); }
#line 4107 "modules/grpc/otel/otel-grammar.c"
    break;

  case 121: /* host_resolve_option: KW_USE_DNS '(' dnsmode ')'  */
#line 1239 "modules/grpc/otel/otel-grammar.y"
                                                { last_host_resolve_options->use_dns = (yyvsp[-1].num); }
#line 4113 "modules/grpc/otel/otel-grammar.c"
    break;

  case 122: /* host_resolve_option: KW_DNS_CACHE '(' yesno ')'  */
#line 1240 "modules/grpc/otel/otel-grammar.y"
                                                { last_host_resolve_options->use_dns_cache = (yyvsp[-1].num); }
#line 4119 "modules/grpc/otel/otel-grammar.c"
    break;

  case 123: /* host_resolve_option: KW_NORMALIZE_HOSTNAMES '(' yesno ')'  */
#line 1241 "modules/grpc/otel/otel-grammar.y"
                                                { last_host_resolve_options->normalize_hostnames = (yyvsp[-1].num); }
#line 4125 "modules/grpc/otel/otel-grammar.c"
    break;

  case 124: /* msg_format_option: KW_TIME_ZONE '(' string ')'  */
#line 1245 "modules/grpc/otel/otel-grammar.y"
                                                { last_msg_format_options->recv_time_zone = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4131 "modules/grpc/otel/otel-grammar.c"
    break;

  case 125: /* msg_format_option: KW_DEFAULT_SEVERITY '(' severity_string ')'  */
#line 1247 "modules/grpc/otel/otel-grammar.y"
          {
	    if (last_msg_format_options->default_pri == 0xFFFF)
	      last_msg_format_options->default_pri = LOG_USER;
	    last_msg_format_options->default_pri = (last_msg_format_options->default_pri & ~SYSLOG_PRIMASK) | (yyvsp[-1].num);
          }
#line 4141 "modules/grpc/otel/otel-grammar.c"
    break;

  case 126: /* msg_format_option: KW_DEFAULT_FACILITY '(' facility_string ')'  */
#line 1253 "modules/grpc/otel/otel-grammar.y"
          {
	    if (last_msg_format_options->default_pri == 0xFFFF)
	      last_msg_format_options->default_pri = LOG_NOTICE;
	    last_msg_format_options->default_pri = (last_msg_format_options->default_pri & SYSLOG_PRIMASK) | (yyvsp[-1].num);
          }
#line 4151 "modules/grpc/otel/otel-grammar.c"
    break;

  case 127: /* msg_format_option: KW_SDATA_PREFIX '(' string ')'  */
#line 1259 "modules/grpc/otel/otel-grammar.y"
          {
            CHECK_ERROR(msg_format_options_set_sdata_prefix(last_msg_format_options, (yyvsp[-1].cptr)), (yylsp[-1]), "Prefix is too long \"%s\"", (yyvsp[-1].cptr));
            free((yyvsp[-1].cptr));
          }
#line 4160 "modules/grpc/otel/otel-grammar.c"
    break;

  case 128: /* _inner_dest_context_push: %empty  */
#line 1483 "modules/grpc/otel/otel-grammar.y"
                          { cfg_lexer_push_context(lexer, LL_CONTEXT_INNER_DEST, NULL, "within destination"); }
#line 4166 "modules/grpc/otel/otel-grammar.c"
    break;

  case 129: /* _inner_dest_context_pop: %empty  */
#line 1484 "modules/grpc/otel/otel-grammar.y"
                         { cfg_lexer_pop_context(lexer); }
#line 4172 "modules/grpc/otel/otel-grammar.c"
    break;

  case 130: /* _inner_src_context_push: %empty  */
#line 1485 "modules/grpc/otel/otel-grammar.y"
                         { cfg_lexer_push_context(lexer, LL_CONTEXT_INNER_SRC, NULL, "within source"); }
#line 4178 "modules/grpc/otel/otel-grammar.c"
    break;

  case 131: /* _inner_src_context_pop: %empty  */
#line 1486 "modules/grpc/otel/otel-grammar.y"
                        { cfg_lexer_pop_context(lexer); }
#line 4184 "modules/grpc/otel/otel-grammar.c"
    break;


#line 4188 "modules/grpc/otel/otel-grammar.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;
  *++yylsp = yyloc;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == OTEL_EMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      {
        yypcontext_t yyctx
          = {yyssp, yytoken, &yylloc};
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = yysyntax_error (&yymsg_alloc, &yymsg, &yyctx);
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == -1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = YY_CAST (char *,
                             YYSTACK_ALLOC (YY_CAST (YYSIZE_T, yymsg_alloc)));
            if (yymsg)
              {
                yysyntax_error_status
                  = yysyntax_error (&yymsg_alloc, &yymsg, &yyctx);
                yymsgp = yymsg;
              }
            else
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = YYENOMEM;
              }
          }
        yyerror (&yylloc, lexer, instance, arg, yymsgp);
        if (yysyntax_error_status == YYENOMEM)
          YYNOMEM;
      }
    }

  yyerror_range[1] = yylloc;
  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= OTEL_EOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == OTEL_EOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval, &yylloc, lexer, instance, arg);
          yychar = OTEL_EMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;

      yyerror_range[1] = *yylsp;
      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp, yylsp, lexer, instance, arg);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  yyerror_range[2] = yylloc;
  ++yylsp;
  YYLLOC_DEFAULT (*yylsp, yyerror_range, 2);

  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (&yylloc, lexer, instance, arg, YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != OTEL_EMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval, &yylloc, lexer, instance, arg);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp, yylsp, lexer, instance, arg);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
  return yyresult;
}

#line 1491 "modules/grpc/otel/otel-grammar.y"


