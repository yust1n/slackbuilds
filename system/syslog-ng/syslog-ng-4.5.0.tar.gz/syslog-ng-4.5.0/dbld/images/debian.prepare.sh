#!/bin/sh

cp packaging/debian/control ${EXTRA_FILES_DIR}/packaging-debian-control
