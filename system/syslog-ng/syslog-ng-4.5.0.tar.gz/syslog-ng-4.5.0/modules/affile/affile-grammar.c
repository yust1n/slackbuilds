/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 1

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1

/* "%code top" blocks.  */
#line 24 "modules/affile/affile-grammar.y"

#include "affile-parser.h"

#line 72 "modules/affile/affile-grammar.c"
/* Substitute the type names.  */
#define YYSTYPE         AFFILE_STYPE
#define YYLTYPE         AFFILE_LTYPE
/* Substitute the variable and function names.  */
#define yyparse         affile_parse
#define yylex           affile_lex
#define yyerror         affile_error
#define yydebug         affile_debug
#define yynerrs         affile_nerrs


# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

/* Use api.header.include to #include this header
   instead of duplicating it here.  */
#ifndef YY_AFFILE_MODULES_AFFILE_AFFILE_GRAMMAR_H_INCLUDED
# define YY_AFFILE_MODULES_AFFILE_AFFILE_GRAMMAR_H_INCLUDED
/* Debug traces.  */
#ifndef AFFILE_DEBUG
# if defined YYDEBUG
#if YYDEBUG
#   define AFFILE_DEBUG 1
#  else
#   define AFFILE_DEBUG 0
#  endif
# else /* ! defined YYDEBUG */
#  define AFFILE_DEBUG 0
# endif /* ! defined YYDEBUG */
#endif  /* ! defined AFFILE_DEBUG */
#if AFFILE_DEBUG
extern int affile_debug;
#endif

/* Token kinds.  */
#ifndef AFFILE_TOKENTYPE
# define AFFILE_TOKENTYPE
  enum affile_tokentype
  {
    AFFILE_EMPTY = -2,
    AFFILE_EOF = 0,                /* "end of file"  */
    AFFILE_error = 256,            /* error  */
    AFFILE_UNDEF = 10523,          /* "invalid token"  */
    LL_CONTEXT_ROOT = 1,           /* LL_CONTEXT_ROOT  */
    LL_CONTEXT_DESTINATION = 2,    /* LL_CONTEXT_DESTINATION  */
    LL_CONTEXT_SOURCE = 3,         /* LL_CONTEXT_SOURCE  */
    LL_CONTEXT_PARSER = 4,         /* LL_CONTEXT_PARSER  */
    LL_CONTEXT_REWRITE = 5,        /* LL_CONTEXT_REWRITE  */
    LL_CONTEXT_FILTER = 6,         /* LL_CONTEXT_FILTER  */
    LL_CONTEXT_LOG = 7,            /* LL_CONTEXT_LOG  */
    LL_CONTEXT_BLOCK_DEF = 8,      /* LL_CONTEXT_BLOCK_DEF  */
    LL_CONTEXT_BLOCK_REF = 9,      /* LL_CONTEXT_BLOCK_REF  */
    LL_CONTEXT_BLOCK_CONTENT = 10, /* LL_CONTEXT_BLOCK_CONTENT  */
    LL_CONTEXT_BLOCK_ARG = 11,     /* LL_CONTEXT_BLOCK_ARG  */
    LL_CONTEXT_PRAGMA = 12,        /* LL_CONTEXT_PRAGMA  */
    LL_CONTEXT_FORMAT = 13,        /* LL_CONTEXT_FORMAT  */
    LL_CONTEXT_TEMPLATE_FUNC = 14, /* LL_CONTEXT_TEMPLATE_FUNC  */
    LL_CONTEXT_INNER_DEST = 15,    /* LL_CONTEXT_INNER_DEST  */
    LL_CONTEXT_INNER_SRC = 16,     /* LL_CONTEXT_INNER_SRC  */
    LL_CONTEXT_CLIENT_PROTO = 17,  /* LL_CONTEXT_CLIENT_PROTO  */
    LL_CONTEXT_SERVER_PROTO = 18,  /* LL_CONTEXT_SERVER_PROTO  */
    LL_CONTEXT_OPTIONS = 19,       /* LL_CONTEXT_OPTIONS  */
    LL_CONTEXT_CONFIG = 20,        /* LL_CONTEXT_CONFIG  */
    LL_CONTEXT_TEMPLATE_REF = 21,  /* LL_CONTEXT_TEMPLATE_REF  */
    LL_CONTEXT_MAX = 22,           /* LL_CONTEXT_MAX  */
    KW_SOURCE = 10000,             /* KW_SOURCE  */
    KW_FILTER = 10001,             /* KW_FILTER  */
    KW_PARSER = 10002,             /* KW_PARSER  */
    KW_DESTINATION = 10003,        /* KW_DESTINATION  */
    KW_LOG = 10004,                /* KW_LOG  */
    KW_OPTIONS = 10005,            /* KW_OPTIONS  */
    KW_INCLUDE = 10006,            /* KW_INCLUDE  */
    KW_BLOCK = 10007,              /* KW_BLOCK  */
    KW_JUNCTION = 10008,           /* KW_JUNCTION  */
    KW_CHANNEL = 10009,            /* KW_CHANNEL  */
    KW_IF = 10010,                 /* KW_IF  */
    KW_ELSE = 10011,               /* KW_ELSE  */
    KW_ELIF = 10012,               /* KW_ELIF  */
    KW_INTERNAL = 10020,           /* KW_INTERNAL  */
    KW_SYSLOG = 10060,             /* KW_SYSLOG  */
    KW_MARK_FREQ = 10071,          /* KW_MARK_FREQ  */
    KW_STATS_FREQ = 10072,         /* KW_STATS_FREQ  */
    KW_STATS_LEVEL = 10073,        /* KW_STATS_LEVEL  */
    KW_STATS_LIFETIME = 10074,     /* KW_STATS_LIFETIME  */
    KW_FLUSH_LINES = 10075,        /* KW_FLUSH_LINES  */
    KW_SUPPRESS = 10076,           /* KW_SUPPRESS  */
    KW_FLUSH_TIMEOUT = 10077,      /* KW_FLUSH_TIMEOUT  */
    KW_LOG_MSG_SIZE = 10078,       /* KW_LOG_MSG_SIZE  */
    KW_FILE_TEMPLATE = 10079,      /* KW_FILE_TEMPLATE  */
    KW_PROTO_TEMPLATE = 10080,     /* KW_PROTO_TEMPLATE  */
    KW_MARK_MODE = 10081,          /* KW_MARK_MODE  */
    KW_ENCODING = 10082,           /* KW_ENCODING  */
    KW_TYPE = 10083,               /* KW_TYPE  */
    KW_STATS_MAX_DYNAMIC = 10084,  /* KW_STATS_MAX_DYNAMIC  */
    KW_MIN_IW_SIZE_PER_READER = 10085, /* KW_MIN_IW_SIZE_PER_READER  */
    KW_WORKERS = 10086,            /* KW_WORKERS  */
    KW_BATCH_LINES = 10087,        /* KW_BATCH_LINES  */
    KW_BATCH_TIMEOUT = 10088,      /* KW_BATCH_TIMEOUT  */
    KW_TRIM_LARGE_MESSAGES = 10089, /* KW_TRIM_LARGE_MESSAGES  */
    KW_STATS = 10400,              /* KW_STATS  */
    KW_FREQ = 10401,               /* KW_FREQ  */
    KW_LEVEL = 10402,              /* KW_LEVEL  */
    KW_LIFETIME = 10403,           /* KW_LIFETIME  */
    KW_MAX_DYNAMIC = 10404,        /* KW_MAX_DYNAMIC  */
    KW_SYSLOG_STATS = 10405,       /* KW_SYSLOG_STATS  */
    KW_HEALTHCHECK_FREQ = 10406,   /* KW_HEALTHCHECK_FREQ  */
    KW_WORKER_PARTITION_KEY = 10407, /* KW_WORKER_PARTITION_KEY  */
    KW_CHAIN_HOSTNAMES = 10090,    /* KW_CHAIN_HOSTNAMES  */
    KW_NORMALIZE_HOSTNAMES = 10091, /* KW_NORMALIZE_HOSTNAMES  */
    KW_KEEP_HOSTNAME = 10092,      /* KW_KEEP_HOSTNAME  */
    KW_CHECK_HOSTNAME = 10093,     /* KW_CHECK_HOSTNAME  */
    KW_BAD_HOSTNAME = 10094,       /* KW_BAD_HOSTNAME  */
    KW_LOG_LEVEL = 10095,          /* KW_LOG_LEVEL  */
    KW_KEEP_TIMESTAMP = 10100,     /* KW_KEEP_TIMESTAMP  */
    KW_USE_DNS = 10110,            /* KW_USE_DNS  */
    KW_USE_FQDN = 10111,           /* KW_USE_FQDN  */
    KW_CUSTOM_DOMAIN = 10112,      /* KW_CUSTOM_DOMAIN  */
    KW_DNS_CACHE = 10120,          /* KW_DNS_CACHE  */
    KW_DNS_CACHE_SIZE = 10121,     /* KW_DNS_CACHE_SIZE  */
    KW_DNS_CACHE_EXPIRE = 10130,   /* KW_DNS_CACHE_EXPIRE  */
    KW_DNS_CACHE_EXPIRE_FAILED = 10131, /* KW_DNS_CACHE_EXPIRE_FAILED  */
    KW_DNS_CACHE_HOSTS = 10132,    /* KW_DNS_CACHE_HOSTS  */
    KW_PERSIST_ONLY = 10140,       /* KW_PERSIST_ONLY  */
    KW_USE_RCPTID = 10141,         /* KW_USE_RCPTID  */
    KW_USE_UNIQID = 10142,         /* KW_USE_UNIQID  */
    KW_TZ_CONVERT = 10150,         /* KW_TZ_CONVERT  */
    KW_TS_FORMAT = 10151,          /* KW_TS_FORMAT  */
    KW_FRAC_DIGITS = 10152,        /* KW_FRAC_DIGITS  */
    KW_LOG_FIFO_SIZE = 10160,      /* KW_LOG_FIFO_SIZE  */
    KW_LOG_FETCH_LIMIT = 10162,    /* KW_LOG_FETCH_LIMIT  */
    KW_LOG_IW_SIZE = 10163,        /* KW_LOG_IW_SIZE  */
    KW_LOG_PREFIX = 10164,         /* KW_LOG_PREFIX  */
    KW_PROGRAM_OVERRIDE = 10165,   /* KW_PROGRAM_OVERRIDE  */
    KW_HOST_OVERRIDE = 10166,      /* KW_HOST_OVERRIDE  */
    KW_THROTTLE = 10170,           /* KW_THROTTLE  */
    KW_THREADED = 10171,           /* KW_THREADED  */
    KW_PASS_UNIX_CREDENTIALS = 10180, /* KW_PASS_UNIX_CREDENTIALS  */
    KW_PERSIST_NAME = 10181,       /* KW_PERSIST_NAME  */
    KW_READ_OLD_RECORDS = 10182,   /* KW_READ_OLD_RECORDS  */
    KW_USE_SYSLOGNG_PID = 10183,   /* KW_USE_SYSLOGNG_PID  */
    KW_FLAGS = 10190,              /* KW_FLAGS  */
    KW_PAD_SIZE = 10200,           /* KW_PAD_SIZE  */
    KW_TIME_ZONE = 10201,          /* KW_TIME_ZONE  */
    KW_RECV_TIME_ZONE = 10202,     /* KW_RECV_TIME_ZONE  */
    KW_SEND_TIME_ZONE = 10203,     /* KW_SEND_TIME_ZONE  */
    KW_LOCAL_TIME_ZONE = 10204,    /* KW_LOCAL_TIME_ZONE  */
    KW_FORMAT = 10205,             /* KW_FORMAT  */
    KW_MULTI_LINE_MODE = 10206,    /* KW_MULTI_LINE_MODE  */
    KW_MULTI_LINE_PREFIX = 10207,  /* KW_MULTI_LINE_PREFIX  */
    KW_MULTI_LINE_GARBAGE = 10208, /* KW_MULTI_LINE_GARBAGE  */
    KW_TRUNCATE_SIZE = 10209,      /* KW_TRUNCATE_SIZE  */
    KW_TIME_REOPEN = 10210,        /* KW_TIME_REOPEN  */
    KW_TIME_REAP = 10211,          /* KW_TIME_REAP  */
    KW_TIME_SLEEP = 10212,         /* KW_TIME_SLEEP  */
    KW_PARTITIONS = 10213,         /* KW_PARTITIONS  */
    KW_PARTITION_KEY = 10214,      /* KW_PARTITION_KEY  */
    KW_PARALLELIZE = 10215,        /* KW_PARALLELIZE  */
    KW_TMPL_ESCAPE = 10220,        /* KW_TMPL_ESCAPE  */
    KW_OPTIONAL = 10230,           /* KW_OPTIONAL  */
    KW_CREATE_DIRS = 10240,        /* KW_CREATE_DIRS  */
    KW_OWNER = 10250,              /* KW_OWNER  */
    KW_GROUP = 10251,              /* KW_GROUP  */
    KW_PERM = 10252,               /* KW_PERM  */
    KW_DIR_OWNER = 10260,          /* KW_DIR_OWNER  */
    KW_DIR_GROUP = 10261,          /* KW_DIR_GROUP  */
    KW_DIR_PERM = 10262,           /* KW_DIR_PERM  */
    KW_TEMPLATE = 10270,           /* KW_TEMPLATE  */
    KW_TEMPLATE_ESCAPE = 10271,    /* KW_TEMPLATE_ESCAPE  */
    KW_TEMPLATE_FUNCTION = 10272,  /* KW_TEMPLATE_FUNCTION  */
    KW_DEFAULT_FACILITY = 10300,   /* KW_DEFAULT_FACILITY  */
    KW_DEFAULT_SEVERITY = 10301,   /* KW_DEFAULT_SEVERITY  */
    KW_SDATA_PREFIX = 10302,       /* KW_SDATA_PREFIX  */
    KW_PORT = 10323,               /* KW_PORT  */
    KW_USE_TIME_RECVD = 10340,     /* KW_USE_TIME_RECVD  */
    KW_FACILITY = 10350,           /* KW_FACILITY  */
    KW_SEVERITY = 10351,           /* KW_SEVERITY  */
    KW_HOST = 10352,               /* KW_HOST  */
    KW_MATCH = 10353,              /* KW_MATCH  */
    KW_MESSAGE = 10354,            /* KW_MESSAGE  */
    KW_NETMASK = 10355,            /* KW_NETMASK  */
    KW_TAGS = 10356,               /* KW_TAGS  */
    KW_NETMASK6 = 10357,           /* KW_NETMASK6  */
    KW_REWRITE = 10370,            /* KW_REWRITE  */
    KW_CONDITION = 10371,          /* KW_CONDITION  */
    KW_VALUE = 10372,              /* KW_VALUE  */
    KW_YES = 10380,                /* KW_YES  */
    KW_NO = 10381,                 /* KW_NO  */
    KW_AUTO = 10382,               /* KW_AUTO  */
    KW_IFDEF = 10410,              /* KW_IFDEF  */
    KW_ENDIF = 10411,              /* KW_ENDIF  */
    LL_DOTDOT = 10420,             /* LL_DOTDOT  */
    LL_DOTDOTDOT = 10421,          /* LL_DOTDOTDOT  */
    LL_PRAGMA = 10422,             /* LL_PRAGMA  */
    LL_EOL = 10423,                /* LL_EOL  */
    LL_ERROR = 10424,              /* LL_ERROR  */
    LL_ARROW = 10425,              /* LL_ARROW  */
    LL_IDENTIFIER = 10430,         /* LL_IDENTIFIER  */
    LL_NUMBER = 10431,             /* LL_NUMBER  */
    LL_FLOAT = 10432,              /* LL_FLOAT  */
    LL_STRING = 10433,             /* LL_STRING  */
    LL_TOKEN = 10434,              /* LL_TOKEN  */
    LL_BLOCK = 10435,              /* LL_BLOCK  */
    LL_PLUGIN = 10436,             /* LL_PLUGIN  */
    LL_TEMPLATE_REF = 10437,       /* LL_TEMPLATE_REF  */
    KW_VALUE_PAIRS = 10500,        /* KW_VALUE_PAIRS  */
    KW_EXCLUDE = 10502,            /* KW_EXCLUDE  */
    KW_PAIR = 10503,               /* KW_PAIR  */
    KW_KEY = 10504,                /* KW_KEY  */
    KW_SCOPE = 10505,              /* KW_SCOPE  */
    KW_SHIFT = 10506,              /* KW_SHIFT  */
    KW_SHIFT_LEVELS = 10507,       /* KW_SHIFT_LEVELS  */
    KW_REKEY = 10508,              /* KW_REKEY  */
    KW_ADD_PREFIX = 10509,         /* KW_ADD_PREFIX  */
    KW_REPLACE_PREFIX = 10510,     /* KW_REPLACE_PREFIX  */
    KW_CAST = 10511,               /* KW_CAST  */
    KW_UPPER = 10512,              /* KW_UPPER  */
    KW_LOWER = 10513,              /* KW_LOWER  */
    KW_INCLUDE_BYTES = 10514,      /* KW_INCLUDE_BYTES  */
    KW_ON_ERROR = 10520,           /* KW_ON_ERROR  */
    KW_RETRIES = 10521,            /* KW_RETRIES  */
    KW_FETCH_NO_DATA_DELAY = 10522, /* KW_FETCH_NO_DATA_DELAY  */
    KW_FILE = 10524,               /* KW_FILE  */
    KW_PIPE = 10525,               /* KW_PIPE  */
    KW_FSYNC = 10526,              /* KW_FSYNC  */
    KW_FOLLOW_FREQ = 10527,        /* KW_FOLLOW_FREQ  */
    KW_OVERWRITE_IF_OLDER = 10528, /* KW_OVERWRITE_IF_OLDER  */
    KW_SYMLINK_AS = 10529,         /* KW_SYMLINK_AS  */
    KW_MULTI_LINE_TIMEOUT = 10530, /* KW_MULTI_LINE_TIMEOUT  */
    KW_WILDCARD_FILE = 10531,      /* KW_WILDCARD_FILE  */
    KW_BASE_DIR = 10532,           /* KW_BASE_DIR  */
    KW_FILENAME_PATTERN = 10533,   /* KW_FILENAME_PATTERN  */
    KW_RECURSIVE = 10534,          /* KW_RECURSIVE  */
    KW_MAX_FILES = 10535,          /* KW_MAX_FILES  */
    KW_MONITOR_METHOD = 10536,     /* KW_MONITOR_METHOD  */
    KW_FORCE_DIRECTORY_POLLING = 10537, /* KW_FORCE_DIRECTORY_POLLING  */
    KW_STDIN = 10538,              /* KW_STDIN  */
    KW_STDOUT = 10539              /* KW_STDOUT  */
  };
  typedef enum affile_tokentype affile_token_kind_t;
#endif
/* Token kinds.  */
#define AFFILE_EMPTY -2
#define AFFILE_EOF 0
#define AFFILE_error 256
#define AFFILE_UNDEF 10523
#define LL_CONTEXT_ROOT 1
#define LL_CONTEXT_DESTINATION 2
#define LL_CONTEXT_SOURCE 3
#define LL_CONTEXT_PARSER 4
#define LL_CONTEXT_REWRITE 5
#define LL_CONTEXT_FILTER 6
#define LL_CONTEXT_LOG 7
#define LL_CONTEXT_BLOCK_DEF 8
#define LL_CONTEXT_BLOCK_REF 9
#define LL_CONTEXT_BLOCK_CONTENT 10
#define LL_CONTEXT_BLOCK_ARG 11
#define LL_CONTEXT_PRAGMA 12
#define LL_CONTEXT_FORMAT 13
#define LL_CONTEXT_TEMPLATE_FUNC 14
#define LL_CONTEXT_INNER_DEST 15
#define LL_CONTEXT_INNER_SRC 16
#define LL_CONTEXT_CLIENT_PROTO 17
#define LL_CONTEXT_SERVER_PROTO 18
#define LL_CONTEXT_OPTIONS 19
#define LL_CONTEXT_CONFIG 20
#define LL_CONTEXT_TEMPLATE_REF 21
#define LL_CONTEXT_MAX 22
#define KW_SOURCE 10000
#define KW_FILTER 10001
#define KW_PARSER 10002
#define KW_DESTINATION 10003
#define KW_LOG 10004
#define KW_OPTIONS 10005
#define KW_INCLUDE 10006
#define KW_BLOCK 10007
#define KW_JUNCTION 10008
#define KW_CHANNEL 10009
#define KW_IF 10010
#define KW_ELSE 10011
#define KW_ELIF 10012
#define KW_INTERNAL 10020
#define KW_SYSLOG 10060
#define KW_MARK_FREQ 10071
#define KW_STATS_FREQ 10072
#define KW_STATS_LEVEL 10073
#define KW_STATS_LIFETIME 10074
#define KW_FLUSH_LINES 10075
#define KW_SUPPRESS 10076
#define KW_FLUSH_TIMEOUT 10077
#define KW_LOG_MSG_SIZE 10078
#define KW_FILE_TEMPLATE 10079
#define KW_PROTO_TEMPLATE 10080
#define KW_MARK_MODE 10081
#define KW_ENCODING 10082
#define KW_TYPE 10083
#define KW_STATS_MAX_DYNAMIC 10084
#define KW_MIN_IW_SIZE_PER_READER 10085
#define KW_WORKERS 10086
#define KW_BATCH_LINES 10087
#define KW_BATCH_TIMEOUT 10088
#define KW_TRIM_LARGE_MESSAGES 10089
#define KW_STATS 10400
#define KW_FREQ 10401
#define KW_LEVEL 10402
#define KW_LIFETIME 10403
#define KW_MAX_DYNAMIC 10404
#define KW_SYSLOG_STATS 10405
#define KW_HEALTHCHECK_FREQ 10406
#define KW_WORKER_PARTITION_KEY 10407
#define KW_CHAIN_HOSTNAMES 10090
#define KW_NORMALIZE_HOSTNAMES 10091
#define KW_KEEP_HOSTNAME 10092
#define KW_CHECK_HOSTNAME 10093
#define KW_BAD_HOSTNAME 10094
#define KW_LOG_LEVEL 10095
#define KW_KEEP_TIMESTAMP 10100
#define KW_USE_DNS 10110
#define KW_USE_FQDN 10111
#define KW_CUSTOM_DOMAIN 10112
#define KW_DNS_CACHE 10120
#define KW_DNS_CACHE_SIZE 10121
#define KW_DNS_CACHE_EXPIRE 10130
#define KW_DNS_CACHE_EXPIRE_FAILED 10131
#define KW_DNS_CACHE_HOSTS 10132
#define KW_PERSIST_ONLY 10140
#define KW_USE_RCPTID 10141
#define KW_USE_UNIQID 10142
#define KW_TZ_CONVERT 10150
#define KW_TS_FORMAT 10151
#define KW_FRAC_DIGITS 10152
#define KW_LOG_FIFO_SIZE 10160
#define KW_LOG_FETCH_LIMIT 10162
#define KW_LOG_IW_SIZE 10163
#define KW_LOG_PREFIX 10164
#define KW_PROGRAM_OVERRIDE 10165
#define KW_HOST_OVERRIDE 10166
#define KW_THROTTLE 10170
#define KW_THREADED 10171
#define KW_PASS_UNIX_CREDENTIALS 10180
#define KW_PERSIST_NAME 10181
#define KW_READ_OLD_RECORDS 10182
#define KW_USE_SYSLOGNG_PID 10183
#define KW_FLAGS 10190
#define KW_PAD_SIZE 10200
#define KW_TIME_ZONE 10201
#define KW_RECV_TIME_ZONE 10202
#define KW_SEND_TIME_ZONE 10203
#define KW_LOCAL_TIME_ZONE 10204
#define KW_FORMAT 10205
#define KW_MULTI_LINE_MODE 10206
#define KW_MULTI_LINE_PREFIX 10207
#define KW_MULTI_LINE_GARBAGE 10208
#define KW_TRUNCATE_SIZE 10209
#define KW_TIME_REOPEN 10210
#define KW_TIME_REAP 10211
#define KW_TIME_SLEEP 10212
#define KW_PARTITIONS 10213
#define KW_PARTITION_KEY 10214
#define KW_PARALLELIZE 10215
#define KW_TMPL_ESCAPE 10220
#define KW_OPTIONAL 10230
#define KW_CREATE_DIRS 10240
#define KW_OWNER 10250
#define KW_GROUP 10251
#define KW_PERM 10252
#define KW_DIR_OWNER 10260
#define KW_DIR_GROUP 10261
#define KW_DIR_PERM 10262
#define KW_TEMPLATE 10270
#define KW_TEMPLATE_ESCAPE 10271
#define KW_TEMPLATE_FUNCTION 10272
#define KW_DEFAULT_FACILITY 10300
#define KW_DEFAULT_SEVERITY 10301
#define KW_SDATA_PREFIX 10302
#define KW_PORT 10323
#define KW_USE_TIME_RECVD 10340
#define KW_FACILITY 10350
#define KW_SEVERITY 10351
#define KW_HOST 10352
#define KW_MATCH 10353
#define KW_MESSAGE 10354
#define KW_NETMASK 10355
#define KW_TAGS 10356
#define KW_NETMASK6 10357
#define KW_REWRITE 10370
#define KW_CONDITION 10371
#define KW_VALUE 10372
#define KW_YES 10380
#define KW_NO 10381
#define KW_AUTO 10382
#define KW_IFDEF 10410
#define KW_ENDIF 10411
#define LL_DOTDOT 10420
#define LL_DOTDOTDOT 10421
#define LL_PRAGMA 10422
#define LL_EOL 10423
#define LL_ERROR 10424
#define LL_ARROW 10425
#define LL_IDENTIFIER 10430
#define LL_NUMBER 10431
#define LL_FLOAT 10432
#define LL_STRING 10433
#define LL_TOKEN 10434
#define LL_BLOCK 10435
#define LL_PLUGIN 10436
#define LL_TEMPLATE_REF 10437
#define KW_VALUE_PAIRS 10500
#define KW_EXCLUDE 10502
#define KW_PAIR 10503
#define KW_KEY 10504
#define KW_SCOPE 10505
#define KW_SHIFT 10506
#define KW_SHIFT_LEVELS 10507
#define KW_REKEY 10508
#define KW_ADD_PREFIX 10509
#define KW_REPLACE_PREFIX 10510
#define KW_CAST 10511
#define KW_UPPER 10512
#define KW_LOWER 10513
#define KW_INCLUDE_BYTES 10514
#define KW_ON_ERROR 10520
#define KW_RETRIES 10521
#define KW_FETCH_NO_DATA_DELAY 10522
#define KW_FILE 10524
#define KW_PIPE 10525
#define KW_FSYNC 10526
#define KW_FOLLOW_FREQ 10527
#define KW_OVERWRITE_IF_OLDER 10528
#define KW_SYMLINK_AS 10529
#define KW_MULTI_LINE_TIMEOUT 10530
#define KW_WILDCARD_FILE 10531
#define KW_BASE_DIR 10532
#define KW_FILENAME_PATTERN 10533
#define KW_RECURSIVE 10534
#define KW_MAX_FILES 10535
#define KW_MONITOR_METHOD 10536
#define KW_FORCE_DIRECTORY_POLLING 10537
#define KW_STDIN 10538
#define KW_STDOUT 10539

/* Value type.  */
#if ! defined AFFILE_STYPE && ! defined AFFILE_STYPE_IS_DECLARED
typedef CFG_STYPE AFFILE_STYPE;
# define AFFILE_STYPE_IS_TRIVIAL 1
# define AFFILE_STYPE_IS_DECLARED 1
#endif

/* Location type.  */
typedef CFG_LTYPE AFFILE_LTYPE;




int affile_parse (CfgLexer *lexer, LogDriver **instance, gpointer arg);


#endif /* !YY_AFFILE_MODULES_AFFILE_AFFILE_GRAMMAR_H_INCLUDED  */
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_LL_CONTEXT_ROOT = 3,            /* LL_CONTEXT_ROOT  */
  YYSYMBOL_LL_CONTEXT_DESTINATION = 4,     /* LL_CONTEXT_DESTINATION  */
  YYSYMBOL_LL_CONTEXT_SOURCE = 5,          /* LL_CONTEXT_SOURCE  */
  YYSYMBOL_LL_CONTEXT_PARSER = 6,          /* LL_CONTEXT_PARSER  */
  YYSYMBOL_LL_CONTEXT_REWRITE = 7,         /* LL_CONTEXT_REWRITE  */
  YYSYMBOL_LL_CONTEXT_FILTER = 8,          /* LL_CONTEXT_FILTER  */
  YYSYMBOL_LL_CONTEXT_LOG = 9,             /* LL_CONTEXT_LOG  */
  YYSYMBOL_LL_CONTEXT_BLOCK_DEF = 10,      /* LL_CONTEXT_BLOCK_DEF  */
  YYSYMBOL_LL_CONTEXT_BLOCK_REF = 11,      /* LL_CONTEXT_BLOCK_REF  */
  YYSYMBOL_LL_CONTEXT_BLOCK_CONTENT = 12,  /* LL_CONTEXT_BLOCK_CONTENT  */
  YYSYMBOL_LL_CONTEXT_BLOCK_ARG = 13,      /* LL_CONTEXT_BLOCK_ARG  */
  YYSYMBOL_LL_CONTEXT_PRAGMA = 14,         /* LL_CONTEXT_PRAGMA  */
  YYSYMBOL_LL_CONTEXT_FORMAT = 15,         /* LL_CONTEXT_FORMAT  */
  YYSYMBOL_LL_CONTEXT_TEMPLATE_FUNC = 16,  /* LL_CONTEXT_TEMPLATE_FUNC  */
  YYSYMBOL_LL_CONTEXT_INNER_DEST = 17,     /* LL_CONTEXT_INNER_DEST  */
  YYSYMBOL_LL_CONTEXT_INNER_SRC = 18,      /* LL_CONTEXT_INNER_SRC  */
  YYSYMBOL_LL_CONTEXT_CLIENT_PROTO = 19,   /* LL_CONTEXT_CLIENT_PROTO  */
  YYSYMBOL_LL_CONTEXT_SERVER_PROTO = 20,   /* LL_CONTEXT_SERVER_PROTO  */
  YYSYMBOL_LL_CONTEXT_OPTIONS = 21,        /* LL_CONTEXT_OPTIONS  */
  YYSYMBOL_LL_CONTEXT_CONFIG = 22,         /* LL_CONTEXT_CONFIG  */
  YYSYMBOL_LL_CONTEXT_TEMPLATE_REF = 23,   /* LL_CONTEXT_TEMPLATE_REF  */
  YYSYMBOL_LL_CONTEXT_MAX = 24,            /* LL_CONTEXT_MAX  */
  YYSYMBOL_KW_SOURCE = 25,                 /* KW_SOURCE  */
  YYSYMBOL_KW_FILTER = 26,                 /* KW_FILTER  */
  YYSYMBOL_KW_PARSER = 27,                 /* KW_PARSER  */
  YYSYMBOL_KW_DESTINATION = 28,            /* KW_DESTINATION  */
  YYSYMBOL_KW_LOG = 29,                    /* KW_LOG  */
  YYSYMBOL_KW_OPTIONS = 30,                /* KW_OPTIONS  */
  YYSYMBOL_KW_INCLUDE = 31,                /* KW_INCLUDE  */
  YYSYMBOL_KW_BLOCK = 32,                  /* KW_BLOCK  */
  YYSYMBOL_KW_JUNCTION = 33,               /* KW_JUNCTION  */
  YYSYMBOL_KW_CHANNEL = 34,                /* KW_CHANNEL  */
  YYSYMBOL_KW_IF = 35,                     /* KW_IF  */
  YYSYMBOL_KW_ELSE = 36,                   /* KW_ELSE  */
  YYSYMBOL_KW_ELIF = 37,                   /* KW_ELIF  */
  YYSYMBOL_KW_INTERNAL = 38,               /* KW_INTERNAL  */
  YYSYMBOL_KW_SYSLOG = 39,                 /* KW_SYSLOG  */
  YYSYMBOL_KW_MARK_FREQ = 40,              /* KW_MARK_FREQ  */
  YYSYMBOL_KW_STATS_FREQ = 41,             /* KW_STATS_FREQ  */
  YYSYMBOL_KW_STATS_LEVEL = 42,            /* KW_STATS_LEVEL  */
  YYSYMBOL_KW_STATS_LIFETIME = 43,         /* KW_STATS_LIFETIME  */
  YYSYMBOL_KW_FLUSH_LINES = 44,            /* KW_FLUSH_LINES  */
  YYSYMBOL_KW_SUPPRESS = 45,               /* KW_SUPPRESS  */
  YYSYMBOL_KW_FLUSH_TIMEOUT = 46,          /* KW_FLUSH_TIMEOUT  */
  YYSYMBOL_KW_LOG_MSG_SIZE = 47,           /* KW_LOG_MSG_SIZE  */
  YYSYMBOL_KW_FILE_TEMPLATE = 48,          /* KW_FILE_TEMPLATE  */
  YYSYMBOL_KW_PROTO_TEMPLATE = 49,         /* KW_PROTO_TEMPLATE  */
  YYSYMBOL_KW_MARK_MODE = 50,              /* KW_MARK_MODE  */
  YYSYMBOL_KW_ENCODING = 51,               /* KW_ENCODING  */
  YYSYMBOL_KW_TYPE = 52,                   /* KW_TYPE  */
  YYSYMBOL_KW_STATS_MAX_DYNAMIC = 53,      /* KW_STATS_MAX_DYNAMIC  */
  YYSYMBOL_KW_MIN_IW_SIZE_PER_READER = 54, /* KW_MIN_IW_SIZE_PER_READER  */
  YYSYMBOL_KW_WORKERS = 55,                /* KW_WORKERS  */
  YYSYMBOL_KW_BATCH_LINES = 56,            /* KW_BATCH_LINES  */
  YYSYMBOL_KW_BATCH_TIMEOUT = 57,          /* KW_BATCH_TIMEOUT  */
  YYSYMBOL_KW_TRIM_LARGE_MESSAGES = 58,    /* KW_TRIM_LARGE_MESSAGES  */
  YYSYMBOL_KW_STATS = 59,                  /* KW_STATS  */
  YYSYMBOL_KW_FREQ = 60,                   /* KW_FREQ  */
  YYSYMBOL_KW_LEVEL = 61,                  /* KW_LEVEL  */
  YYSYMBOL_KW_LIFETIME = 62,               /* KW_LIFETIME  */
  YYSYMBOL_KW_MAX_DYNAMIC = 63,            /* KW_MAX_DYNAMIC  */
  YYSYMBOL_KW_SYSLOG_STATS = 64,           /* KW_SYSLOG_STATS  */
  YYSYMBOL_KW_HEALTHCHECK_FREQ = 65,       /* KW_HEALTHCHECK_FREQ  */
  YYSYMBOL_KW_WORKER_PARTITION_KEY = 66,   /* KW_WORKER_PARTITION_KEY  */
  YYSYMBOL_KW_CHAIN_HOSTNAMES = 67,        /* KW_CHAIN_HOSTNAMES  */
  YYSYMBOL_KW_NORMALIZE_HOSTNAMES = 68,    /* KW_NORMALIZE_HOSTNAMES  */
  YYSYMBOL_KW_KEEP_HOSTNAME = 69,          /* KW_KEEP_HOSTNAME  */
  YYSYMBOL_KW_CHECK_HOSTNAME = 70,         /* KW_CHECK_HOSTNAME  */
  YYSYMBOL_KW_BAD_HOSTNAME = 71,           /* KW_BAD_HOSTNAME  */
  YYSYMBOL_KW_LOG_LEVEL = 72,              /* KW_LOG_LEVEL  */
  YYSYMBOL_KW_KEEP_TIMESTAMP = 73,         /* KW_KEEP_TIMESTAMP  */
  YYSYMBOL_KW_USE_DNS = 74,                /* KW_USE_DNS  */
  YYSYMBOL_KW_USE_FQDN = 75,               /* KW_USE_FQDN  */
  YYSYMBOL_KW_CUSTOM_DOMAIN = 76,          /* KW_CUSTOM_DOMAIN  */
  YYSYMBOL_KW_DNS_CACHE = 77,              /* KW_DNS_CACHE  */
  YYSYMBOL_KW_DNS_CACHE_SIZE = 78,         /* KW_DNS_CACHE_SIZE  */
  YYSYMBOL_KW_DNS_CACHE_EXPIRE = 79,       /* KW_DNS_CACHE_EXPIRE  */
  YYSYMBOL_KW_DNS_CACHE_EXPIRE_FAILED = 80, /* KW_DNS_CACHE_EXPIRE_FAILED  */
  YYSYMBOL_KW_DNS_CACHE_HOSTS = 81,        /* KW_DNS_CACHE_HOSTS  */
  YYSYMBOL_KW_PERSIST_ONLY = 82,           /* KW_PERSIST_ONLY  */
  YYSYMBOL_KW_USE_RCPTID = 83,             /* KW_USE_RCPTID  */
  YYSYMBOL_KW_USE_UNIQID = 84,             /* KW_USE_UNIQID  */
  YYSYMBOL_KW_TZ_CONVERT = 85,             /* KW_TZ_CONVERT  */
  YYSYMBOL_KW_TS_FORMAT = 86,              /* KW_TS_FORMAT  */
  YYSYMBOL_KW_FRAC_DIGITS = 87,            /* KW_FRAC_DIGITS  */
  YYSYMBOL_KW_LOG_FIFO_SIZE = 88,          /* KW_LOG_FIFO_SIZE  */
  YYSYMBOL_KW_LOG_FETCH_LIMIT = 89,        /* KW_LOG_FETCH_LIMIT  */
  YYSYMBOL_KW_LOG_IW_SIZE = 90,            /* KW_LOG_IW_SIZE  */
  YYSYMBOL_KW_LOG_PREFIX = 91,             /* KW_LOG_PREFIX  */
  YYSYMBOL_KW_PROGRAM_OVERRIDE = 92,       /* KW_PROGRAM_OVERRIDE  */
  YYSYMBOL_KW_HOST_OVERRIDE = 93,          /* KW_HOST_OVERRIDE  */
  YYSYMBOL_KW_THROTTLE = 94,               /* KW_THROTTLE  */
  YYSYMBOL_KW_THREADED = 95,               /* KW_THREADED  */
  YYSYMBOL_KW_PASS_UNIX_CREDENTIALS = 96,  /* KW_PASS_UNIX_CREDENTIALS  */
  YYSYMBOL_KW_PERSIST_NAME = 97,           /* KW_PERSIST_NAME  */
  YYSYMBOL_KW_READ_OLD_RECORDS = 98,       /* KW_READ_OLD_RECORDS  */
  YYSYMBOL_KW_USE_SYSLOGNG_PID = 99,       /* KW_USE_SYSLOGNG_PID  */
  YYSYMBOL_KW_FLAGS = 100,                 /* KW_FLAGS  */
  YYSYMBOL_KW_PAD_SIZE = 101,              /* KW_PAD_SIZE  */
  YYSYMBOL_KW_TIME_ZONE = 102,             /* KW_TIME_ZONE  */
  YYSYMBOL_KW_RECV_TIME_ZONE = 103,        /* KW_RECV_TIME_ZONE  */
  YYSYMBOL_KW_SEND_TIME_ZONE = 104,        /* KW_SEND_TIME_ZONE  */
  YYSYMBOL_KW_LOCAL_TIME_ZONE = 105,       /* KW_LOCAL_TIME_ZONE  */
  YYSYMBOL_KW_FORMAT = 106,                /* KW_FORMAT  */
  YYSYMBOL_KW_MULTI_LINE_MODE = 107,       /* KW_MULTI_LINE_MODE  */
  YYSYMBOL_KW_MULTI_LINE_PREFIX = 108,     /* KW_MULTI_LINE_PREFIX  */
  YYSYMBOL_KW_MULTI_LINE_GARBAGE = 109,    /* KW_MULTI_LINE_GARBAGE  */
  YYSYMBOL_KW_TRUNCATE_SIZE = 110,         /* KW_TRUNCATE_SIZE  */
  YYSYMBOL_KW_TIME_REOPEN = 111,           /* KW_TIME_REOPEN  */
  YYSYMBOL_KW_TIME_REAP = 112,             /* KW_TIME_REAP  */
  YYSYMBOL_KW_TIME_SLEEP = 113,            /* KW_TIME_SLEEP  */
  YYSYMBOL_KW_PARTITIONS = 114,            /* KW_PARTITIONS  */
  YYSYMBOL_KW_PARTITION_KEY = 115,         /* KW_PARTITION_KEY  */
  YYSYMBOL_KW_PARALLELIZE = 116,           /* KW_PARALLELIZE  */
  YYSYMBOL_KW_TMPL_ESCAPE = 117,           /* KW_TMPL_ESCAPE  */
  YYSYMBOL_KW_OPTIONAL = 118,              /* KW_OPTIONAL  */
  YYSYMBOL_KW_CREATE_DIRS = 119,           /* KW_CREATE_DIRS  */
  YYSYMBOL_KW_OWNER = 120,                 /* KW_OWNER  */
  YYSYMBOL_KW_GROUP = 121,                 /* KW_GROUP  */
  YYSYMBOL_KW_PERM = 122,                  /* KW_PERM  */
  YYSYMBOL_KW_DIR_OWNER = 123,             /* KW_DIR_OWNER  */
  YYSYMBOL_KW_DIR_GROUP = 124,             /* KW_DIR_GROUP  */
  YYSYMBOL_KW_DIR_PERM = 125,              /* KW_DIR_PERM  */
  YYSYMBOL_KW_TEMPLATE = 126,              /* KW_TEMPLATE  */
  YYSYMBOL_KW_TEMPLATE_ESCAPE = 127,       /* KW_TEMPLATE_ESCAPE  */
  YYSYMBOL_KW_TEMPLATE_FUNCTION = 128,     /* KW_TEMPLATE_FUNCTION  */
  YYSYMBOL_KW_DEFAULT_FACILITY = 129,      /* KW_DEFAULT_FACILITY  */
  YYSYMBOL_KW_DEFAULT_SEVERITY = 130,      /* KW_DEFAULT_SEVERITY  */
  YYSYMBOL_KW_SDATA_PREFIX = 131,          /* KW_SDATA_PREFIX  */
  YYSYMBOL_KW_PORT = 132,                  /* KW_PORT  */
  YYSYMBOL_KW_USE_TIME_RECVD = 133,        /* KW_USE_TIME_RECVD  */
  YYSYMBOL_KW_FACILITY = 134,              /* KW_FACILITY  */
  YYSYMBOL_KW_SEVERITY = 135,              /* KW_SEVERITY  */
  YYSYMBOL_KW_HOST = 136,                  /* KW_HOST  */
  YYSYMBOL_KW_MATCH = 137,                 /* KW_MATCH  */
  YYSYMBOL_KW_MESSAGE = 138,               /* KW_MESSAGE  */
  YYSYMBOL_KW_NETMASK = 139,               /* KW_NETMASK  */
  YYSYMBOL_KW_TAGS = 140,                  /* KW_TAGS  */
  YYSYMBOL_KW_NETMASK6 = 141,              /* KW_NETMASK6  */
  YYSYMBOL_KW_REWRITE = 142,               /* KW_REWRITE  */
  YYSYMBOL_KW_CONDITION = 143,             /* KW_CONDITION  */
  YYSYMBOL_KW_VALUE = 144,                 /* KW_VALUE  */
  YYSYMBOL_KW_YES = 145,                   /* KW_YES  */
  YYSYMBOL_KW_NO = 146,                    /* KW_NO  */
  YYSYMBOL_KW_AUTO = 147,                  /* KW_AUTO  */
  YYSYMBOL_KW_IFDEF = 148,                 /* KW_IFDEF  */
  YYSYMBOL_KW_ENDIF = 149,                 /* KW_ENDIF  */
  YYSYMBOL_LL_DOTDOT = 150,                /* LL_DOTDOT  */
  YYSYMBOL_LL_DOTDOTDOT = 151,             /* LL_DOTDOTDOT  */
  YYSYMBOL_LL_PRAGMA = 152,                /* LL_PRAGMA  */
  YYSYMBOL_LL_EOL = 153,                   /* LL_EOL  */
  YYSYMBOL_LL_ERROR = 154,                 /* LL_ERROR  */
  YYSYMBOL_LL_ARROW = 155,                 /* LL_ARROW  */
  YYSYMBOL_LL_IDENTIFIER = 156,            /* LL_IDENTIFIER  */
  YYSYMBOL_LL_NUMBER = 157,                /* LL_NUMBER  */
  YYSYMBOL_LL_FLOAT = 158,                 /* LL_FLOAT  */
  YYSYMBOL_LL_STRING = 159,                /* LL_STRING  */
  YYSYMBOL_LL_TOKEN = 160,                 /* LL_TOKEN  */
  YYSYMBOL_LL_BLOCK = 161,                 /* LL_BLOCK  */
  YYSYMBOL_LL_PLUGIN = 162,                /* LL_PLUGIN  */
  YYSYMBOL_LL_TEMPLATE_REF = 163,          /* LL_TEMPLATE_REF  */
  YYSYMBOL_KW_VALUE_PAIRS = 164,           /* KW_VALUE_PAIRS  */
  YYSYMBOL_KW_EXCLUDE = 165,               /* KW_EXCLUDE  */
  YYSYMBOL_KW_PAIR = 166,                  /* KW_PAIR  */
  YYSYMBOL_KW_KEY = 167,                   /* KW_KEY  */
  YYSYMBOL_KW_SCOPE = 168,                 /* KW_SCOPE  */
  YYSYMBOL_KW_SHIFT = 169,                 /* KW_SHIFT  */
  YYSYMBOL_KW_SHIFT_LEVELS = 170,          /* KW_SHIFT_LEVELS  */
  YYSYMBOL_KW_REKEY = 171,                 /* KW_REKEY  */
  YYSYMBOL_KW_ADD_PREFIX = 172,            /* KW_ADD_PREFIX  */
  YYSYMBOL_KW_REPLACE_PREFIX = 173,        /* KW_REPLACE_PREFIX  */
  YYSYMBOL_KW_CAST = 174,                  /* KW_CAST  */
  YYSYMBOL_KW_UPPER = 175,                 /* KW_UPPER  */
  YYSYMBOL_KW_LOWER = 176,                 /* KW_LOWER  */
  YYSYMBOL_KW_INCLUDE_BYTES = 177,         /* KW_INCLUDE_BYTES  */
  YYSYMBOL_KW_ON_ERROR = 178,              /* KW_ON_ERROR  */
  YYSYMBOL_KW_RETRIES = 179,               /* KW_RETRIES  */
  YYSYMBOL_KW_FETCH_NO_DATA_DELAY = 180,   /* KW_FETCH_NO_DATA_DELAY  */
  YYSYMBOL_KW_FILE = 181,                  /* KW_FILE  */
  YYSYMBOL_KW_PIPE = 182,                  /* KW_PIPE  */
  YYSYMBOL_KW_FSYNC = 183,                 /* KW_FSYNC  */
  YYSYMBOL_KW_FOLLOW_FREQ = 184,           /* KW_FOLLOW_FREQ  */
  YYSYMBOL_KW_OVERWRITE_IF_OLDER = 185,    /* KW_OVERWRITE_IF_OLDER  */
  YYSYMBOL_KW_SYMLINK_AS = 186,            /* KW_SYMLINK_AS  */
  YYSYMBOL_KW_MULTI_LINE_TIMEOUT = 187,    /* KW_MULTI_LINE_TIMEOUT  */
  YYSYMBOL_KW_WILDCARD_FILE = 188,         /* KW_WILDCARD_FILE  */
  YYSYMBOL_KW_BASE_DIR = 189,              /* KW_BASE_DIR  */
  YYSYMBOL_KW_FILENAME_PATTERN = 190,      /* KW_FILENAME_PATTERN  */
  YYSYMBOL_KW_RECURSIVE = 191,             /* KW_RECURSIVE  */
  YYSYMBOL_KW_MAX_FILES = 192,             /* KW_MAX_FILES  */
  YYSYMBOL_KW_MONITOR_METHOD = 193,        /* KW_MONITOR_METHOD  */
  YYSYMBOL_KW_FORCE_DIRECTORY_POLLING = 194, /* KW_FORCE_DIRECTORY_POLLING  */
  YYSYMBOL_KW_STDIN = 195,                 /* KW_STDIN  */
  YYSYMBOL_KW_STDOUT = 196,                /* KW_STDOUT  */
  YYSYMBOL_197_ = 197,                     /* '('  */
  YYSYMBOL_198_ = 198,                     /* ')'  */
  YYSYMBOL_199_ = 199,                     /* '{'  */
  YYSYMBOL_200_ = 200,                     /* '}'  */
  YYSYMBOL_201_ = 201,                     /* ';'  */
  YYSYMBOL_202_ = 202,                     /* ':'  */
  YYSYMBOL_YYACCEPT = 203,                 /* $accept  */
  YYSYMBOL_start = 204,                    /* start  */
  YYSYMBOL_source_affile = 205,            /* source_affile  */
  YYSYMBOL_206_1 = 206,                    /* $@1  */
  YYSYMBOL_source_wildcard_params = 207,   /* source_wildcard_params  */
  YYSYMBOL_source_wildcard_options = 208,  /* source_wildcard_options  */
  YYSYMBOL_source_stdin_params = 209,      /* source_stdin_params  */
  YYSYMBOL_210_2 = 210,                    /* $@2  */
  YYSYMBOL_source_affile_params = 211,     /* source_affile_params  */
  YYSYMBOL_212_3 = 212,                    /* $@3  */
  YYSYMBOL_source_affile_options = 213,    /* source_affile_options  */
  YYSYMBOL_source_affile_option = 214,     /* source_affile_option  */
  YYSYMBOL_source_wildcard_option = 215,   /* source_wildcard_option  */
  YYSYMBOL_source_legacy_wildcard_option = 216, /* source_legacy_wildcard_option  */
  YYSYMBOL_source_afpipe_params = 217,     /* source_afpipe_params  */
  YYSYMBOL_218_4 = 218,                    /* $@4  */
  YYSYMBOL_source_afpipe_options = 219,    /* source_afpipe_options  */
  YYSYMBOL_source_afpipe_option = 220,     /* source_afpipe_option  */
  YYSYMBOL_multi_line_timeout = 221,       /* multi_line_timeout  */
  YYSYMBOL_dest_affile = 222,              /* dest_affile  */
  YYSYMBOL_dest_affile_params = 223,       /* dest_affile_params  */
  YYSYMBOL_224_5 = 224,                    /* $@5  */
  YYSYMBOL_dest_affile_options = 225,      /* dest_affile_options  */
  YYSYMBOL_dest_affile_option = 226,       /* dest_affile_option  */
  YYSYMBOL_dest_afpipe_params = 227,       /* dest_afpipe_params  */
  YYSYMBOL_228_6 = 228,                    /* $@6  */
  YYSYMBOL_dest_afpipe_options = 229,      /* dest_afpipe_options  */
  YYSYMBOL_dest_afpipe_option = 230,       /* dest_afpipe_option  */
  YYSYMBOL_dest_affile_common_option = 231, /* dest_affile_common_option  */
  YYSYMBOL_dest_stdout_params = 232,       /* dest_stdout_params  */
  YYSYMBOL_233_7 = 233,                    /* $@7  */
  YYSYMBOL_dest_stdout_options = 234,      /* dest_stdout_options  */
  YYSYMBOL_dest_stdout_option = 235,       /* dest_stdout_option  */
  YYSYMBOL_template_content_inner = 236,   /* template_content_inner  */
  YYSYMBOL_type_hint = 237,                /* type_hint  */
  YYSYMBOL_template_content = 238,         /* template_content  */
  YYSYMBOL_239_10 = 239,                   /* @10  */
  YYSYMBOL_template_name_or_content = 240, /* template_name_or_content  */
  YYSYMBOL_template_name_or_content_tail = 241, /* template_name_or_content_tail  */
  YYSYMBOL_string = 242,                   /* string  */
  YYSYMBOL_yesno_strict = 243,             /* yesno_strict  */
  YYSYMBOL_yesno = 244,                    /* yesno  */
  YYSYMBOL_dnsmode = 245,                  /* dnsmode  */
  YYSYMBOL_nonnegative_integer64 = 246,    /* nonnegative_integer64  */
  YYSYMBOL_nonnegative_integer = 247,      /* nonnegative_integer  */
  YYSYMBOL_positive_integer64 = 248,       /* positive_integer64  */
  YYSYMBOL_positive_integer = 249,         /* positive_integer  */
  YYSYMBOL_nonnegative_float = 250,        /* nonnegative_float  */
  YYSYMBOL_string_or_number = 251,         /* string_or_number  */
  YYSYMBOL_normalized_flag = 252,          /* normalized_flag  */
  YYSYMBOL_string_list = 253,              /* string_list  */
  YYSYMBOL_string_list_build = 254,        /* string_list_build  */
  YYSYMBOL_severity_string = 255,          /* severity_string  */
  YYSYMBOL_facility_string = 256,          /* facility_string  */
  YYSYMBOL_driver_option = 257,            /* driver_option  */
  YYSYMBOL_inner_source = 258,             /* inner_source  */
  YYSYMBOL_source_driver_option = 259,     /* source_driver_option  */
  YYSYMBOL_inner_dest = 260,               /* inner_dest  */
  YYSYMBOL_dest_driver_option = 261,       /* dest_driver_option  */
  YYSYMBOL_source_option = 262,            /* source_option  */
  YYSYMBOL_263_13 = 263,                   /* $@13  */
  YYSYMBOL_source_reader_option = 264,     /* source_reader_option  */
  YYSYMBOL_265_14 = 265,                   /* $@14  */
  YYSYMBOL_266_15 = 266,                   /* $@15  */
  YYSYMBOL_267_16 = 267,                   /* $@16  */
  YYSYMBOL_source_reader_option_flags = 268, /* source_reader_option_flags  */
  YYSYMBOL_source_proto_option = 269,      /* source_proto_option  */
  YYSYMBOL_host_resolve_option = 270,      /* host_resolve_option  */
  YYSYMBOL_msg_format_option = 271,        /* msg_format_option  */
  YYSYMBOL_dest_writer_option = 272,       /* dest_writer_option  */
  YYSYMBOL_273_17 = 273,                   /* $@17  */
  YYSYMBOL_dest_writer_options_flags = 274, /* dest_writer_options_flags  */
  YYSYMBOL_file_perm_option = 275,         /* file_perm_option  */
  YYSYMBOL_template_option = 276,          /* template_option  */
  YYSYMBOL_multi_line_option = 277,        /* multi_line_option  */
  YYSYMBOL__template_ref_context_push = 278, /* _template_ref_context_push  */
  YYSYMBOL__inner_dest_context_push = 279, /* _inner_dest_context_push  */
  YYSYMBOL__inner_dest_context_pop = 280,  /* _inner_dest_context_pop  */
  YYSYMBOL__inner_src_context_push = 281,  /* _inner_src_context_push  */
  YYSYMBOL__inner_src_context_pop = 282    /* _inner_src_context_pop  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;



/* Unqualified %code blocks.  */
#line 29 "modules/affile/affile-grammar.y"


#include "file-opener.h"
#include "affile-source.h"
#include "wildcard-source.h"
#include "affile-dest.h"
#include "cfg-parser.h"
#include "syslog-names.h"
#include "messages.h"
#include "plugin.h"
#include "cfg-grammar-internal.h"
#include "stdin.h"
#include "stdout.h"
#include "named-pipe.h"

#include <string.h>

FileReaderOptions *last_file_reader_options;
LogProtoFileReaderOptions *last_log_proto_options;
MultiLineOptions *last_multi_line_options;
WildcardSourceDriver *last_legacy_wildcard_src_driver;

static void
affile_grammar_set_file_source_driver(AFFileSourceDriver *sd)
{
  last_driver = &sd->super.super;
  last_file_reader_options = &sd->file_reader_options;
  last_reader_options = &last_file_reader_options->reader_options;
  last_file_perm_options = &sd->file_opener_options.file_perm_options;
  last_log_proto_options = file_reader_options_get_log_proto_options(last_file_reader_options);
  last_multi_line_options = &last_log_proto_options->multi_line_options;
}

static void
affile_grammar_set_wildcard_file_source_driver(WildcardSourceDriver *sd)
{
  last_driver = &sd->super.super;
  last_file_reader_options = &sd->file_reader_options;
  last_reader_options = &last_file_reader_options->reader_options;
  last_file_perm_options = &sd->file_opener_options.file_perm_options;
  last_log_proto_options = file_reader_options_get_log_proto_options(last_file_reader_options);
  last_multi_line_options = &last_log_proto_options->multi_line_options;
}

#line 93 "modules/affile/affile-grammar.y"


# define YYLLOC_DEFAULT(Current, Rhs, N)                                \
  do {                                                                  \
    if (N)                                                              \
      {                                                                 \
        (Current).name         = YYRHSLOC(Rhs, 1).name;                 \
        (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;          \
        (Current).first_column = YYRHSLOC (Rhs, 1).first_column;        \
        (Current).last_line    = YYRHSLOC (Rhs, N).last_line;           \
        (Current).last_column  = YYRHSLOC (Rhs, N).last_column;         \
      }                                                                 \
    else                                                                \
      {                                                                 \
        (Current).name         = YYRHSLOC(Rhs, 0).name;                 \
        (Current).first_line   = (Current).last_line   =                \
          YYRHSLOC (Rhs, 0).last_line;                                  \
        (Current).first_column = (Current).last_column =                \
          YYRHSLOC (Rhs, 0).last_column;                                \
      }                                                                 \
  } while (0)

#define CHECK_ERROR_WITHOUT_MESSAGE(val, token) do {                    \
    if (!(val))                                                         \
      {                                                                 \
        YYERROR;                                                        \
      }                                                                 \
  } while (0)

#define CHECK_ERROR(val, token, errorfmt, ...) do {                     \
    if (!(val))                                                         \
      {                                                                 \
        if (errorfmt)                                                   \
          {                                                             \
            gchar __buf[256];                                           \
            g_snprintf(__buf, sizeof(__buf), errorfmt, ## __VA_ARGS__); \
            yyerror(& (token), lexer, NULL, NULL, __buf);               \
          }                                                             \
        YYERROR;                                                        \
      }                                                                 \
  } while (0)

#define CHECK_ERROR_GERROR(val, token, error, errorfmt, ...) do {       \
    if (!(val))                                                         \
      {                                                                 \
        if (errorfmt)                                                   \
          {                                                             \
            gchar __buf[256];                                           \
            g_snprintf(__buf, sizeof(__buf), errorfmt ", error=%s", ## __VA_ARGS__, error->message); \
            yyerror(& (token), lexer, NULL, NULL, __buf);               \
          }                                                             \
        g_clear_error(&error);						\
        YYERROR;                                                        \
      }                                                                 \
  } while (0)

#define YYMAXDEPTH 20000



#line 947 "modules/affile/affile-grammar.c"

#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_int16 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if 1

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* 1 */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined AFFILE_LTYPE_IS_TRIVIAL && AFFILE_LTYPE_IS_TRIVIAL \
             && defined AFFILE_STYPE_IS_TRIVIAL && AFFILE_STYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
  YYLTYPE yyls_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE) \
             + YYSIZEOF (YYLTYPE)) \
      + 2 * YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  13
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   621

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  203
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  80
/* YYNRULES -- Number of rules.  */
#define YYNRULES  198
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  465

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   10539


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_uint8 yytranslate[] =
{
       0,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     197,   198,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,   202,   201,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   199,     2,   200,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,     2,     2,     2,     2,     2,     2,     2,
      38,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      39,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    40,    41,    42,    43,    44,    45,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
      67,    68,    69,    70,    71,    72,     2,     2,     2,     2,
      73,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      74,    75,    76,     2,     2,     2,     2,     2,     2,     2,
      77,    78,     2,     2,     2,     2,     2,     2,     2,     2,
      79,    80,    81,     2,     2,     2,     2,     2,     2,     2,
      82,    83,    84,     2,     2,     2,     2,     2,     2,     2,
      85,    86,    87,     2,     2,     2,     2,     2,     2,     2,
      88,     2,    89,    90,    91,    92,    93,     2,     2,     2,
      94,    95,     2,     2,     2,     2,     2,     2,     2,     2,
      96,    97,    98,    99,     2,     2,     2,     2,     2,     2,
     100,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
     111,   112,   113,   114,   115,   116,     2,     2,     2,     2,
     117,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     118,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     119,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     120,   121,   122,     2,     2,     2,     2,     2,     2,     2,
     123,   124,   125,     2,     2,     2,     2,     2,     2,     2,
     126,   127,   128,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     129,   130,   131,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   132,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     133,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     134,   135,   136,   137,   138,   139,   140,   141,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     142,   143,   144,     2,     2,     2,     2,     2,     2,     2,
     145,   146,   147,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      59,    60,    61,    62,    63,    64,    65,    66,     2,     2,
     148,   149,     2,     2,     2,     2,     2,     2,     2,     2,
     150,   151,   152,   153,   154,   155,     2,     2,     2,     2,
     156,   157,   158,   159,   160,   161,   162,   163,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     164,     2,   165,   166,   167,   168,   169,   170,   171,   172,
     173,   174,   175,   176,   177,     2,     2,     2,     2,     2,
     178,   179,   180,     2,   181,   182,   183,   184,   185,   186,
     187,   188,   189,   190,   191,   192,   193,   194,   195,   196
};

#if AFFILE_DEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   498,   498,   499,   503,   504,   505,   507,   506,   515,
     519,   520,   525,   525,   535,   534,   554,   555,   556,   560,
     561,   562,   563,   564,   565,   566,   570,   571,   576,   577,
     578,   579,   583,   588,   597,   596,   606,   607,   611,   612,
     613,   614,   615,   616,   617,   621,   628,   629,   630,   635,
     634,   644,   645,   649,   650,   651,   652,   653,   654,   655,
     656,   661,   660,   670,   671,   675,   676,   677,   678,   682,
     683,   688,   688,   696,   697,   701,   702,   972,   979,   988,
     996,  1004,  1015,  1015,  1026,  1030,  1031,  1037,  1038,  1042,
    1043,  1047,  1048,  1058,  1059,  1063,  1070,  1077,  1084,  1091,
    1095,  1113,  1114,  1115,  1146,  1150,  1154,  1155,  1164,  1175,
    1183,  1192,  1193,  1197,  1224,  1225,  1229,  1257,  1258,  1259,
    1260,  1309,  1310,  1311,  1312,  1313,  1314,  1315,  1316,  1317,
    1318,  1319,  1319,  1326,  1327,  1328,  1329,  1330,  1330,  1331,
    1331,  1332,  1332,  1336,  1337,  1338,  1343,  1350,  1351,  1355,
    1356,  1357,  1358,  1362,  1363,  1369,  1375,  1390,  1391,  1392,
    1393,  1394,  1395,  1396,  1397,  1398,  1399,  1405,  1406,  1406,
    1410,  1411,  1415,  1416,  1417,  1418,  1419,  1420,  1421,  1422,
    1423,  1424,  1425,  1426,  1430,  1431,  1432,  1433,  1434,  1435,
    1436,  1552,  1557,  1563,  1594,  1595,  1596,  1597,  1598
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if 1
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "LL_CONTEXT_ROOT",
  "LL_CONTEXT_DESTINATION", "LL_CONTEXT_SOURCE", "LL_CONTEXT_PARSER",
  "LL_CONTEXT_REWRITE", "LL_CONTEXT_FILTER", "LL_CONTEXT_LOG",
  "LL_CONTEXT_BLOCK_DEF", "LL_CONTEXT_BLOCK_REF",
  "LL_CONTEXT_BLOCK_CONTENT", "LL_CONTEXT_BLOCK_ARG", "LL_CONTEXT_PRAGMA",
  "LL_CONTEXT_FORMAT", "LL_CONTEXT_TEMPLATE_FUNC", "LL_CONTEXT_INNER_DEST",
  "LL_CONTEXT_INNER_SRC", "LL_CONTEXT_CLIENT_PROTO",
  "LL_CONTEXT_SERVER_PROTO", "LL_CONTEXT_OPTIONS", "LL_CONTEXT_CONFIG",
  "LL_CONTEXT_TEMPLATE_REF", "LL_CONTEXT_MAX", "KW_SOURCE", "KW_FILTER",
  "KW_PARSER", "KW_DESTINATION", "KW_LOG", "KW_OPTIONS", "KW_INCLUDE",
  "KW_BLOCK", "KW_JUNCTION", "KW_CHANNEL", "KW_IF", "KW_ELSE", "KW_ELIF",
  "KW_INTERNAL", "KW_SYSLOG", "KW_MARK_FREQ", "KW_STATS_FREQ",
  "KW_STATS_LEVEL", "KW_STATS_LIFETIME", "KW_FLUSH_LINES", "KW_SUPPRESS",
  "KW_FLUSH_TIMEOUT", "KW_LOG_MSG_SIZE", "KW_FILE_TEMPLATE",
  "KW_PROTO_TEMPLATE", "KW_MARK_MODE", "KW_ENCODING", "KW_TYPE",
  "KW_STATS_MAX_DYNAMIC", "KW_MIN_IW_SIZE_PER_READER", "KW_WORKERS",
  "KW_BATCH_LINES", "KW_BATCH_TIMEOUT", "KW_TRIM_LARGE_MESSAGES",
  "KW_STATS", "KW_FREQ", "KW_LEVEL", "KW_LIFETIME", "KW_MAX_DYNAMIC",
  "KW_SYSLOG_STATS", "KW_HEALTHCHECK_FREQ", "KW_WORKER_PARTITION_KEY",
  "KW_CHAIN_HOSTNAMES", "KW_NORMALIZE_HOSTNAMES", "KW_KEEP_HOSTNAME",
  "KW_CHECK_HOSTNAME", "KW_BAD_HOSTNAME", "KW_LOG_LEVEL",
  "KW_KEEP_TIMESTAMP", "KW_USE_DNS", "KW_USE_FQDN", "KW_CUSTOM_DOMAIN",
  "KW_DNS_CACHE", "KW_DNS_CACHE_SIZE", "KW_DNS_CACHE_EXPIRE",
  "KW_DNS_CACHE_EXPIRE_FAILED", "KW_DNS_CACHE_HOSTS", "KW_PERSIST_ONLY",
  "KW_USE_RCPTID", "KW_USE_UNIQID", "KW_TZ_CONVERT", "KW_TS_FORMAT",
  "KW_FRAC_DIGITS", "KW_LOG_FIFO_SIZE", "KW_LOG_FETCH_LIMIT",
  "KW_LOG_IW_SIZE", "KW_LOG_PREFIX", "KW_PROGRAM_OVERRIDE",
  "KW_HOST_OVERRIDE", "KW_THROTTLE", "KW_THREADED",
  "KW_PASS_UNIX_CREDENTIALS", "KW_PERSIST_NAME", "KW_READ_OLD_RECORDS",
  "KW_USE_SYSLOGNG_PID", "KW_FLAGS", "KW_PAD_SIZE", "KW_TIME_ZONE",
  "KW_RECV_TIME_ZONE", "KW_SEND_TIME_ZONE", "KW_LOCAL_TIME_ZONE",
  "KW_FORMAT", "KW_MULTI_LINE_MODE", "KW_MULTI_LINE_PREFIX",
  "KW_MULTI_LINE_GARBAGE", "KW_TRUNCATE_SIZE", "KW_TIME_REOPEN",
  "KW_TIME_REAP", "KW_TIME_SLEEP", "KW_PARTITIONS", "KW_PARTITION_KEY",
  "KW_PARALLELIZE", "KW_TMPL_ESCAPE", "KW_OPTIONAL", "KW_CREATE_DIRS",
  "KW_OWNER", "KW_GROUP", "KW_PERM", "KW_DIR_OWNER", "KW_DIR_GROUP",
  "KW_DIR_PERM", "KW_TEMPLATE", "KW_TEMPLATE_ESCAPE",
  "KW_TEMPLATE_FUNCTION", "KW_DEFAULT_FACILITY", "KW_DEFAULT_SEVERITY",
  "KW_SDATA_PREFIX", "KW_PORT", "KW_USE_TIME_RECVD", "KW_FACILITY",
  "KW_SEVERITY", "KW_HOST", "KW_MATCH", "KW_MESSAGE", "KW_NETMASK",
  "KW_TAGS", "KW_NETMASK6", "KW_REWRITE", "KW_CONDITION", "KW_VALUE",
  "KW_YES", "KW_NO", "KW_AUTO", "KW_IFDEF", "KW_ENDIF", "LL_DOTDOT",
  "LL_DOTDOTDOT", "LL_PRAGMA", "LL_EOL", "LL_ERROR", "LL_ARROW",
  "LL_IDENTIFIER", "LL_NUMBER", "LL_FLOAT", "LL_STRING", "LL_TOKEN",
  "LL_BLOCK", "LL_PLUGIN", "LL_TEMPLATE_REF", "KW_VALUE_PAIRS",
  "KW_EXCLUDE", "KW_PAIR", "KW_KEY", "KW_SCOPE", "KW_SHIFT",
  "KW_SHIFT_LEVELS", "KW_REKEY", "KW_ADD_PREFIX", "KW_REPLACE_PREFIX",
  "KW_CAST", "KW_UPPER", "KW_LOWER", "KW_INCLUDE_BYTES", "KW_ON_ERROR",
  "KW_RETRIES", "KW_FETCH_NO_DATA_DELAY", "KW_FILE", "KW_PIPE", "KW_FSYNC",
  "KW_FOLLOW_FREQ", "KW_OVERWRITE_IF_OLDER", "KW_SYMLINK_AS",
  "KW_MULTI_LINE_TIMEOUT", "KW_WILDCARD_FILE", "KW_BASE_DIR",
  "KW_FILENAME_PATTERN", "KW_RECURSIVE", "KW_MAX_FILES",
  "KW_MONITOR_METHOD", "KW_FORCE_DIRECTORY_POLLING", "KW_STDIN",
  "KW_STDOUT", "'('", "')'", "'{'", "'}'", "';'", "':'", "$accept",
  "start", "source_affile", "$@1", "source_wildcard_params",
  "source_wildcard_options", "source_stdin_params", "$@2",
  "source_affile_params", "$@3", "source_affile_options",
  "source_affile_option", "source_wildcard_option",
  "source_legacy_wildcard_option", "source_afpipe_params", "$@4",
  "source_afpipe_options", "source_afpipe_option", "multi_line_timeout",
  "dest_affile", "dest_affile_params", "$@5", "dest_affile_options",
  "dest_affile_option", "dest_afpipe_params", "$@6", "dest_afpipe_options",
  "dest_afpipe_option", "dest_affile_common_option", "dest_stdout_params",
  "$@7", "dest_stdout_options", "dest_stdout_option",
  "template_content_inner", "type_hint", "template_content", "@10",
  "template_name_or_content", "template_name_or_content_tail", "string",
  "yesno_strict", "yesno", "dnsmode", "nonnegative_integer64",
  "nonnegative_integer", "positive_integer64", "positive_integer",
  "nonnegative_float", "string_or_number", "normalized_flag",
  "string_list", "string_list_build", "severity_string", "facility_string",
  "driver_option", "inner_source", "source_driver_option", "inner_dest",
  "dest_driver_option", "source_option", "$@13", "source_reader_option",
  "$@14", "$@15", "$@16", "source_reader_option_flags",
  "source_proto_option", "host_resolve_option", "msg_format_option",
  "dest_writer_option", "$@17", "dest_writer_options_flags",
  "file_perm_option", "template_option", "multi_line_option",
  "_template_ref_context_push", "_inner_dest_context_push",
  "_inner_dest_context_pop", "_inner_src_context_push",
  "_inner_src_context_pop", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-179)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-142)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
      10,  -157,  -103,    23,  -169,  -136,  -127,  -179,   -89,   -84,
    -179,   -80,  -179,  -179,  -179,  -179,  -179,  -179,  -179,   -70,
    -179,  -179,  -179,  -179,   -94,   -94,  -179,  -179,  -179,  -179,
      75,  -179,  -179,  -179,   423,  -179,  -179,  -179,  -179,  -179,
    -179,   153,  -179,   -20,  -149,   272,   -50,  -179,  -179,  -179,
     -46,  -179,   -60,   365,   -45,   -42,   -29,   -22,   -14,   -12,
      -8,    -5,    -3,    -2,     1,     2,    11,    12,    16,  -179,
    -179,   423,  -179,  -179,  -179,  -179,   110,   -41,   -20,   -39,
     317,    19,    20,    21,    24,    25,    27,    28,    29,    38,
      47,    54,    55,    61,    74,  -179,    84,    88,    89,    92,
      96,    97,   103,  -179,  -179,  -179,   153,  -179,  -179,  -179,
    -179,  -179,   405,   -17,   -56,  -179,  -179,   -32,   104,   106,
    -179,   -20,   -20,  -179,   114,   116,   117,   122,   123,   124,
    -179,   272,  -179,  -179,  -179,  -179,   107,  -179,  -179,   365,
    -179,  -179,  -179,  -179,  -179,   -26,    22,    22,    22,    50,
     -31,    50,    22,   -94,   -94,    22,    22,    50,  -179,  -179,
     126,   127,   128,   129,   131,   132,   133,  -179,  -179,  -179,
    -179,   134,   135,   136,  -179,   317,  -179,  -179,  -179,  -179,
     -26,    50,   -38,    22,   -94,   -94,   -94,   -94,  -114,    82,
    -141,   111,   140,  -135,  -122,    22,   -94,   -94,   -26,    50,
     -94,   137,  -179,   139,   142,   144,   150,   151,   152,   155,
     156,   157,   159,  -179,   113,   160,   161,   162,  -179,   164,
     165,   166,   168,  -179,  -179,   -26,   -26,  -179,  -179,    22,
     -26,   -26,   -26,    22,   -94,  -179,  -179,  -179,  -179,   169,
    -179,  -179,  -179,  -179,  -179,   172,  -179,  -179,   173,   176,
     178,  -179,  -179,   179,   181,   182,   183,   187,   188,  -179,
     -94,   190,   191,   201,   202,   203,    57,   -94,    22,   -94,
     -94,   -94,   -26,   -94,    22,   -26,   -26,  -179,   204,   206,
     -38,   -38,   209,   210,   214,   215,   218,   222,  -179,   223,
    -179,   224,   229,  -179,  -179,   230,  -179,   231,   232,  -179,
    -179,  -179,   233,   234,   235,   245,   246,   247,   251,  -179,
     -26,   -26,   -26,    50,   -94,   -94,   -94,   -26,   -26,   -94,
     253,   254,   255,   257,  -179,    50,   -94,   -26,   -94,   -13,
     -94,   -94,   258,   262,   266,   273,   282,   283,   284,   285,
    -179,  -179,  -179,  -179,  -179,  -179,  -179,  -179,  -179,  -179,
    -179,  -179,  -179,  -179,  -179,  -179,  -179,  -179,  -179,  -179,
     294,   295,   296,   301,   302,   303,   304,   307,   308,   309,
    -179,  -179,  -179,  -179,  -179,  -179,  -179,  -179,  -179,  -179,
    -179,  -179,  -179,  -179,  -179,  -179,  -179,  -179,  -179,  -179,
    -179,  -179,  -179,   310,   311,   312,   314,   315,   316,   318,
     320,   321,   -94,   323,  -179,   -26,   -74,   -26,   -26,   324,
     327,   328,   330,  -179,  -179,   331,  -179,   332,   333,  -179,
    -179,  -179,  -179,  -179,  -179,  -179,  -179,  -179,  -179,  -179,
    -179,  -179,  -179,  -179,  -179,  -179,  -179,  -179,  -179,  -179,
    -179,  -179,  -179,  -179,  -179,  -179,  -179,  -179,   334,  -179,
    -179,   337,   338,   339,  -179,  -179,  -179,  -179,  -179,  -179,
    -179,  -179,  -179,  -179,  -179
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,     0,     0,     0,     0,     0,     0,     3,     0,     0,
       7,     0,     2,     1,   195,   195,   195,   197,   197,     0,
     197,    82,    82,    71,     0,     0,   197,    12,   196,    49,
       0,   196,    61,   196,   168,    87,    88,   198,    14,   198,
      34,   137,   198,   137,     0,   168,    87,    79,    80,    83,
       0,    77,     0,   168,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   116,
      72,   168,   120,   119,    76,    75,     0,     0,   137,     0,
     137,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   113,     0,     0,     0,     0,
       0,     0,     0,   198,     9,    31,   137,    22,   115,   114,
      25,    24,   131,     0,     0,    23,    21,     0,     0,     0,
      13,   137,   137,    46,     0,     0,     0,     0,     0,     0,
      50,   168,    60,    54,    53,    55,     0,    47,    62,   168,
      68,    66,    65,    67,    48,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   171,     0,     0,     0,   194,    73,
       0,     0,     0,     0,     0,     0,     0,   169,     4,    15,
       5,     0,     0,     0,    35,   137,    44,    43,    42,    41,
       0,     0,   145,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    10,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   138,     0,     0,     0,     0,   140,     0,
       0,     0,     0,   142,     6,     0,     0,    16,    17,     0,
       0,     0,     0,     0,     0,    51,   102,   103,   101,     0,
      63,    89,    90,    92,    91,     0,    95,    96,     0,     0,
       0,    97,    98,     0,     0,     0,     0,     0,     0,   104,
     171,     0,     0,     0,     0,     0,    82,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    36,     0,     0,
     145,   145,     0,     0,     0,     0,     0,     0,   173,     0,
     175,     0,     0,   177,   179,     0,   181,     0,     0,   183,
      99,   100,     0,     0,     0,     0,     0,     0,     0,     8,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   107,
       0,     0,     0,     0,   132,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      78,   112,   164,   158,   160,   159,   165,   166,   117,   118,
     111,   170,   157,   162,   163,   167,   161,    85,    86,    84,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     133,   135,   144,   143,   134,    20,   136,   191,   192,   193,
     172,   174,   176,   178,   180,   182,    19,    45,    26,    27,
      28,    29,    30,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   107,     0,   105,     0,     0,     0,     0,     0,
       0,     0,     0,   110,   109,     0,   108,     0,     0,    33,
      32,    69,    56,    70,    59,    57,    58,   184,   185,   186,
     187,   188,   189,   190,    39,    38,    40,   122,   123,   127,
     121,   126,   124,   125,   128,   129,   106,   130,     0,    94,
      93,     0,     0,     0,   147,   146,   148,   153,   155,   154,
     156,   152,   150,   149,   151
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -179,  -179,  -179,  -179,  -179,    78,  -179,  -179,  -179,  -179,
     -66,   -30,  -179,  -179,  -179,  -179,   175,  -179,  -179,  -179,
    -179,  -179,   141,  -179,  -179,  -179,   195,  -179,   -43,  -179,
    -179,   237,  -179,  -179,  -179,   -18,  -179,  -179,  -179,   -24,
    -179,  -178,  -179,  -179,   -88,  -179,  -148,  -179,    14,  -179,
    -179,   -75,  -179,  -179,   148,  -179,   -63,  -179,   -16,  -179,
    -179,   -61,  -179,  -179,  -179,  -144,  -179,  -179,  -179,    13,
    -179,   278,   -40,  -179,   -59,  -179,   154,    91,   130,    51
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
       0,     3,    12,    19,   103,   104,    42,    43,    37,    78,
     120,   121,   106,   122,    39,    80,   174,   175,   107,     7,
      28,    45,   130,   131,    31,    53,   138,   139,   132,    33,
      34,    70,    71,    49,    50,    29,    30,   265,   359,   238,
     244,   245,   451,   247,   248,   252,   253,   302,   239,   260,
     403,   404,   417,   415,   108,   109,   110,    73,    74,   213,
     214,   111,   112,   113,   114,   282,   218,   324,   223,    75,
      76,   261,   115,   167,   116,   266,    21,    44,    24,    77
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      38,    40,   278,   256,    32,   135,    51,   254,   449,   264,
     140,   105,   169,   143,     1,     2,   292,   176,    55,   177,
     306,   179,   298,    13,     4,     5,   413,  -139,    14,   133,
     215,  -139,   280,   279,   216,   246,   300,   141,  -139,     6,
     178,   217,    35,   236,   237,    36,   219,   332,   333,   123,
      81,   307,   335,   336,   337,   227,   228,   293,   134,   249,
     250,    15,    35,   299,   257,    36,   142,   262,   263,    82,
      16,   241,   242,   220,   221,   222,   105,    63,     8,     9,
      83,    84,  -141,   243,   288,    10,    85,    86,    87,    88,
      79,   135,    11,   117,   365,   283,   140,   368,   369,   143,
      89,    90,    91,    92,    93,    94,   301,   303,    17,  -141,
    -141,  -141,   176,    18,   177,   133,   179,    20,    35,   241,
     242,    36,    52,   141,    54,    35,   255,    26,    36,   258,
     259,   243,   393,   394,   395,   178,   372,   373,   137,   400,
     401,   334,    95,    35,   134,   338,    36,   -81,    25,   411,
      27,   136,   142,   144,   201,   145,    41,   168,   281,   170,
     284,   285,   286,   287,    96,   396,   224,    97,   146,    22,
      23,   118,   304,   305,   119,   147,   308,   409,   -18,   246,
     361,   320,    72,   148,   202,   149,   367,   321,   322,   150,
     323,    55,   151,    72,   152,   153,   160,   161,   154,   155,
    -139,    72,   289,   291,  -139,   295,   297,   251,   156,   157,
     339,  -139,   162,   158,   163,   164,   180,   181,   182,    72,
     357,   183,   184,    81,   185,   186,   187,   448,   450,   452,
     453,    46,    47,    48,    36,   188,   259,   165,    35,   236,
     237,    36,    82,   360,   189,   362,   363,   364,   358,   366,
      63,   190,   191,    83,    84,  -141,   281,   281,   192,    85,
      86,    87,    88,    35,   236,   237,    36,    35,   236,   237,
      36,   193,   235,    89,    90,    91,    92,    93,    94,    72,
     290,   194,  -141,  -141,  -141,   195,   196,    72,   166,   197,
     397,   398,   399,   198,   199,   402,    35,   236,   237,    36,
     200,   225,   410,   226,   412,   414,   416,   418,   159,   294,
      55,   229,    56,   230,   231,    95,    57,    58,    59,   232,
     233,   234,    60,   267,   268,   269,   270,   446,   271,   272,
     273,   274,   275,   276,   240,   309,   310,    96,   296,   311,
      97,   312,    98,    99,   100,   101,   102,   313,   314,   315,
     277,   -11,   316,   317,   318,    55,   319,   325,   326,   327,
      61,   328,   329,   330,  -139,   331,    62,   340,  -139,    63,
     341,   342,    64,    65,   343,  -139,   344,   345,   402,   346,
     347,   348,    66,    67,   124,   349,   350,    81,   352,   353,
     125,   126,    89,    90,    91,    92,    93,    94,    68,   354,
     355,   356,   370,    55,   371,    56,    82,   374,   375,    57,
      58,    59,   376,   377,    63,    60,   378,    83,   171,  -141,
     379,   380,   381,    85,    86,    87,    88,   382,   383,   384,
     385,   386,   387,   388,    69,   172,   173,    89,    90,    91,
      92,    93,    94,   389,   390,   391,  -141,  -141,  -141,   392,
     405,   406,   407,    61,   408,   127,   419,   128,   129,    62,
     420,    55,    63,    56,   421,    64,    65,    57,    58,    59,
     -52,   422,   203,    60,   204,    66,    67,   124,   205,    95,
     423,   424,   425,   426,   126,    89,    90,    91,    92,    93,
      94,    68,   427,   428,   429,   206,   207,   208,   209,   430,
     431,   432,   433,   210,   211,   434,   435,   436,   437,   438,
     439,    61,   440,   441,   442,   -37,   443,    62,   444,   445,
      63,   447,   454,    64,    65,   455,   456,    69,   457,   458,
     459,   460,   461,    66,    67,   462,   463,   464,   351,     0,
       0,     0,     0,     0,     0,   212,     0,     0,     0,    68,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   -64,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    69,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   -74
};

static const yytype_int16 yycheck[] =
{
      24,    25,   180,   151,    22,    45,    30,    38,    82,   157,
      53,    41,    78,    53,     4,     5,   157,    80,    38,    80,
     198,    80,   157,     0,   181,   182,    39,    47,   197,    45,
      47,    51,    70,   181,    51,   157,   158,    53,    58,   196,
      80,    58,   156,   157,   158,   159,   102,   225,   226,   198,
      70,   199,   230,   231,   232,   121,   122,   198,    45,   147,
     148,   197,   156,   198,   152,   159,    53,   155,   156,    89,
     197,   145,   146,   129,   130,   131,   106,    97,   181,   182,
     100,   101,   102,   157,   198,   188,   106,   107,   108,   109,
      39,   131,   195,    42,   272,   183,   139,   275,   276,   139,
     120,   121,   122,   123,   124,   125,   194,   195,   197,   129,
     130,   131,   175,   197,   175,   131,   175,   197,   156,   145,
     146,   159,    31,   139,    33,   156,   150,   197,   159,   153,
     154,   157,   310,   311,   312,   175,   280,   281,   198,   317,
     318,   229,   162,   156,   131,   233,   159,   197,    18,   327,
      20,   197,   139,   198,   103,   197,    26,   198,   182,   198,
     184,   185,   186,   187,   184,   313,   198,   187,   197,    15,
      16,   191,   196,   197,   194,   197,   200,   325,   198,   157,
     268,    68,    34,   197,   106,   197,   274,    74,    75,   197,
      77,    38,   197,    45,   197,   197,    86,    87,   197,   197,
      47,    53,   188,   189,    51,   191,   192,   157,   197,   197,
     234,    58,   102,   197,   104,   105,   197,   197,   197,    71,
     163,   197,   197,    70,   197,   197,   197,   405,   406,   407,
     408,   156,   157,   158,   159,   197,   260,   127,   156,   157,
     158,   159,    89,   267,   197,   269,   270,   271,   266,   273,
      97,   197,   197,   100,   101,   102,   280,   281,   197,   106,
     107,   108,   109,   156,   157,   158,   159,   156,   157,   158,
     159,   197,   131,   120,   121,   122,   123,   124,   125,   131,
     198,   197,   129,   130,   131,   197,   197,   139,   178,   197,
     314,   315,   316,   197,   197,   319,   156,   157,   158,   159,
     197,   197,   326,   197,   328,   329,   330,   331,    71,   198,
      38,   197,    40,   197,   197,   162,    44,    45,    46,   197,
     197,   197,    50,   197,   197,   197,   197,   402,   197,   197,
     197,   197,   197,   197,   139,   198,   197,   184,   198,   197,
     187,   197,   189,   190,   191,   192,   193,   197,   197,   197,
     175,   198,   197,   197,   197,    38,   197,   197,   197,   197,
      88,   197,   197,   197,    47,   197,    94,   198,    51,    97,
     198,   198,   100,   101,   198,    58,   198,   198,   402,   198,
     198,   198,   110,   111,   112,   198,   198,    70,   198,   198,
     118,   119,   120,   121,   122,   123,   124,   125,   126,   198,
     198,   198,   198,    38,   198,    40,    89,   198,   198,    44,
      45,    46,   198,   198,    97,    50,   198,   100,   101,   102,
     198,   198,   198,   106,   107,   108,   109,   198,   198,   198,
     198,   198,   198,   198,   162,   118,   119,   120,   121,   122,
     123,   124,   125,   198,   198,   198,   129,   130,   131,   198,
     197,   197,   197,    88,   197,   183,   198,   185,   186,    94,
     198,    38,    97,    40,   198,   100,   101,    44,    45,    46,
     198,   198,    67,    50,    69,   110,   111,   112,    73,   162,
     198,   198,   198,   198,   119,   120,   121,   122,   123,   124,
     125,   126,   198,   198,   198,    90,    91,    92,    93,   198,
     198,   198,   198,    98,    99,   198,   198,   198,   198,   198,
     198,    88,   198,   198,   198,   198,   198,    94,   198,   198,
      97,   198,   198,   100,   101,   198,   198,   162,   198,   198,
     198,   198,   198,   110,   111,   198,   198,   198,   260,    -1,
      -1,    -1,    -1,    -1,    -1,   140,    -1,    -1,    -1,   126,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   198,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   162,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   198
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int16 yystos[] =
{
       0,     4,     5,   204,   181,   182,   196,   222,   181,   182,
     188,   195,   205,     0,   197,   197,   197,   197,   197,   206,
     197,   279,   279,   279,   281,   281,   197,   281,   223,   238,
     239,   227,   238,   232,   233,   156,   159,   211,   242,   217,
     242,   281,   209,   210,   280,   224,   156,   157,   158,   236,
     237,   242,   280,   228,   280,    38,    40,    44,    45,    46,
      50,    88,    94,    97,   100,   101,   110,   111,   126,   162,
     234,   235,   257,   260,   261,   272,   273,   282,   212,   282,
     218,    70,    89,   100,   101,   106,   107,   108,   109,   120,
     121,   122,   123,   124,   125,   162,   184,   187,   189,   190,
     191,   192,   193,   207,   208,   214,   215,   221,   257,   258,
     259,   264,   265,   266,   267,   275,   277,   282,   191,   194,
     213,   214,   216,   198,   112,   118,   119,   183,   185,   186,
     225,   226,   231,   261,   272,   275,   197,   198,   229,   230,
     231,   261,   272,   275,   198,   197,   197,   197,   197,   197,
     197,   197,   197,   197,   197,   197,   197,   197,   197,   234,
      86,    87,   102,   104,   105,   127,   178,   276,   198,   213,
     198,   101,   118,   119,   219,   220,   259,   264,   275,   277,
     197,   197,   197,   197,   197,   197,   197,   197,   197,   197,
     197,   197,   197,   197,   197,   197,   197,   197,   197,   197,
     197,   282,   208,    67,    69,    73,    90,    91,    92,    93,
      98,    99,   140,   262,   263,    47,    51,    58,   269,   102,
     129,   130,   131,   271,   198,   197,   197,   213,   213,   197,
     197,   197,   197,   197,   197,   225,   157,   158,   242,   251,
     229,   145,   146,   157,   243,   244,   157,   246,   247,   247,
     247,   157,   248,   249,    38,   242,   249,   247,   242,   242,
     252,   274,   247,   247,   249,   240,   278,   197,   197,   197,
     197,   197,   197,   197,   197,   197,   197,   219,   244,   249,
      70,   242,   268,   247,   242,   242,   242,   242,   198,   251,
     198,   251,   157,   198,   198,   251,   198,   251,   157,   198,
     158,   247,   250,   247,   242,   242,   244,   249,   242,   198,
     197,   197,   197,   197,   197,   197,   197,   197,   197,   197,
      68,    74,    75,    77,   270,   197,   197,   197,   197,   197,
     197,   197,   244,   244,   247,   244,   244,   244,   247,   242,
     198,   198,   198,   198,   198,   198,   198,   198,   198,   198,
     198,   274,   198,   198,   198,   198,   198,   163,   238,   241,
     242,   247,   242,   242,   242,   244,   242,   247,   244,   244,
     198,   198,   268,   268,   198,   198,   198,   198,   198,   198,
     198,   198,   198,   198,   198,   198,   198,   198,   198,   198,
     198,   198,   198,   244,   244,   244,   249,   242,   242,   242,
     244,   244,   242,   253,   254,   197,   197,   197,   197,   249,
     242,   244,   242,    39,   242,   256,   242,   255,   242,   198,
     198,   198,   198,   198,   198,   198,   198,   198,   198,   198,
     198,   198,   198,   198,   198,   198,   198,   198,   198,   198,
     198,   198,   198,   198,   198,   198,   254,   198,   244,    82,
     244,   245,   244,   244,   198,   198,   198,   198,   198,   198,
     198,   198,   198,   198,   198
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int16 yyr1[] =
{
       0,   203,   204,   204,   205,   205,   205,   206,   205,   207,
     208,   208,   210,   209,   212,   211,   213,   213,   213,   214,
     214,   214,   214,   214,   214,   214,   215,   215,   215,   215,
     215,   215,   216,   216,   218,   217,   219,   219,   220,   220,
     220,   220,   220,   220,   220,   221,   222,   222,   222,   224,
     223,   225,   225,   226,   226,   226,   226,   226,   226,   226,
     226,   228,   227,   229,   229,   230,   230,   230,   230,   231,
     231,   233,   232,   234,   234,   235,   235,   236,   236,   236,
     236,   237,   239,   238,   240,   241,   241,   242,   242,   243,
     243,   244,   244,   245,   245,   246,   247,   248,   249,   250,
     250,   251,   251,   251,   252,   253,   254,   254,   255,   256,
     256,   257,   257,   258,   259,   259,   260,   261,   261,   261,
     261,   262,   262,   262,   262,   262,   262,   262,   262,   262,
     262,   263,   262,   264,   264,   264,   264,   265,   264,   266,
     264,   267,   264,   268,   268,   268,   269,   269,   269,   270,
     270,   270,   270,   271,   271,   271,   271,   272,   272,   272,
     272,   272,   272,   272,   272,   272,   272,   272,   273,   272,
     274,   274,   275,   275,   275,   275,   275,   275,   275,   275,
     275,   275,   275,   275,   276,   276,   276,   276,   276,   276,
     276,   277,   277,   277,   278,   279,   280,   281,   282
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     2,     2,     6,     6,     6,     0,     7,     1,
       2,     0,     0,     2,     0,     3,     2,     2,     0,     4,
       4,     1,     1,     1,     1,     1,     4,     4,     4,     4,
       4,     1,     4,     4,     0,     3,     2,     0,     4,     4,
       4,     1,     1,     1,     1,     4,     6,     6,     6,     0,
       3,     2,     0,     1,     1,     1,     4,     4,     4,     4,
       1,     0,     3,     2,     0,     1,     1,     1,     1,     4,
       4,     0,     2,     2,     0,     1,     1,     1,     4,     1,
       1,     1,     0,     2,     2,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     2,     0,     1,     1,
       1,     4,     4,     1,     1,     1,     1,     4,     4,     1,
       1,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     0,     2,     4,     4,     4,     4,     0,     2,     0,
       2,     0,     2,     2,     2,     0,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     0,     2,
       2,     0,     4,     3,     4,     3,     4,     3,     4,     3,
       4,     3,     4,     3,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     0,     0,     0,     0,     0
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = AFFILE_EMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == AFFILE_EMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (&yylloc, lexer, instance, arg, YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use AFFILE_error or AFFILE_UNDEF. */
#define YYERRCODE AFFILE_UNDEF

/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)                                \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;        \
          (Current).first_column = YYRHSLOC (Rhs, 1).first_column;      \
          (Current).last_line    = YYRHSLOC (Rhs, N).last_line;         \
          (Current).last_column  = YYRHSLOC (Rhs, N).last_column;       \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).first_line   = (Current).last_line   =              \
            YYRHSLOC (Rhs, 0).last_line;                                \
          (Current).first_column = (Current).last_column =              \
            YYRHSLOC (Rhs, 0).last_column;                              \
        }                                                               \
    while (0)
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K])


/* Enable debugging if requested.  */
#if AFFILE_DEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)


/* YYLOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

# ifndef YYLOCATION_PRINT

#  if defined YY_LOCATION_PRINT

   /* Temporary convenience wrapper in case some people defined the
      undocumented and private YY_LOCATION_PRINT macros.  */
#   define YYLOCATION_PRINT(File, Loc)  YY_LOCATION_PRINT(File, *(Loc))

#  elif defined AFFILE_LTYPE_IS_TRIVIAL && AFFILE_LTYPE_IS_TRIVIAL

/* Print *YYLOCP on YYO.  Private, do not rely on its existence. */

YY_ATTRIBUTE_UNUSED
static int
yy_location_print_ (FILE *yyo, YYLTYPE const * const yylocp)
{
  int res = 0;
  int end_col = 0 != yylocp->last_column ? yylocp->last_column - 1 : 0;
  if (0 <= yylocp->first_line)
    {
      res += YYFPRINTF (yyo, "%d", yylocp->first_line);
      if (0 <= yylocp->first_column)
        res += YYFPRINTF (yyo, ".%d", yylocp->first_column);
    }
  if (0 <= yylocp->last_line)
    {
      if (yylocp->first_line < yylocp->last_line)
        {
          res += YYFPRINTF (yyo, "-%d", yylocp->last_line);
          if (0 <= end_col)
            res += YYFPRINTF (yyo, ".%d", end_col);
        }
      else if (0 <= end_col && yylocp->first_column < end_col)
        res += YYFPRINTF (yyo, "-%d", end_col);
    }
  return res;
}

#   define YYLOCATION_PRINT  yy_location_print_

    /* Temporary convenience wrapper in case some people defined the
       undocumented and private YY_LOCATION_PRINT macros.  */
#   define YY_LOCATION_PRINT(File, Loc)  YYLOCATION_PRINT(File, &(Loc))

#  else

#   define YYLOCATION_PRINT(File, Loc) ((void) 0)
    /* Temporary convenience wrapper in case some people defined the
       undocumented and private YY_LOCATION_PRINT macros.  */
#   define YY_LOCATION_PRINT  YYLOCATION_PRINT

#  endif
# endif /* !defined YYLOCATION_PRINT */


# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value, Location, lexer, instance, arg); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp, CfgLexer *lexer, LogDriver **instance, gpointer arg)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  YY_USE (yylocationp);
  YY_USE (lexer);
  YY_USE (instance);
  YY_USE (arg);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp, CfgLexer *lexer, LogDriver **instance, gpointer arg)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  YYLOCATION_PRINT (yyo, yylocationp);
  YYFPRINTF (yyo, ": ");
  yy_symbol_value_print (yyo, yykind, yyvaluep, yylocationp, lexer, instance, arg);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp, YYLTYPE *yylsp,
                 int yyrule, CfgLexer *lexer, LogDriver **instance, gpointer arg)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)],
                       &(yylsp[(yyi + 1) - (yynrhs)]), lexer, instance, arg);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, yylsp, Rule, lexer, instance, arg); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !AFFILE_DEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !AFFILE_DEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


/* Context of a parse error.  */
typedef struct
{
  yy_state_t *yyssp;
  yysymbol_kind_t yytoken;
  YYLTYPE *yylloc;
} yypcontext_t;

/* Put in YYARG at most YYARGN of the expected tokens given the
   current YYCTX, and return the number of tokens stored in YYARG.  If
   YYARG is null, return the number of expected tokens (guaranteed to
   be less than YYNTOKENS).  Return YYENOMEM on memory exhaustion.
   Return 0 if there are more than YYARGN expected tokens, yet fill
   YYARG up to YYARGN. */
static int
yypcontext_expected_tokens (const yypcontext_t *yyctx,
                            yysymbol_kind_t yyarg[], int yyargn)
{
  /* Actual size of YYARG. */
  int yycount = 0;
  int yyn = yypact[+*yyctx->yyssp];
  if (!yypact_value_is_default (yyn))
    {
      /* Start YYX at -YYN if negative to avoid negative indexes in
         YYCHECK.  In other words, skip the first -YYN actions for
         this state because they are default actions.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;
      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yyx;
      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
        if (yycheck[yyx + yyn] == yyx && yyx != YYSYMBOL_YYerror
            && !yytable_value_is_error (yytable[yyx + yyn]))
          {
            if (!yyarg)
              ++yycount;
            else if (yycount == yyargn)
              return 0;
            else
              yyarg[yycount++] = YY_CAST (yysymbol_kind_t, yyx);
          }
    }
  if (yyarg && yycount == 0 && 0 < yyargn)
    yyarg[0] = YYSYMBOL_YYEMPTY;
  return yycount;
}




#ifndef yystrlen
# if defined __GLIBC__ && defined _STRING_H
#  define yystrlen(S) (YY_CAST (YYPTRDIFF_T, strlen (S)))
# else
/* Return the length of YYSTR.  */
static YYPTRDIFF_T
yystrlen (const char *yystr)
{
  YYPTRDIFF_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
# endif
#endif

#ifndef yystpcpy
# if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#  define yystpcpy stpcpy
# else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
# endif
#endif

#ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYPTRDIFF_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYPTRDIFF_T yyn = 0;
      char const *yyp = yystr;
      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            else
              goto append;

          append:
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (yyres)
    return yystpcpy (yyres, yystr) - yyres;
  else
    return yystrlen (yystr);
}
#endif


static int
yy_syntax_error_arguments (const yypcontext_t *yyctx,
                           yysymbol_kind_t yyarg[], int yyargn)
{
  /* Actual size of YYARG. */
  int yycount = 0;
  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yyctx->yytoken != YYSYMBOL_YYEMPTY)
    {
      int yyn;
      if (yyarg)
        yyarg[yycount] = yyctx->yytoken;
      ++yycount;
      yyn = yypcontext_expected_tokens (yyctx,
                                        yyarg ? yyarg + 1 : yyarg, yyargn - 1);
      if (yyn == YYENOMEM)
        return YYENOMEM;
      else
        yycount += yyn;
    }
  return yycount;
}

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return -1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return YYENOMEM if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYPTRDIFF_T *yymsg_alloc, char **yymsg,
                const yypcontext_t *yyctx)
{
  enum { YYARGS_MAX = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat: reported tokens (one for the "unexpected",
     one per "expected"). */
  yysymbol_kind_t yyarg[YYARGS_MAX];
  /* Cumulated lengths of YYARG.  */
  YYPTRDIFF_T yysize = 0;

  /* Actual size of YYARG. */
  int yycount = yy_syntax_error_arguments (yyctx, yyarg, YYARGS_MAX);
  if (yycount == YYENOMEM)
    return YYENOMEM;

  switch (yycount)
    {
#define YYCASE_(N, S)                       \
      case N:                               \
        yyformat = S;                       \
        break
    default: /* Avoid compiler warnings. */
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
    }

  /* Compute error message size.  Don't count the "%s"s, but reserve
     room for the terminator.  */
  yysize = yystrlen (yyformat) - 2 * yycount + 1;
  {
    int yyi;
    for (yyi = 0; yyi < yycount; ++yyi)
      {
        YYPTRDIFF_T yysize1
          = yysize + yytnamerr (YY_NULLPTR, yytname[yyarg[yyi]]);
        if (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM)
          yysize = yysize1;
        else
          return YYENOMEM;
      }
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return -1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yytname[yyarg[yyi++]]);
          yyformat += 2;
        }
      else
        {
          ++yyp;
          ++yyformat;
        }
  }
  return 0;
}


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep, YYLTYPE *yylocationp, CfgLexer *lexer, LogDriver **instance, gpointer arg)
{
  YY_USE (yyvaluep);
  YY_USE (yylocationp);
  YY_USE (lexer);
  YY_USE (instance);
  YY_USE (arg);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  switch (yykind)
    {
    case YYSYMBOL_LL_IDENTIFIER: /* LL_IDENTIFIER  */
#line 373 "modules/affile/affile-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3430 "modules/affile/affile-grammar.c"
        break;

    case YYSYMBOL_LL_STRING: /* LL_STRING  */
#line 373 "modules/affile/affile-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3436 "modules/affile/affile-grammar.c"
        break;

    case YYSYMBOL_LL_BLOCK: /* LL_BLOCK  */
#line 373 "modules/affile/affile-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3442 "modules/affile/affile-grammar.c"
        break;

    case YYSYMBOL_LL_PLUGIN: /* LL_PLUGIN  */
#line 373 "modules/affile/affile-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3448 "modules/affile/affile-grammar.c"
        break;

    case YYSYMBOL_LL_TEMPLATE_REF: /* LL_TEMPLATE_REF  */
#line 373 "modules/affile/affile-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3454 "modules/affile/affile-grammar.c"
        break;

    case YYSYMBOL_string: /* string  */
#line 373 "modules/affile/affile-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3460 "modules/affile/affile-grammar.c"
        break;

    case YYSYMBOL_string_or_number: /* string_or_number  */
#line 373 "modules/affile/affile-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3466 "modules/affile/affile-grammar.c"
        break;

    case YYSYMBOL_normalized_flag: /* normalized_flag  */
#line 373 "modules/affile/affile-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3472 "modules/affile/affile-grammar.c"
        break;

      default:
        break;
    }
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}






/*----------.
| yyparse.  |
`----------*/

int
yyparse (CfgLexer *lexer, LogDriver **instance, gpointer arg)
{
/* Lookahead token kind.  */
int yychar;


/* The semantic value of the lookahead symbol.  */
/* Default value used for initialization, for pacifying older GCCs
   or non-GCC compilers.  */
YY_INITIAL_VALUE (static YYSTYPE yyval_default;)
YYSTYPE yylval YY_INITIAL_VALUE (= yyval_default);

/* Location data for the lookahead symbol.  */
static YYLTYPE yyloc_default
# if defined AFFILE_LTYPE_IS_TRIVIAL && AFFILE_LTYPE_IS_TRIVIAL
  = { 1, 1, 1, 1 }
# endif
;
YYLTYPE yylloc = yyloc_default;

    /* Number of syntax errors so far.  */
    int yynerrs = 0;

    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

    /* The location stack: array, bottom, top.  */
    YYLTYPE yylsa[YYINITDEPTH];
    YYLTYPE *yyls = yylsa;
    YYLTYPE *yylsp = yyls;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
  YYLTYPE yyloc;

  /* The locations where the error started and ended.  */
  YYLTYPE yyerror_range[3];

  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYPTRDIFF_T yymsg_alloc = sizeof yymsgbuf;

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N), yylsp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = AFFILE_EMPTY; /* Cause a token to be read.  */

  yylsp[0] = yylloc;
  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;
        YYLTYPE *yyls1 = yyls;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yyls1, yysize * YYSIZEOF (*yylsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
        yyls = yyls1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
        YYSTACK_RELOCATE (yyls_alloc, yyls);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
      yylsp = yyls + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == AFFILE_EMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex (&yylval, &yylloc, lexer);
    }

  if (yychar <= AFFILE_EOF)
    {
      yychar = AFFILE_EOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == AFFILE_error)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = AFFILE_UNDEF;
      yytoken = YYSYMBOL_YYerror;
      yyerror_range[1] = yylloc;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END
  *++yylsp = yylloc;

  /* Discard the shifted token.  */
  yychar = AFFILE_EMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

  /* Default location. */
  YYLLOC_DEFAULT (yyloc, (yylsp - yylen), yylen);
  yyerror_range[1] = yyloc;
  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* start: LL_CONTEXT_SOURCE source_affile  */
#line 498 "modules/affile/affile-grammar.y"
                                                                 { YYACCEPT; }
#line 3778 "modules/affile/affile-grammar.c"
    break;

  case 3: /* start: LL_CONTEXT_DESTINATION dest_affile  */
#line 499 "modules/affile/affile-grammar.y"
                                                                 { YYACCEPT; }
#line 3784 "modules/affile/affile-grammar.c"
    break;

  case 4: /* source_affile: KW_FILE '(' _inner_src_context_push source_affile_params _inner_src_context_pop ')'  */
#line 503 "modules/affile/affile-grammar.y"
                                                                                                { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 3790 "modules/affile/affile-grammar.c"
    break;

  case 5: /* source_affile: KW_PIPE '(' _inner_src_context_push source_afpipe_params _inner_src_context_pop ')'  */
#line 504 "modules/affile/affile-grammar.y"
                                                                                                { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 3796 "modules/affile/affile-grammar.c"
    break;

  case 6: /* source_affile: KW_STDIN '(' _inner_src_context_push source_stdin_params _inner_src_context_pop ')'  */
#line 505 "modules/affile/affile-grammar.y"
                                                                                                { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 3802 "modules/affile/affile-grammar.c"
    break;

  case 7: /* $@1: %empty  */
#line 507 "modules/affile/affile-grammar.y"
        {
	  WildcardSourceDriver *sd = (WildcardSourceDriver *) wildcard_sd_new(configuration);;
	  *instance = &sd->super.super;
	  affile_grammar_set_wildcard_file_source_driver(sd);
	}
#line 3812 "modules/affile/affile-grammar.c"
    break;

  case 8: /* source_affile: KW_WILDCARD_FILE $@1 '(' _inner_src_context_push source_wildcard_params _inner_src_context_pop ')'  */
#line 511 "modules/affile/affile-grammar.y"
                                                                                        { (yyval.ptr) = last_driver; }
#line 3818 "modules/affile/affile-grammar.c"
    break;

  case 12: /* $@2: %empty  */
#line 525 "modules/affile/affile-grammar.y"
          {
	    AFFileSourceDriver *sd = (AFFileSourceDriver *) stdin_sd_new(configuration);
	    *instance = &sd->super.super;
	    affile_grammar_set_file_source_driver(sd);
	  }
#line 3828 "modules/affile/affile-grammar.c"
    break;

  case 13: /* source_stdin_params: $@2 source_affile_options  */
#line 530 "modules/affile/affile-grammar.y"
                                                { (yyval.ptr) = last_driver; }
#line 3834 "modules/affile/affile-grammar.c"
    break;

  case 14: /* $@3: %empty  */
#line 535 "modules/affile/affile-grammar.y"
          {
	    if (!affile_is_legacy_wildcard_source((yyvsp[0].cptr)))
	      {
	        AFFileSourceDriver *sd = (AFFileSourceDriver *) affile_sd_new((yyvsp[0].cptr), configuration);
	        *instance = &sd->super.super;
	        affile_grammar_set_file_source_driver(sd);
	      }
	    else
	      {
	        WildcardSourceDriver *sd = (WildcardSourceDriver *) wildcard_sd_legacy_new((yyvsp[0].cptr), configuration);
	        last_legacy_wildcard_src_driver = sd;
	        *instance = &sd->super.super;
	        affile_grammar_set_wildcard_file_source_driver(sd);
	      }
	  }
#line 3854 "modules/affile/affile-grammar.c"
    break;

  case 15: /* source_affile_params: string $@3 source_affile_options  */
#line 550 "modules/affile/affile-grammar.y"
                                                { (yyval.ptr) = last_driver; last_legacy_wildcard_src_driver = NULL; free((yyvsp[-2].cptr)); }
#line 3860 "modules/affile/affile-grammar.c"
    break;

  case 19: /* source_affile_option: KW_FOLLOW_FREQ '(' nonnegative_float ')'  */
#line 560 "modules/affile/affile-grammar.y"
                                                                { file_reader_options_set_follow_freq(last_file_reader_options, (long) ((yyvsp[-1].fnum) * 1000)); }
#line 3866 "modules/affile/affile-grammar.c"
    break;

  case 20: /* source_affile_option: KW_PAD_SIZE '(' nonnegative_integer ')'  */
#line 561 "modules/affile/affile-grammar.y"
                                                        { last_log_proto_options->pad_size = (yyvsp[-1].num); }
#line 3872 "modules/affile/affile-grammar.c"
    break;

  case 26: /* source_wildcard_option: KW_BASE_DIR '(' string ')'  */
#line 570 "modules/affile/affile-grammar.y"
                                     { wildcard_sd_set_base_dir(last_driver, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 3878 "modules/affile/affile-grammar.c"
    break;

  case 27: /* source_wildcard_option: KW_FILENAME_PATTERN '(' string ')'  */
#line 572 "modules/affile/affile-grammar.y"
          {
	    wildcard_sd_set_filename_pattern(last_driver, (yyvsp[-1].cptr));
	    free((yyvsp[-1].cptr));
          }
#line 3887 "modules/affile/affile-grammar.c"
    break;

  case 28: /* source_wildcard_option: KW_RECURSIVE '(' yesno ')'  */
#line 576 "modules/affile/affile-grammar.y"
                                     { wildcard_sd_set_recursive(last_driver, (yyvsp[-1].num)); }
#line 3893 "modules/affile/affile-grammar.c"
    break;

  case 29: /* source_wildcard_option: KW_MAX_FILES '(' positive_integer ')'  */
#line 577 "modules/affile/affile-grammar.y"
                                                { wildcard_sd_set_max_files(last_driver, (yyvsp[-1].num)); }
#line 3899 "modules/affile/affile-grammar.c"
    break;

  case 30: /* source_wildcard_option: KW_MONITOR_METHOD '(' string ')'  */
#line 578 "modules/affile/affile-grammar.y"
                                           { CHECK_ERROR(wildcard_sd_set_monitor_method(last_driver, (yyvsp[-1].cptr)), (yylsp[-1]), "Invalid monitor-method"); free((yyvsp[-1].cptr)); }
#line 3905 "modules/affile/affile-grammar.c"
    break;

  case 32: /* source_legacy_wildcard_option: KW_FORCE_DIRECTORY_POLLING '(' yesno ')'  */
#line 584 "modules/affile/affile-grammar.y"
          {
	    CHECK_ERROR(last_legacy_wildcard_src_driver, (yylsp[-3]), "Invalid option, force-directory-polling() can only be used in legacy wildcard file sources");
	    wildcard_sd_set_monitor_method(&last_legacy_wildcard_src_driver->super.super, (yyvsp[-1].num) ? "poll" : "auto");
	  }
#line 3914 "modules/affile/affile-grammar.c"
    break;

  case 33: /* source_legacy_wildcard_option: KW_RECURSIVE '(' yesno ')'  */
#line 589 "modules/affile/affile-grammar.y"
          {
	    CHECK_ERROR(last_legacy_wildcard_src_driver, (yylsp[-3]), "Invalid option, recursive() can only be used in legacy wildcard file sources");
	    wildcard_sd_set_recursive(&last_legacy_wildcard_src_driver->super.super, (yyvsp[-1].num));
	  }
#line 3923 "modules/affile/affile-grammar.c"
    break;

  case 34: /* $@4: %empty  */
#line 597 "modules/affile/affile-grammar.y"
          {
	    AFFileSourceDriver *sd = (AFFileSourceDriver *) pipe_sd_new((yyvsp[0].cptr), configuration);
	    *instance = &sd->super.super;
	    affile_grammar_set_file_source_driver(sd);
	  }
#line 3933 "modules/affile/affile-grammar.c"
    break;

  case 35: /* source_afpipe_params: string $@4 source_afpipe_options  */
#line 602 "modules/affile/affile-grammar.y"
                                                        { (yyval.ptr) = last_driver; free((yyvsp[-2].cptr)); }
#line 3939 "modules/affile/affile-grammar.c"
    break;

  case 38: /* source_afpipe_option: KW_OPTIONAL '(' yesno ')'  */
#line 611 "modules/affile/affile-grammar.y"
                                                        { last_driver->optional = (yyvsp[-1].num); }
#line 3945 "modules/affile/affile-grammar.c"
    break;

  case 39: /* source_afpipe_option: KW_PAD_SIZE '(' nonnegative_integer ')'  */
#line 612 "modules/affile/affile-grammar.y"
                                                        { last_log_proto_options->pad_size = (yyvsp[-1].num); }
#line 3951 "modules/affile/affile-grammar.c"
    break;

  case 40: /* source_afpipe_option: KW_CREATE_DIRS '(' yesno ')'  */
#line 613 "modules/affile/affile-grammar.y"
                                                        { pipe_sd_set_create_dirs(last_driver, (yyvsp[-1].num)); }
#line 3957 "modules/affile/affile-grammar.c"
    break;

  case 45: /* multi_line_timeout: KW_MULTI_LINE_TIMEOUT '(' nonnegative_integer ')'  */
#line 622 "modules/affile/affile-grammar.y"
          {
	    	file_reader_options_set_multi_line_timeout(last_file_reader_options, ((yyvsp[-1].num) * 1000));
	  }
#line 3965 "modules/affile/affile-grammar.c"
    break;

  case 46: /* dest_affile: KW_FILE '(' _inner_dest_context_push dest_affile_params _inner_dest_context_pop ')'  */
#line 628 "modules/affile/affile-grammar.y"
                                                                                                { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 3971 "modules/affile/affile-grammar.c"
    break;

  case 47: /* dest_affile: KW_PIPE '(' _inner_dest_context_push dest_afpipe_params _inner_dest_context_pop ')'  */
#line 629 "modules/affile/affile-grammar.y"
                                                                                                { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 3977 "modules/affile/affile-grammar.c"
    break;

  case 48: /* dest_affile: KW_STDOUT '(' _inner_dest_context_push dest_stdout_params _inner_dest_context_pop ')'  */
#line 630 "modules/affile/affile-grammar.y"
                                                                                                { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 3983 "modules/affile/affile-grammar.c"
    break;

  case 49: /* $@5: %empty  */
#line 635 "modules/affile/affile-grammar.y"
          {
	    last_driver = *instance = affile_dd_new((yyvsp[0].ptr), configuration);
	    last_writer_options = &((AFFileDestDriver *) last_driver)->writer_options;
	    last_file_perm_options = &((AFFileDestDriver *) last_driver)->file_opener_options.file_perm_options;
	  }
#line 3993 "modules/affile/affile-grammar.c"
    break;

  case 50: /* dest_affile_params: template_content $@5 dest_affile_options  */
#line 640 "modules/affile/affile-grammar.y"
                                                        { (yyval.ptr) = last_driver; }
#line 3999 "modules/affile/affile-grammar.c"
    break;

  case 56: /* dest_affile_option: KW_OPTIONAL '(' yesno ')'  */
#line 652 "modules/affile/affile-grammar.y"
                                                { last_driver->optional = (yyvsp[-1].num); }
#line 4005 "modules/affile/affile-grammar.c"
    break;

  case 57: /* dest_affile_option: KW_OVERWRITE_IF_OLDER '(' nonnegative_integer ')'  */
#line 653 "modules/affile/affile-grammar.y"
                                                                { affile_dd_set_overwrite_if_older(last_driver, (yyvsp[-1].num)); }
#line 4011 "modules/affile/affile-grammar.c"
    break;

  case 58: /* dest_affile_option: KW_SYMLINK_AS '(' string ')'  */
#line 654 "modules/affile/affile-grammar.y"
                                                { affile_dd_set_symlink_as(last_driver, (yyvsp[-1].cptr)); }
#line 4017 "modules/affile/affile-grammar.c"
    break;

  case 59: /* dest_affile_option: KW_FSYNC '(' yesno ')'  */
#line 655 "modules/affile/affile-grammar.y"
                                                { affile_dd_set_fsync(last_driver, (yyvsp[-1].num)); }
#line 4023 "modules/affile/affile-grammar.c"
    break;

  case 61: /* $@6: %empty  */
#line 661 "modules/affile/affile-grammar.y"
          {
	    last_driver = *instance = pipe_dd_new((yyvsp[0].ptr), configuration);
	    last_writer_options = &((AFFileDestDriver *) last_driver)->writer_options;
	    last_file_perm_options = &((AFFileDestDriver *) last_driver)->file_opener_options.file_perm_options;
	  }
#line 4033 "modules/affile/affile-grammar.c"
    break;

  case 62: /* dest_afpipe_params: template_content $@6 dest_afpipe_options  */
#line 666 "modules/affile/affile-grammar.y"
                                                { (yyval.ptr) = last_driver; }
#line 4039 "modules/affile/affile-grammar.c"
    break;

  case 69: /* dest_affile_common_option: KW_TIME_REAP '(' nonnegative_integer ')'  */
#line 682 "modules/affile/affile-grammar.y"
                                                                { affile_dd_set_time_reap(last_driver, (yyvsp[-1].num)); }
#line 4045 "modules/affile/affile-grammar.c"
    break;

  case 70: /* dest_affile_common_option: KW_CREATE_DIRS '(' yesno ')'  */
#line 683 "modules/affile/affile-grammar.y"
                                                { affile_dd_set_create_dirs(last_driver, (yyvsp[-1].num)); }
#line 4051 "modules/affile/affile-grammar.c"
    break;

  case 71: /* $@7: %empty  */
#line 688 "modules/affile/affile-grammar.y"
          {
            last_driver = *instance = stdout_dd_new(configuration);
            last_writer_options = &((AFFileDestDriver *) last_driver)->writer_options;
            last_file_perm_options = &((AFFileDestDriver *) last_driver)->file_opener_options.file_perm_options;
          }
#line 4061 "modules/affile/affile-grammar.c"
    break;

  case 77: /* template_content_inner: string  */
#line 973 "modules/affile/affile-grammar.y"
        {
          GError *error = NULL;

          CHECK_ERROR_GERROR(log_template_compile((yyvsp[-1].ptr), (yyvsp[0].cptr), &error), (yylsp[0]), error, "Error compiling template");
          free((yyvsp[0].cptr));
        }
#line 4072 "modules/affile/affile-grammar.c"
    break;

  case 78: /* template_content_inner: type_hint '(' string_or_number ')'  */
#line 980 "modules/affile/affile-grammar.y"
        {
          GError *error = NULL;

          CHECK_ERROR_GERROR(log_template_compile((yyvsp[-4].ptr), (yyvsp[-1].cptr), &error), (yylsp[-1]), error, "Error compiling template");
          free((yyvsp[-1].cptr));

          log_template_set_type_hint_value((yyvsp[-4].ptr), (yyvsp[-3].num));
        }
#line 4085 "modules/affile/affile-grammar.c"
    break;

  case 79: /* template_content_inner: LL_NUMBER  */
#line 989 "modules/affile/affile-grammar.y"
        {
          gchar decimal[32];

          g_snprintf(decimal, sizeof(decimal), "%" G_GINT64_FORMAT, (yyvsp[0].num));
          log_template_compile_literal_string((yyvsp[-1].ptr), decimal);
          log_template_set_type_hint((yyvsp[-1].ptr), "int64", NULL);
        }
#line 4097 "modules/affile/affile-grammar.c"
    break;

  case 80: /* template_content_inner: LL_FLOAT  */
#line 997 "modules/affile/affile-grammar.y"
        {
          log_template_compile_literal_string((yyvsp[-1].ptr), lexer->token_text->str);
          log_template_set_type_hint((yyvsp[-1].ptr), "float", NULL);
        }
#line 4106 "modules/affile/affile-grammar.c"
    break;

  case 81: /* type_hint: LL_IDENTIFIER  */
#line 1005 "modules/affile/affile-grammar.y"
          {
            LogMessageValueType type;
            GError *error = NULL;

            CHECK_ERROR_GERROR(type_hint_parse((yyvsp[0].cptr), &type, &error), (yylsp[0]), error, "Unknown type hint");
            free((yyvsp[0].cptr));
            (yyval.num) = type;
          }
#line 4119 "modules/affile/affile-grammar.c"
    break;

  case 82: /* @10: %empty  */
#line 1015 "modules/affile/affile-grammar.y"
               {
            (yyval.ptr) = log_template_new(configuration, NULL);
          }
#line 4127 "modules/affile/affile-grammar.c"
    break;

  case 83: /* template_content: @10 template_content_inner  */
#line 1017 "modules/affile/affile-grammar.y"
                                                                            { (yyval.ptr) = (yyvsp[-1].ptr); }
#line 4133 "modules/affile/affile-grammar.c"
    break;

  case 84: /* template_name_or_content: _template_ref_context_push template_name_or_content_tail  */
#line 1026 "modules/affile/affile-grammar.y"
                                                                            { (yyval.ptr) = (yyvsp[0].ptr); }
#line 4139 "modules/affile/affile-grammar.c"
    break;

  case 85: /* template_name_or_content_tail: LL_TEMPLATE_REF  */
#line 1030 "modules/affile/affile-grammar.y"
                                                                            { (yyval.ptr) = cfg_tree_lookup_template(&configuration->tree, (yyvsp[0].cptr)); free((yyvsp[0].cptr)); }
#line 4145 "modules/affile/affile-grammar.c"
    break;

  case 86: /* template_name_or_content_tail: template_content  */
#line 1031 "modules/affile/affile-grammar.y"
                                                                            { (yyval.ptr) = (yyvsp[0].ptr); }
#line 4151 "modules/affile/affile-grammar.c"
    break;

  case 89: /* yesno_strict: KW_YES  */
#line 1042 "modules/affile/affile-grammar.y"
                                                { (yyval.num) = 1; }
#line 4157 "modules/affile/affile-grammar.c"
    break;

  case 90: /* yesno_strict: KW_NO  */
#line 1043 "modules/affile/affile-grammar.y"
                                                { (yyval.num) = 0; }
#line 4163 "modules/affile/affile-grammar.c"
    break;

  case 92: /* yesno: LL_NUMBER  */
#line 1048 "modules/affile/affile-grammar.y"
                                                { (yyval.num) = (yyvsp[0].num); }
#line 4169 "modules/affile/affile-grammar.c"
    break;

  case 93: /* dnsmode: yesno  */
#line 1058 "modules/affile/affile-grammar.y"
                                                { (yyval.num) = (yyvsp[0].num); }
#line 4175 "modules/affile/affile-grammar.c"
    break;

  case 94: /* dnsmode: KW_PERSIST_ONLY  */
#line 1059 "modules/affile/affile-grammar.y"
                                                { (yyval.num) = 2; }
#line 4181 "modules/affile/affile-grammar.c"
    break;

  case 95: /* nonnegative_integer64: LL_NUMBER  */
#line 1064 "modules/affile/affile-grammar.y"
          {
            CHECK_ERROR(((yyvsp[0].num) >= 0), (yylsp[0]), "It cannot be negative");
          }
#line 4189 "modules/affile/affile-grammar.c"
    break;

  case 96: /* nonnegative_integer: nonnegative_integer64  */
#line 1071 "modules/affile/affile-grammar.y"
          {
            CHECK_ERROR(((yyvsp[0].num) <= G_MAXINT32), (yylsp[0]), "Must be smaller than 2^31");
          }
#line 4197 "modules/affile/affile-grammar.c"
    break;

  case 97: /* positive_integer64: LL_NUMBER  */
#line 1078 "modules/affile/affile-grammar.y"
          {
            CHECK_ERROR(((yyvsp[0].num) > 0), (yylsp[0]), "Must be positive");
          }
#line 4205 "modules/affile/affile-grammar.c"
    break;

  case 98: /* positive_integer: positive_integer64  */
#line 1085 "modules/affile/affile-grammar.y"
          {
            CHECK_ERROR(((yyvsp[0].num) <= G_MAXINT32), (yylsp[0]), "Must be smaller than 2^31");
          }
#line 4213 "modules/affile/affile-grammar.c"
    break;

  case 99: /* nonnegative_float: LL_FLOAT  */
#line 1092 "modules/affile/affile-grammar.y"
          {
            CHECK_ERROR(((yyvsp[0].fnum) >= 0), (yylsp[0]), "It cannot be negative");
          }
#line 4221 "modules/affile/affile-grammar.c"
    break;

  case 100: /* nonnegative_float: nonnegative_integer  */
#line 1096 "modules/affile/affile-grammar.y"
          {
            (yyval.fnum) = (double) (yyvsp[0].num);
          }
#line 4229 "modules/affile/affile-grammar.c"
    break;

  case 101: /* string_or_number: string  */
#line 1113 "modules/affile/affile-grammar.y"
                                                { (yyval.cptr) = (yyvsp[0].cptr); }
#line 4235 "modules/affile/affile-grammar.c"
    break;

  case 102: /* string_or_number: LL_NUMBER  */
#line 1114 "modules/affile/affile-grammar.y"
                                                { (yyval.cptr) = strdup(lexer->token_text->str); }
#line 4241 "modules/affile/affile-grammar.c"
    break;

  case 103: /* string_or_number: LL_FLOAT  */
#line 1115 "modules/affile/affile-grammar.y"
                                                { (yyval.cptr) = strdup(lexer->token_text->str); }
#line 4247 "modules/affile/affile-grammar.c"
    break;

  case 104: /* normalized_flag: string  */
#line 1146 "modules/affile/affile-grammar.y"
                                                { (yyval.cptr) = normalize_flag((yyvsp[0].cptr)); free((yyvsp[0].cptr)); }
#line 4253 "modules/affile/affile-grammar.c"
    break;

  case 105: /* string_list: string_list_build  */
#line 1150 "modules/affile/affile-grammar.y"
                                                { (yyval.ptr) = (yyvsp[0].ptr); }
#line 4259 "modules/affile/affile-grammar.c"
    break;

  case 106: /* string_list_build: string string_list_build  */
#line 1154 "modules/affile/affile-grammar.y"
                                                { (yyval.ptr) = g_list_prepend((yyvsp[0].ptr), g_strdup((yyvsp[-1].cptr))); free((yyvsp[-1].cptr)); }
#line 4265 "modules/affile/affile-grammar.c"
    break;

  case 107: /* string_list_build: %empty  */
#line 1155 "modules/affile/affile-grammar.y"
                                                { (yyval.ptr) = NULL; }
#line 4271 "modules/affile/affile-grammar.c"
    break;

  case 108: /* severity_string: string  */
#line 1165 "modules/affile/affile-grammar.y"
          {
	    /* return the numeric value of the "level" */
	    int n = syslog_name_lookup_severity_by_name((yyvsp[0].cptr));
	    CHECK_ERROR((n != -1), (yylsp[0]), "Unknown priority level\"%s\"", (yyvsp[0].cptr));
	    free((yyvsp[0].cptr));
            (yyval.num) = n;
	  }
#line 4283 "modules/affile/affile-grammar.c"
    break;

  case 109: /* facility_string: string  */
#line 1176 "modules/affile/affile-grammar.y"
          {
            /* return the numeric value of facility */
	    int n = syslog_name_lookup_facility_by_name((yyvsp[0].cptr));
	    CHECK_ERROR((n != -1), (yylsp[0]), "Unknown facility \"%s\"", (yyvsp[0].cptr));
	    free((yyvsp[0].cptr));
	    (yyval.num) = n;
	  }
#line 4295 "modules/affile/affile-grammar.c"
    break;

  case 110: /* facility_string: KW_SYSLOG  */
#line 1183 "modules/affile/affile-grammar.y"
                                                { (yyval.num) = LOG_SYSLOG; }
#line 4301 "modules/affile/affile-grammar.c"
    break;

  case 111: /* driver_option: KW_PERSIST_NAME '(' string ')'  */
#line 1192 "modules/affile/affile-grammar.y"
                                         { log_pipe_set_persist_name(&last_driver->super, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4307 "modules/affile/affile-grammar.c"
    break;

  case 112: /* driver_option: KW_INTERNAL '(' yesno ')'  */
#line 1193 "modules/affile/affile-grammar.y"
                                    { log_pipe_set_internal(&last_driver->super, (yyvsp[-1].num)); }
#line 4313 "modules/affile/affile-grammar.c"
    break;

  case 113: /* inner_source: LL_PLUGIN  */
#line 1198 "modules/affile/affile-grammar.y"
          {
            Plugin *p;
            gint context = LL_CONTEXT_INNER_SRC;
            gpointer value;

            p = cfg_find_plugin(configuration, context, (yyvsp[0].cptr));
            CHECK_ERROR(p, (yylsp[0]), "%s plugin %s not found", cfg_lexer_lookup_context_name_by_type(context), (yyvsp[0].cptr));

            value = cfg_parse_plugin(configuration, p, &(yylsp[0]), last_driver);

            free((yyvsp[0].cptr));
            if (!value)
              {
                YYERROR;
              }
            if (!log_driver_add_plugin(last_driver, (LogDriverPlugin *) value))
              {
                log_driver_plugin_free(value);
                CHECK_ERROR(TRUE, (yylsp[0]), "Error while registering the plugin %s in this destination", (yyvsp[0].cptr));
              }
          }
#line 4339 "modules/affile/affile-grammar.c"
    break;

  case 116: /* inner_dest: LL_PLUGIN  */
#line 1230 "modules/affile/affile-grammar.y"
          {
            Plugin *p;
            gint context = LL_CONTEXT_INNER_DEST;
            gpointer value;

            p = cfg_find_plugin(configuration, context, (yyvsp[0].cptr));
            CHECK_ERROR(p, (yylsp[0]), "%s plugin %s not found", cfg_lexer_lookup_context_name_by_type(context), (yyvsp[0].cptr));

            value = cfg_parse_plugin(configuration, p, &(yylsp[0]), last_driver);

            free((yyvsp[0].cptr));
            if (!value)
              {
                YYERROR;
              }
            if (!log_driver_add_plugin(last_driver, (LogDriverPlugin *) value))
              {
                log_driver_plugin_free(value);
                CHECK_ERROR(TRUE, (yylsp[0]), "Error while registering the plugin %s in this destination", (yyvsp[0].cptr));
              }
          }
#line 4365 "modules/affile/affile-grammar.c"
    break;

  case 117: /* dest_driver_option: KW_LOG_FIFO_SIZE '(' positive_integer ')'  */
#line 1257 "modules/affile/affile-grammar.y"
                                                        { ((LogDestDriver *) last_driver)->log_fifo_size = (yyvsp[-1].num); }
#line 4371 "modules/affile/affile-grammar.c"
    break;

  case 118: /* dest_driver_option: KW_THROTTLE '(' nonnegative_integer ')'  */
#line 1258 "modules/affile/affile-grammar.y"
                                                          { ((LogDestDriver *) last_driver)->throttle = (yyvsp[-1].num); }
#line 4377 "modules/affile/affile-grammar.c"
    break;

  case 121: /* source_option: KW_LOG_IW_SIZE '(' positive_integer ')'  */
#line 1309 "modules/affile/affile-grammar.y"
                                                        { last_source_options->init_window_size = (yyvsp[-1].num); }
#line 4383 "modules/affile/affile-grammar.c"
    break;

  case 122: /* source_option: KW_CHAIN_HOSTNAMES '(' yesno ')'  */
#line 1310 "modules/affile/affile-grammar.y"
                                                { last_source_options->chain_hostnames = (yyvsp[-1].num); }
#line 4389 "modules/affile/affile-grammar.c"
    break;

  case 123: /* source_option: KW_KEEP_HOSTNAME '(' yesno ')'  */
#line 1311 "modules/affile/affile-grammar.y"
                                                { last_source_options->keep_hostname = (yyvsp[-1].num); }
#line 4395 "modules/affile/affile-grammar.c"
    break;

  case 124: /* source_option: KW_PROGRAM_OVERRIDE '(' string ')'  */
#line 1312 "modules/affile/affile-grammar.y"
                                                { last_source_options->program_override = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4401 "modules/affile/affile-grammar.c"
    break;

  case 125: /* source_option: KW_HOST_OVERRIDE '(' string ')'  */
#line 1313 "modules/affile/affile-grammar.y"
                                                { last_source_options->host_override = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4407 "modules/affile/affile-grammar.c"
    break;

  case 126: /* source_option: KW_LOG_PREFIX '(' string ')'  */
#line 1314 "modules/affile/affile-grammar.y"
                                                { gchar *p = strrchr((yyvsp[-1].cptr), ':'); if (p) *p = 0; last_source_options->program_override = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4413 "modules/affile/affile-grammar.c"
    break;

  case 127: /* source_option: KW_KEEP_TIMESTAMP '(' yesno ')'  */
#line 1315 "modules/affile/affile-grammar.y"
                                                { last_source_options->keep_timestamp = (yyvsp[-1].num); }
#line 4419 "modules/affile/affile-grammar.c"
    break;

  case 128: /* source_option: KW_READ_OLD_RECORDS '(' yesno ')'  */
#line 1316 "modules/affile/affile-grammar.y"
                                                { last_source_options->read_old_records = (yyvsp[-1].num); }
#line 4425 "modules/affile/affile-grammar.c"
    break;

  case 129: /* source_option: KW_USE_SYSLOGNG_PID '(' yesno ')'  */
#line 1317 "modules/affile/affile-grammar.y"
                                                { last_source_options->use_syslogng_pid = (yyvsp[-1].num); }
#line 4431 "modules/affile/affile-grammar.c"
    break;

  case 130: /* source_option: KW_TAGS '(' string_list ')'  */
#line 1318 "modules/affile/affile-grammar.y"
                                                { log_source_options_set_tags(last_source_options, (yyvsp[-1].ptr)); }
#line 4437 "modules/affile/affile-grammar.c"
    break;

  case 131: /* $@13: %empty  */
#line 1319 "modules/affile/affile-grammar.y"
          { last_host_resolve_options = &last_source_options->host_resolve_options; }
#line 4443 "modules/affile/affile-grammar.c"
    break;

  case 133: /* source_reader_option: KW_CHECK_HOSTNAME '(' yesno ')'  */
#line 1326 "modules/affile/affile-grammar.y"
                                                { last_reader_options->check_hostname = (yyvsp[-1].num); }
#line 4449 "modules/affile/affile-grammar.c"
    break;

  case 135: /* source_reader_option: KW_LOG_FETCH_LIMIT '(' positive_integer ')'  */
#line 1328 "modules/affile/affile-grammar.y"
                                                        { last_reader_options->fetch_limit = (yyvsp[-1].num); }
#line 4455 "modules/affile/affile-grammar.c"
    break;

  case 136: /* source_reader_option: KW_FORMAT '(' string ')'  */
#line 1329 "modules/affile/affile-grammar.y"
                                                { last_reader_options->parse_options.format = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4461 "modules/affile/affile-grammar.c"
    break;

  case 137: /* $@14: %empty  */
#line 1330 "modules/affile/affile-grammar.y"
          { last_source_options = &last_reader_options->super; }
#line 4467 "modules/affile/affile-grammar.c"
    break;

  case 139: /* $@15: %empty  */
#line 1331 "modules/affile/affile-grammar.y"
          { last_proto_server_options = &last_reader_options->proto_options.super; }
#line 4473 "modules/affile/affile-grammar.c"
    break;

  case 141: /* $@16: %empty  */
#line 1332 "modules/affile/affile-grammar.y"
          { last_msg_format_options = &last_reader_options->parse_options; }
#line 4479 "modules/affile/affile-grammar.c"
    break;

  case 143: /* source_reader_option_flags: string source_reader_option_flags  */
#line 1336 "modules/affile/affile-grammar.y"
                                                { CHECK_ERROR(log_reader_options_process_flag(last_reader_options, (yyvsp[-1].cptr)), (yylsp[-1]), "Unknown flag \"%s\"", (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4485 "modules/affile/affile-grammar.c"
    break;

  case 144: /* source_reader_option_flags: KW_CHECK_HOSTNAME source_reader_option_flags  */
#line 1337 "modules/affile/affile-grammar.y"
                                                           { log_reader_options_process_flag(last_reader_options, "check-hostname"); }
#line 4491 "modules/affile/affile-grammar.c"
    break;

  case 146: /* source_proto_option: KW_ENCODING '(' string ')'  */
#line 1344 "modules/affile/affile-grammar.y"
          {
            CHECK_ERROR(log_proto_server_options_set_encoding(last_proto_server_options, (yyvsp[-1].cptr)),
                        (yylsp[-1]),
                        "unknown encoding \"%s\"", (yyvsp[-1].cptr));
            free((yyvsp[-1].cptr));
          }
#line 4502 "modules/affile/affile-grammar.c"
    break;

  case 147: /* source_proto_option: KW_LOG_MSG_SIZE '(' positive_integer ')'  */
#line 1350 "modules/affile/affile-grammar.y"
                                                        { last_proto_server_options->max_msg_size = (yyvsp[-1].num); }
#line 4508 "modules/affile/affile-grammar.c"
    break;

  case 148: /* source_proto_option: KW_TRIM_LARGE_MESSAGES '(' yesno ')'  */
#line 1351 "modules/affile/affile-grammar.y"
                                                        { last_proto_server_options->trim_large_messages = (yyvsp[-1].num); }
#line 4514 "modules/affile/affile-grammar.c"
    break;

  case 149: /* host_resolve_option: KW_USE_FQDN '(' yesno ')'  */
#line 1355 "modules/affile/affile-grammar.y"
                                                { last_host_resolve_options->use_fqdn = (yyvsp[-1].num); }
#line 4520 "modules/affile/affile-grammar.c"
    break;

  case 150: /* host_resolve_option: KW_USE_DNS '(' dnsmode ')'  */
#line 1356 "modules/affile/affile-grammar.y"
                                                { last_host_resolve_options->use_dns = (yyvsp[-1].num); }
#line 4526 "modules/affile/affile-grammar.c"
    break;

  case 151: /* host_resolve_option: KW_DNS_CACHE '(' yesno ')'  */
#line 1357 "modules/affile/affile-grammar.y"
                                                { last_host_resolve_options->use_dns_cache = (yyvsp[-1].num); }
#line 4532 "modules/affile/affile-grammar.c"
    break;

  case 152: /* host_resolve_option: KW_NORMALIZE_HOSTNAMES '(' yesno ')'  */
#line 1358 "modules/affile/affile-grammar.y"
                                                { last_host_resolve_options->normalize_hostnames = (yyvsp[-1].num); }
#line 4538 "modules/affile/affile-grammar.c"
    break;

  case 153: /* msg_format_option: KW_TIME_ZONE '(' string ')'  */
#line 1362 "modules/affile/affile-grammar.y"
                                                { last_msg_format_options->recv_time_zone = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4544 "modules/affile/affile-grammar.c"
    break;

  case 154: /* msg_format_option: KW_DEFAULT_SEVERITY '(' severity_string ')'  */
#line 1364 "modules/affile/affile-grammar.y"
          {
	    if (last_msg_format_options->default_pri == 0xFFFF)
	      last_msg_format_options->default_pri = LOG_USER;
	    last_msg_format_options->default_pri = (last_msg_format_options->default_pri & ~SYSLOG_PRIMASK) | (yyvsp[-1].num);
          }
#line 4554 "modules/affile/affile-grammar.c"
    break;

  case 155: /* msg_format_option: KW_DEFAULT_FACILITY '(' facility_string ')'  */
#line 1370 "modules/affile/affile-grammar.y"
          {
	    if (last_msg_format_options->default_pri == 0xFFFF)
	      last_msg_format_options->default_pri = LOG_NOTICE;
	    last_msg_format_options->default_pri = (last_msg_format_options->default_pri & SYSLOG_PRIMASK) | (yyvsp[-1].num);
          }
#line 4564 "modules/affile/affile-grammar.c"
    break;

  case 156: /* msg_format_option: KW_SDATA_PREFIX '(' string ')'  */
#line 1376 "modules/affile/affile-grammar.y"
          {
            CHECK_ERROR(msg_format_options_set_sdata_prefix(last_msg_format_options, (yyvsp[-1].cptr)), (yylsp[-1]), "Prefix is too long \"%s\"", (yyvsp[-1].cptr));
            free((yyvsp[-1].cptr));
          }
#line 4573 "modules/affile/affile-grammar.c"
    break;

  case 157: /* dest_writer_option: KW_FLAGS '(' dest_writer_options_flags ')'  */
#line 1390 "modules/affile/affile-grammar.y"
                                                     { last_writer_options->options = (yyvsp[-1].num); }
#line 4579 "modules/affile/affile-grammar.c"
    break;

  case 158: /* dest_writer_option: KW_FLUSH_LINES '(' nonnegative_integer ')'  */
#line 1391 "modules/affile/affile-grammar.y"
                                                                { last_writer_options->flush_lines = (yyvsp[-1].num); }
#line 4585 "modules/affile/affile-grammar.c"
    break;

  case 159: /* dest_writer_option: KW_FLUSH_TIMEOUT '(' positive_integer ')'  */
#line 1392 "modules/affile/affile-grammar.y"
                                                        { }
#line 4591 "modules/affile/affile-grammar.c"
    break;

  case 160: /* dest_writer_option: KW_SUPPRESS '(' nonnegative_integer ')'  */
#line 1393 "modules/affile/affile-grammar.y"
                                                             { last_writer_options->suppress = (yyvsp[-1].num); }
#line 4597 "modules/affile/affile-grammar.c"
    break;

  case 161: /* dest_writer_option: KW_TEMPLATE '(' template_name_or_content ')'  */
#line 1394 "modules/affile/affile-grammar.y"
                                                             { last_writer_options->template = (yyvsp[-1].ptr); }
#line 4603 "modules/affile/affile-grammar.c"
    break;

  case 162: /* dest_writer_option: KW_PAD_SIZE '(' nonnegative_integer ')'  */
#line 1395 "modules/affile/affile-grammar.y"
                                                          { last_writer_options->padding = (yyvsp[-1].num); }
#line 4609 "modules/affile/affile-grammar.c"
    break;

  case 163: /* dest_writer_option: KW_TRUNCATE_SIZE '(' nonnegative_integer ')'  */
#line 1396 "modules/affile/affile-grammar.y"
                                                               { last_writer_options->truncate_size = (yyvsp[-1].num); }
#line 4615 "modules/affile/affile-grammar.c"
    break;

  case 164: /* dest_writer_option: KW_MARK_FREQ '(' nonnegative_integer ')'  */
#line 1397 "modules/affile/affile-grammar.y"
                                                          { last_writer_options->mark_freq = (yyvsp[-1].num); }
#line 4621 "modules/affile/affile-grammar.c"
    break;

  case 165: /* dest_writer_option: KW_MARK_MODE '(' KW_INTERNAL ')'  */
#line 1398 "modules/affile/affile-grammar.y"
                                                { log_writer_options_set_mark_mode(last_writer_options, "internal"); }
#line 4627 "modules/affile/affile-grammar.c"
    break;

  case 166: /* dest_writer_option: KW_MARK_MODE '(' string ')'  */
#line 1400 "modules/affile/affile-grammar.y"
          {
	    CHECK_ERROR(cfg_lookup_mark_mode((yyvsp[-1].cptr)) != -1, (yylsp[-1]), "illegal mark mode \"%s\"", (yyvsp[-1].cptr));
            log_writer_options_set_mark_mode(last_writer_options, (yyvsp[-1].cptr));
            free((yyvsp[-1].cptr));
          }
#line 4637 "modules/affile/affile-grammar.c"
    break;

  case 167: /* dest_writer_option: KW_TIME_REOPEN '(' positive_integer ')'  */
#line 1405 "modules/affile/affile-grammar.y"
                                                  { last_writer_options->time_reopen = (yyvsp[-1].num); }
#line 4643 "modules/affile/affile-grammar.c"
    break;

  case 168: /* $@17: %empty  */
#line 1406 "modules/affile/affile-grammar.y"
          { last_template_options = &last_writer_options->template_options; }
#line 4649 "modules/affile/affile-grammar.c"
    break;

  case 170: /* dest_writer_options_flags: normalized_flag dest_writer_options_flags  */
#line 1410 "modules/affile/affile-grammar.y"
                                                      { (yyval.num) = log_writer_options_lookup_flag((yyvsp[-1].cptr)) | (yyvsp[0].num); free((yyvsp[-1].cptr)); }
#line 4655 "modules/affile/affile-grammar.c"
    break;

  case 171: /* dest_writer_options_flags: %empty  */
#line 1411 "modules/affile/affile-grammar.y"
                                                      { (yyval.num) = 0; }
#line 4661 "modules/affile/affile-grammar.c"
    break;

  case 172: /* file_perm_option: KW_OWNER '(' string_or_number ')'  */
#line 1415 "modules/affile/affile-grammar.y"
                                                { file_perm_options_set_file_uid(last_file_perm_options, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4667 "modules/affile/affile-grammar.c"
    break;

  case 173: /* file_perm_option: KW_OWNER '(' ')'  */
#line 1416 "modules/affile/affile-grammar.y"
                                                { file_perm_options_dont_change_file_uid(last_file_perm_options); }
#line 4673 "modules/affile/affile-grammar.c"
    break;

  case 174: /* file_perm_option: KW_GROUP '(' string_or_number ')'  */
#line 1417 "modules/affile/affile-grammar.y"
                                                { file_perm_options_set_file_gid(last_file_perm_options, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4679 "modules/affile/affile-grammar.c"
    break;

  case 175: /* file_perm_option: KW_GROUP '(' ')'  */
#line 1418 "modules/affile/affile-grammar.y"
                                                { file_perm_options_dont_change_file_gid(last_file_perm_options); }
#line 4685 "modules/affile/affile-grammar.c"
    break;

  case 176: /* file_perm_option: KW_PERM '(' LL_NUMBER ')'  */
#line 1419 "modules/affile/affile-grammar.y"
                                                { file_perm_options_set_file_perm(last_file_perm_options, (yyvsp[-1].num)); }
#line 4691 "modules/affile/affile-grammar.c"
    break;

  case 177: /* file_perm_option: KW_PERM '(' ')'  */
#line 1420 "modules/affile/affile-grammar.y"
                                                { file_perm_options_dont_change_file_perm(last_file_perm_options); }
#line 4697 "modules/affile/affile-grammar.c"
    break;

  case 178: /* file_perm_option: KW_DIR_OWNER '(' string_or_number ')'  */
#line 1421 "modules/affile/affile-grammar.y"
                                                { file_perm_options_set_dir_uid(last_file_perm_options, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4703 "modules/affile/affile-grammar.c"
    break;

  case 179: /* file_perm_option: KW_DIR_OWNER '(' ')'  */
#line 1422 "modules/affile/affile-grammar.y"
                                                { file_perm_options_dont_change_dir_uid(last_file_perm_options); }
#line 4709 "modules/affile/affile-grammar.c"
    break;

  case 180: /* file_perm_option: KW_DIR_GROUP '(' string_or_number ')'  */
#line 1423 "modules/affile/affile-grammar.y"
                                                { file_perm_options_set_dir_gid(last_file_perm_options, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4715 "modules/affile/affile-grammar.c"
    break;

  case 181: /* file_perm_option: KW_DIR_GROUP '(' ')'  */
#line 1424 "modules/affile/affile-grammar.y"
                                                { file_perm_options_dont_change_dir_gid(last_file_perm_options); }
#line 4721 "modules/affile/affile-grammar.c"
    break;

  case 182: /* file_perm_option: KW_DIR_PERM '(' LL_NUMBER ')'  */
#line 1425 "modules/affile/affile-grammar.y"
                                                { file_perm_options_set_dir_perm(last_file_perm_options, (yyvsp[-1].num)); }
#line 4727 "modules/affile/affile-grammar.c"
    break;

  case 183: /* file_perm_option: KW_DIR_PERM '(' ')'  */
#line 1426 "modules/affile/affile-grammar.y"
                                                { file_perm_options_dont_change_dir_perm(last_file_perm_options); }
#line 4733 "modules/affile/affile-grammar.c"
    break;

  case 184: /* template_option: KW_TS_FORMAT '(' string ')'  */
#line 1430 "modules/affile/affile-grammar.y"
                                                { last_template_options->ts_format = cfg_ts_format_value((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4739 "modules/affile/affile-grammar.c"
    break;

  case 185: /* template_option: KW_FRAC_DIGITS '(' nonnegative_integer ')'  */
#line 1431 "modules/affile/affile-grammar.y"
                                                        { last_template_options->frac_digits = (yyvsp[-1].num); }
#line 4745 "modules/affile/affile-grammar.c"
    break;

  case 186: /* template_option: KW_TIME_ZONE '(' string ')'  */
#line 1432 "modules/affile/affile-grammar.y"
                                                { last_template_options->time_zone[LTZ_SEND] = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4751 "modules/affile/affile-grammar.c"
    break;

  case 187: /* template_option: KW_SEND_TIME_ZONE '(' string ')'  */
#line 1433 "modules/affile/affile-grammar.y"
                                                { last_template_options->time_zone[LTZ_SEND] = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4757 "modules/affile/affile-grammar.c"
    break;

  case 188: /* template_option: KW_LOCAL_TIME_ZONE '(' string ')'  */
#line 1434 "modules/affile/affile-grammar.y"
                                                { last_template_options->time_zone[LTZ_LOCAL] = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4763 "modules/affile/affile-grammar.c"
    break;

  case 189: /* template_option: KW_TEMPLATE_ESCAPE '(' yesno ')'  */
#line 1435 "modules/affile/affile-grammar.y"
                                                { last_template_options->escape = (yyvsp[-1].num); }
#line 4769 "modules/affile/affile-grammar.c"
    break;

  case 190: /* template_option: KW_ON_ERROR '(' string ')'  */
#line 1437 "modules/affile/affile-grammar.y"
        {
          gint on_error;

          CHECK_ERROR(log_template_on_error_parse((yyvsp[-1].cptr), &on_error), (yylsp[-1]), "Invalid on-error() setting \"%s\"", (yyvsp[-1].cptr));
          free((yyvsp[-1].cptr));

          log_template_options_set_on_error(last_template_options, on_error);
        }
#line 4782 "modules/affile/affile-grammar.c"
    break;

  case 191: /* multi_line_option: KW_MULTI_LINE_MODE '(' string ')'  */
#line 1553 "modules/affile/affile-grammar.y"
          {
            CHECK_ERROR(multi_line_options_set_mode(last_multi_line_options, (yyvsp[-1].cptr)), (yylsp[-1]), "Invalid multi-line mode");
	    free((yyvsp[-1].cptr));
          }
#line 4791 "modules/affile/affile-grammar.c"
    break;

  case 192: /* multi_line_option: KW_MULTI_LINE_PREFIX '(' string ')'  */
#line 1558 "modules/affile/affile-grammar.y"
          {
            GError *error = NULL;
            CHECK_ERROR_GERROR(multi_line_options_set_prefix(last_multi_line_options, (yyvsp[-1].cptr), &error), (yylsp[-1]), error, "error compiling multi-line regexp");
            free((yyvsp[-1].cptr));
          }
#line 4801 "modules/affile/affile-grammar.c"
    break;

  case 193: /* multi_line_option: KW_MULTI_LINE_GARBAGE '(' string ')'  */
#line 1564 "modules/affile/affile-grammar.y"
          {
            GError *error = NULL;

            CHECK_ERROR_GERROR(multi_line_options_set_garbage(last_multi_line_options, (yyvsp[-1].cptr), &error), (yylsp[-1]), error, "error compiling multi-line regexp");
            free((yyvsp[-1].cptr));
	  }
#line 4812 "modules/affile/affile-grammar.c"
    break;

  case 194: /* _template_ref_context_push: %empty  */
#line 1594 "modules/affile/affile-grammar.y"
                            { cfg_lexer_push_context(lexer, LL_CONTEXT_TEMPLATE_REF, NULL, "template reference"); }
#line 4818 "modules/affile/affile-grammar.c"
    break;

  case 195: /* _inner_dest_context_push: %empty  */
#line 1595 "modules/affile/affile-grammar.y"
                          { cfg_lexer_push_context(lexer, LL_CONTEXT_INNER_DEST, NULL, "within destination"); }
#line 4824 "modules/affile/affile-grammar.c"
    break;

  case 196: /* _inner_dest_context_pop: %empty  */
#line 1596 "modules/affile/affile-grammar.y"
                         { cfg_lexer_pop_context(lexer); }
#line 4830 "modules/affile/affile-grammar.c"
    break;

  case 197: /* _inner_src_context_push: %empty  */
#line 1597 "modules/affile/affile-grammar.y"
                         { cfg_lexer_push_context(lexer, LL_CONTEXT_INNER_SRC, NULL, "within source"); }
#line 4836 "modules/affile/affile-grammar.c"
    break;

  case 198: /* _inner_src_context_pop: %empty  */
#line 1598 "modules/affile/affile-grammar.y"
                        { cfg_lexer_pop_context(lexer); }
#line 4842 "modules/affile/affile-grammar.c"
    break;


#line 4846 "modules/affile/affile-grammar.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;
  *++yylsp = yyloc;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == AFFILE_EMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      {
        yypcontext_t yyctx
          = {yyssp, yytoken, &yylloc};
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = yysyntax_error (&yymsg_alloc, &yymsg, &yyctx);
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == -1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = YY_CAST (char *,
                             YYSTACK_ALLOC (YY_CAST (YYSIZE_T, yymsg_alloc)));
            if (yymsg)
              {
                yysyntax_error_status
                  = yysyntax_error (&yymsg_alloc, &yymsg, &yyctx);
                yymsgp = yymsg;
              }
            else
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = YYENOMEM;
              }
          }
        yyerror (&yylloc, lexer, instance, arg, yymsgp);
        if (yysyntax_error_status == YYENOMEM)
          YYNOMEM;
      }
    }

  yyerror_range[1] = yylloc;
  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= AFFILE_EOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == AFFILE_EOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval, &yylloc, lexer, instance, arg);
          yychar = AFFILE_EMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;

      yyerror_range[1] = *yylsp;
      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp, yylsp, lexer, instance, arg);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  yyerror_range[2] = yylloc;
  ++yylsp;
  YYLLOC_DEFAULT (*yylsp, yyerror_range, 2);

  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (&yylloc, lexer, instance, arg, YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != AFFILE_EMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval, &yylloc, lexer, instance, arg);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp, yylsp, lexer, instance, arg);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
  return yyresult;
}

#line 1603 "modules/affile/affile-grammar.y"

