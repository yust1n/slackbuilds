#ifndef UI_ATOM_H
#define UI_ATOM_H

extern void cgit_print_atom(char *tip, const char *path, int max_count);

#endif
