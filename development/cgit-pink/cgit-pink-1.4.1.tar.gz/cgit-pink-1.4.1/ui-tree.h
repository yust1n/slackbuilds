#ifndef UI_TREE_H
#define UI_TREE_H

extern void cgit_print_tree(const char *rev, char *path);

#endif /* UI_TREE_H */
