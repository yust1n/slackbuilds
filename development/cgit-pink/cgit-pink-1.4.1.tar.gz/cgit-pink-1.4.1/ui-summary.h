#ifndef UI_SUMMARY_H
#define UI_SUMMARY_H

extern void cgit_print_summary(void);
extern void cgit_print_repo_readme(const char *path);

#endif /* UI_SUMMARY_H */
