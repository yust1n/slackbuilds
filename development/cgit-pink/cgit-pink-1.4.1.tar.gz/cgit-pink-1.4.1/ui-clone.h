#ifndef UI_CLONE_H
#define UI_CLONE_H

void cgit_clone_info(void);
void cgit_clone_objects(void);
void cgit_clone_head(void);

#endif /* UI_CLONE_H */
