#ifndef UI_BLAME_H
#define UI_BLAME_H

extern void cgit_print_blame(void);

#endif /* UI_BLAME_H */
